<html lang="en" class="translated-ltr">
<head>
    <!-- Google Tag Manager -->
    <script type="text/javascript" async="" src="https://static.ads-twitter.com/uwt.js"></script>

    <script type="text/javascript" async="" src="https://static.ads-twitter.com/uwt.js"></script>
    <script type="text/javascript" async="" src="https://s.yimg.jp/images/listing/tool/cv/ytag.js"></script>
    <script type="text/javascript" async="" src="https://www.google-analytics.com/analytics.js"></script>
    <script type="text/javascript" async="" src="https://s.yimg.jp/images/listing/tool/cv/ytag.js"></script>


    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1,minimum-scale=1.0">

    <meta name="keywords" content="bitcoin,nem,xem,monacoin,zaif,exchange,trading,cryptocurrency,counterparty">

    <meta name="format-detection" content="telephone=no">
    <meta name="google-site-verification" content="RCnFAgVaddf6Ka0FFBAavQeEVuARWUg9j-L1QX0zgm0">

    <meta property="og:image" content="https://d2p8taqyjofgrq.cloudfront.net/images/index/ogp-logo.png">


    <title>Cryptocurrency Exchange - Zaif</title>
    <meta name="description"
          content="『暗号資産で資産形成ならZaif』 対象暗号資産の保有数量に応じて報酬を受け取れるステーキングや、1000円から始められるコイン積立、利用額に応じてBitcoinが還元されるZaifカードなど、独自のサービスで暗号資産の多様な資産形成手段をご提供しております。">


    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://d2p8taqyjofgrq.cloudfront.net/css/bootstrap.min.css?ver=3.3.4">
    <link rel="stylesheet" href="https://d2p8taqyjofgrq.cloudfront.net/css/typeahead.js-bootstrap.css?ver=20170607">
    <link rel="stylesheet" href="https://d2p8taqyjofgrq.cloudfront.net/css/zaif/style.css?rel=1734915364">
    <link rel="stylesheet" href="https://d2p8taqyjofgrq.cloudfront.net/css/zaif/baseaccount.css?rel=1734915364">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://d2p8taqyjofgrq.cloudfront.net/css/zaif/swiper.min.css?rel=1734915364">


    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin="">
    <link href="https://fonts.googleapis.com/css2?family=Noto+Sans+JP:wght@400;500;700&amp;display=swap"
          rel="stylesheet">

    <link rel="stylesheet" href="https://d2p8taqyjofgrq.cloudfront.net/css/zaif/style.css?rel=1734915364">
    <link rel="stylesheet" href="https://d2p8taqyjofgrq.cloudfront.net/css/zaif/index.css?rel=1734915364">

    <link rel="stylesheet" href="https://d2p8taqyjofgrq.cloudfront.net/css/zaif/logo/logo-Index.css?rel=1734915364">
    <link rel="stylesheet" href="https://d2p8taqyjofgrq.cloudfront.net/css/zaif/swiper.min.css?rel=1734915364">
    <link rel="stylesheet" href="https://d2p8taqyjofgrq.cloudfront.net/css/zaif/animate.css?rel=1734915364">
    <script src="https://d2p8taqyjofgrq.cloudfront.net/js/wow.min.js"></script>

    <!--LP-->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Crimson+Text" rel="stylesheet">


    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
    <!-- Latest compiled and minified JavaScript -->
    <script src="https://d2p8taqyjofgrq.cloudfront.net/js/jquery-1.11.3.min.js?ver=1.11.3"></script>
    <script src="https://d2p8taqyjofgrq.cloudfront.net/js/jquery.cookie.js?ver=1.4.1"></script>
    <script src="https://d2p8taqyjofgrq.cloudfront.net/js/bootstrap.min.js?ver=3.3.4"></script>
    <script src="https://d2p8taqyjofgrq.cloudfront.net/js/typeahead.bundle.min.js?ver=20170607"></script>
    <script src="https://d2p8taqyjofgrq.cloudfront.net/js/jquery.toaster.min.js?ver=20150408"></script>
    <script src="https://d2p8taqyjofgrq.cloudfront.net/js/zaif/assets.min.js?rel=1734915364"></script>
    <script src="https://d2p8taqyjofgrq.cloudfront.net/js/jquery.easing.js?ver=1.3"></script>
    <script src="https://d2p8taqyjofgrq.cloudfront.net/js/zaif/swiper.min.js?rel=1734915364"></script>


    <script src="https://d2p8taqyjofgrq.cloudfront.net/js/zaif/sentry/bundle.min.js?ver=7.12.1"></script>
    <script src="https://d2p8taqyjofgrq.cloudfront.net/js/zaif/sentry/bundle.tracing.min.js?ver=7.12.1"></script>



    <script src="https://d2p8taqyjofgrq.cloudfront.net/js/zaif/swiper.min.js?rel=1734915364"></script>


    <!--<script src="https://www.google.com/recaptcha/enterprise.js?hl=en"></script>-->
    <script src="https://d2p8taqyjofgrq.cloudfront.net/js/mathcontext.js"></script>
    <script src="https://d2p8taqyjofgrq.cloudfront.net/js/bigdecimal.js"></script>
    <script src="https://d2p8taqyjofgrq.cloudfront.net/js/jquery.color.js"></script>
    <script src="https://d2p8taqyjofgrq.cloudfront.net/js/swiper-bundle.min.js"></script>
    <script src="https://d2p8taqyjofgrq.cloudfront.net/js/swiper-bundle.min.js"></script>
    <script src="https://d2p8taqyjofgrq.cloudfront.net/js/zaif/page-visibility.js?rel=1734915364"></script>
    <script src="https://d2p8taqyjofgrq.cloudfront.net/js/zaif/currency_list.min.js?rel=1734915364"></script>

    <script>
        new WOW().init();
    </script>


    <link rel="apple-touch-icon" href="https://d2p8taqyjofgrq.cloudfront.net/apple-touch-icon.png">
    <link rel="apple-touch-icon" sizes="72x72" href="https://d2p8taqyjofgrq.cloudfront.net/apple-touch-icon-72x72.png">
    <link rel="apple-touch-icon" sizes="76x76" href="https://d2p8taqyjofgrq.cloudfront.net/apple-touch-icon-76x76.png">
    <link rel="apple-touch-icon" sizes="114x114"
          href="https://d2p8taqyjofgrq.cloudfront.net/apple-touch-icon-114x114.png">
    <link rel="apple-touch-icon" sizes="120x120"
          href="https://d2p8taqyjofgrq.cloudfront.net/apple-touch-icon-120x120.png">
    <link rel="apple-touch-icon" sizes="144x144"
          href="https://d2p8taqyjofgrq.cloudfront.net/apple-touch-icon-144x144.png">
    <link rel="apple-touch-icon" sizes="152x152"
          href="https://d2p8taqyjofgrq.cloudfront.net/apple-touch-icon-152x152.png">

    <script attributionsrc="" type="text/javascript" async=""
            src="https://www.googleadservices.com/pagead/conversion/969753373/?random=1735935515078&amp;cv=11&amp;fst=1735935515078&amp;bg=ffffff&amp;guid=ON&amp;async=1&amp;gtm=45be4cc1z8811417239za201zb811417239&amp;gcd=13l3l3l2l1l1&amp;dma_cps=syphamo&amp;dma=1&amp;tag_exp=101925629~102067555~102067808~102081485~102198178&amp;u_w=1366&amp;u_h=768&amp;url=https%3A%2F%2Fzaif.jp%2F&amp;label=zuiVCLyq6KcDEJ2Gtc4D&amp;hn=www.googleadservices.com&amp;frm=0&amp;tiba=%E6%9A%97%E5%8F%B7%E8%B3%87%E7%94%A3%E3%83%BB%E8%B2%A9%E5%A3%B2%E6%89%80%20-%20Zaif&amp;value=1&amp;bttype=purchase&amp;npa=1&amp;pscdl=noapi&amp;auid=1242597759.1735303710&amp;uaa=x86&amp;uab=64&amp;uafvl=Google%2520Chrome%3B131.0.6778.205%7CChromium%3B131.0.6778.205%7CNot_A%2520Brand%3B24.0.0.0&amp;uamb=0&amp;uam=&amp;uap=Windows&amp;uapv=10.0.0&amp;uaw=0&amp;fdr=CA&amp;capi=1&amp;rfmt=3&amp;fmt=4"></script>
    <link type="text/css" rel="stylesheet" charset="UTF-8"
          href="https://www.gstatic.com/_/translate_http/_/ss/k=translate_http.tr.26tY-h6gH9w.L.W.O/am=BgM/d=0/rs=AN8SPfowrRiAotkQD9r4k3ANeQYGsCLZ7g/m=el_main_css">
</head>


<body class="column1" data-new-gr-c-s-check-loaded="14.1215.0" data-gr-ext-installed="" cz-shortcut-listen="true">



<div id="wrapper">


    <header class="header" id="header">
        <nav class="navbar navbar-inverse navbar-fixed-top yamm">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <h1 id="logo"><a class="navbar-brand main-title" href="/"><img
                            src="https://d2p8taqyjofgrq.cloudfront.net/images/zaif_blue.svg"
                            alt="Zaif Cryptocurrency Exchange"></a></h1>
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar"
                        aria-expanded="false" aria-controls="navbar">
                    <span class="sr-only"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Toggle navigation</font></font></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div id="navbar" class="navbar-collapse collapse navbar-right">
                <ul class="nav navbar-nav">
                    <li><a href="/instant_exchange"><font style="vertical-align: inherit;"><font
                                    style="vertical-align: inherit;">Easy trading</font></font></a></li>
                    <li><a href="/trade"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Orderbook
                                    trading</font></font></a></li>


                    <li><a href="/doc_reserve"><font style="vertical-align: inherit;"><font
                                    style="vertical-align: inherit;">Coin Reserve</font></font></a></li>


                    <li class="dropdown yamm-fw">

                        <a class="dropdown-toggle" href="#" data-toggle="dropdown"><font
                                style="vertical-align: inherit;"><font
                                    style="vertical-align: inherit;">Service</font></font><b class="caret"></b></a>
                        <ul class="dropdown-menu dropdown-service">
                            <li class="nav-service">
                                <div class="nav-service-list">
                                    <ul class="nav-service-listUp">
                                        <li><a href="/automatic_trading_ranking"><font style="vertical-align: inherit;"><font
                                                        style="vertical-align: inherit;">Automatic trading (Ranking
                                                        trade)</font></font></a></li>
                                        <li><a href="/automatic_trading_easy"><font
                                                    style="vertical-align: inherit;"><font
                                                        style="vertical-align: inherit;">Automatic trading (Otegaru
                                                        trade)</font></font></a></li>
                                        <li><a href="/doc_zaifcard"><font style="vertical-align: inherit;"><font
                                                        style="vertical-align: inherit;">Zaif Card</font></font></a>
                                        </li>
                                    </ul>
                                </div>
                            </li>
                        </ul>
                    </li>
                    <li><a href="/login" class="text-skyb"><font style="vertical-align: inherit;"><font
                                    style="vertical-align: inherit;">Login</font></font></a></li>
                    <li><a href="/verify_email" class="text-skyb cv-header" data-toggle="header_tooltip"
                           data-placement="bottom" title="" data-original-title="Click here to start trading"><font
                                style="vertical-align: inherit;"><font style="vertical-align: inherit;">Register</font></font></a>
                    </li>

                    <li></li>
                    <li></li>



                    <li class="dropdown icon-container only_pc">
                        <a href="javascript:void(0)" class="dropdown-toggle text-skyb" data-toggle="dropdown"
                           role="button" aria-haspopup="true" aria-expanded="false">
                            <img src="https://d2p8taqyjofgrq.cloudfront.net/images/lang.png" alt="language"
                                 class="icon-button">
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="link-language" href="{{route('')}}" data-locale="ja"><font
                                        style="vertical-align: inherit;"><font
                                            style="vertical-align: inherit;">English</font></font></a></li>
                            <li role="separator" class="divider only_pc"></li>
                            <li><a class="link-language" href="javascript:void(0)" data-locale="en"><font
                                        style="vertical-align: inherit;"><font
                                            style="vertical-align: inherit;">English</font></font></a></li>
                        </ul>
                    </li>

                    <li class="only_sp"><a href="https://support.zaif.jp" target="_blank"><font
                                style="vertical-align: inherit;"><font style="vertical-align: inherit;">Contact
                                    Support</font></font></a></li>
                    <li class="dropdown only_sp">
                        <a href="javascript:void(0)" class="dropdown-toggle text-skyb" data-toggle="dropdown"
                           role="button" aria-haspopup="true" aria-expanded="false"><font
                                style="vertical-align: inherit;"><font
                                    style="vertical-align: inherit;">Language&nbsp;</font></font><span
                                class="caret"></span></a>
                        <ul class="dropdown-menu">
                            <li><a class="link-language" href="javascript:void(0)" data-locale="ja"><font
                                        style="vertical-align: inherit;"><font
                                            style="vertical-align: inherit;">English</font></font></a></li>
                            <li role="separator" class="divider only_pc"></li>
                            <li><a class="link-language" href="javascript:void(0)" data-locale="en"><font
                                        style="vertical-align: inherit;"><font
                                            style="vertical-align: inherit;">English</font></font></a></li>
                        </ul>
                    </li>
                </ul>
            </div><!-- /.navbar-collapse -->
        </nav>
        <script>
            $(function () {
                $('[data-toggle="header_tooltip"]').tooltip();
            });
        </script>
    </header>


    <div id="main" class="clearfix">


        <main class="top_page">
            <section class="kv_section">
                <div class="kv">
                    <div class="text">
                        <p class="catchcopy">
                            <span class="emphasis"><font style="vertical-align: inherit;"></font></span><font
                                style="vertical-align: inherit;"></font><br><font style="vertical-align: inherit;"><font
                                    style="vertical-align: inherit;">
                                    If you want to build assets </font><font style="vertical-align: inherit;">with
                                </font><span class="emphasis"><font
                                        style="vertical-align: inherit;">crypto assets</font></span></font><img
                                src="https://d2p8taqyjofgrq.cloudfront.net/images/top/zaif.png" alt="Zaif">
                        </p>
                        <p class="description"><font style="vertical-align: inherit;"><font
                                    style="vertical-align: inherit;">
                                    You can purchase even a small amount, so it's easy to start investing!
                                </font></font><br><font style="vertical-align: inherit;"><font
                                    style="vertical-align: inherit;">
                                    Why not start building your adult assets with cryptocurrency investment?
                                </font></font></p>
                        <a href="/verify_email" class="register_button">
                            <p>
                                <span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Get started now</font></font></span><img
                                    src="https://d2p8taqyjofgrq.cloudfront.net/images/top/icon/right_circle.svg"
                                    alt="Membership Registration">
                            </p>
                        </a>
                    </div>
                    <div class="image">
                        <img src="https://d2p8taqyjofgrq.cloudfront.net/images/top/mock_sp.png" alt="Smartphone app"
                             loading="lazy">
                    </div>
                </div>
                <div class="coins">
                    <ul class="currency-list"><a href="/sp/instant_exchange/btc/buy" class="action">
                            <li id="cp_btc_jpy"><p class="label ico-btc"><span><font
                                            style="vertical-align: inherit;"><font style="vertical-align: inherit;">BTC/JPY</font></font></span>
                                </p>
                                <p class="price up"><font style="vertical-align: inherit;"><font
                                            style="vertical-align: inherit;">15,440,000</font></font></p>
                                <p class="volatility up arrow-up"><span><font style="vertical-align: inherit;"><font
                                                style="vertical-align: inherit;">0.74%</font></font></span></p></li>
                        </a><a href="/sp/instant_exchange/eth/buy">
                            <li id="cp_eth_jpy"><p class="label ico-eth"><span><font
                                            style="vertical-align: inherit;"><font style="vertical-align: inherit;">ETH/JPY</font></font></span>
                                </p>
                                <p class="price up"><font style="vertical-align: inherit;"><font
                                            style="vertical-align: inherit;">563,600</font></font></p>
                                <p class="volatility up arrow-up"><span><font style="vertical-align: inherit;"><font
                                                style="vertical-align: inherit;">3.17%</font></font></span></p></li>
                        </a><a href="/sp/instant_exchange/snpt/buy">
                            <li id="cp_snpt_jpy"><p class="label ico-snpt"><span><font style="vertical-align: inherit;"><font
                                                style="vertical-align: inherit;">SNPT/JPY</font></font></span></p>
                                <p class="price down"><font style="vertical-align: inherit;"><font
                                            style="vertical-align: inherit;">6.2760</font></font></p>
                                <p class="volatility down arrow-down"><span><font style="vertical-align: inherit;"><font
                                                style="vertical-align: inherit;">7.56%</font></font></span></p></li>
                        </a><a href="/sp/instant_exchange/skeb/buy">
                            <li id="cp_skeb_jpy"><p class="label ico-skeb"><span><font style="vertical-align: inherit;"><font
                                                style="vertical-align: inherit;">SKEB/JPY</font></font></span></p>
                                <p class="price up"><font style="vertical-align: inherit;"><font
                                            style="vertical-align: inherit;">0.0920</font></font></p>
                                <p class="volatility up arrow-up"><span><font style="vertical-align: inherit;"><font
                                                style="vertical-align: inherit;">2.22%</font></font></span></p></li>
                        </a><a href="/sp/instant_exchange/zpg/buy">
                            <li id="cp_zpg_jpy"><p class="label ico-zpg"><span><font
                                            style="vertical-align: inherit;"><font style="vertical-align: inherit;">ZPG/JPY</font></font></span>
                                </p>
                                <p class="price down"><font style="vertical-align: inherit;"><font
                                            style="vertical-align: inherit;">13,335</font></font></p>
                                <p class="volatility down arrow-down"><span><font style="vertical-align: inherit;"><font
                                                style="vertical-align: inherit;">0.99%</font></font></span></p></li>
                        </a><a href="/sp/instant_exchange/bora/buy">
                            <li id="cp_bora_jpy"><p class="label ico-bora"><span><font style="vertical-align: inherit;"><font
                                                style="vertical-align: inherit;">BORA/JPY</font></font></span></p>
                                <p class="price down"><font style="vertical-align: inherit;"><font
                                            style="vertical-align: inherit;">19.2200</font></font></p>
                                <p class="volatility down arrow-down"><span><font style="vertical-align: inherit;"><font
                                                style="vertical-align: inherit;">10.6%</font></font></span></p></li>
                        </a><a href="/sp/instant_exchange/xym/buy">
                            <li id="cp_xym_jpy"><p class="label ico-xym"><span><font
                                            style="vertical-align: inherit;"><font style="vertical-align: inherit;">XYM/JPY</font></font></span>
                                </p>
                                <p class="price up"><font style="vertical-align: inherit;"><font
                                            style="vertical-align: inherit;">3.014</font></font></p>
                                <p class="volatility up arrow-up"><span><font style="vertical-align: inherit;"><font
                                                style="vertical-align: inherit;">3.6%</font></font></span></p></li>
                        </a><a href="/sp/instant_exchange/xem/buy">
                            <li id="cp_xem_jpy"><p class="label ico-xem"><span><font
                                            style="vertical-align: inherit;"><font style="vertical-align: inherit;">XEM/JPY</font></font></span>
                                </p>
                                <p class="price up"><font style="vertical-align: inherit;"><font
                                            style="vertical-align: inherit;">3.979</font></font></p>
                                <p class="volatility up arrow-up"><span><font style="vertical-align: inherit;"><font
                                                style="vertical-align: inherit;">2.95%</font></font></span></p></li>
                        </a><a href="/sp/instant_exchange/mbx/buy">
                            <li id="cp_mbx_jpy"><p class="label ico-mbx"><span><font
                                            style="vertical-align: inherit;"><font style="vertical-align: inherit;">MBX/JPY</font></font></span>
                                </p>
                                <p class="price up"><font style="vertical-align: inherit;"><font
                                            style="vertical-align: inherit;">57.9198</font></font></p>
                                <p class="volatility up arrow-up"><span><font style="vertical-align: inherit;"><font
                                                style="vertical-align: inherit;">5.3%</font></font></span></p></li>
                        </a></ul>
                </div>
            </section>

            <section class="banners_section">
                <div class="swiper banner_swiper swiper-initialized swiper-horizontal swiper-backface-hidden">
                    <div class="swiper-wrapper" id="swiper-wrapper-3d6b10f81b75ddb43" aria-live="polite">
                        <div class="swiper-slide swiper-slide-active" style="width: 343px; margin-right: 16px;"
                             role="group" aria-label="1 / 8" data-swiper-slide-index="0">
                            <a href="https://zaif-pr.jp/campaign/zpg_zres/" target="_blank" id="kv-20241223_zpg_buy_cp">
                                <img src="https://banner.zaif.jp/banner/banner_zpg_zres.png"
                                     alt="ZPG Acquisition Celebration! Coin Accumulation Campaign">
                            </a>
                        </div>
                        <div class="swiper-slide swiper-slide-next" style="width: 343px; margin-right: 16px;"
                             role="group" aria-label="2 / 8" data-swiper-slide-index="1">
                            <a href="https://zaif-pr.jp/campaign/snpt_buy/" target="_blank"
                               id="kv-20241205_snpt_buy_cp">
                                <img src="https://banner.zaif.jp/banner/banner_snpt_buy.png"
                                     alt="SNPT Listing Commemoration! Purchase Campaign">
                            </a>
                        </div>
                        <div class="swiper-slide" style="width: 343px; margin-right: 16px;" role="group"
                             aria-label="3 / 8" data-swiper-slide-index="2">
                            <a href="/doc_staking" target="_blank" id="kv-20240410_staking_appeal">
                                <img src="https://banner.zaif.jp/banner/banner_staking_appel2.png"
                                     alt="Staking is a new way to build assets">
                            </a>
                        </div>
                        <div class="swiper-slide" style="width: 343px; margin-right: 16px;" role="group"
                             aria-label="4 / 8" data-swiper-slide-index="3">
                            <a href="/doc_mobile_app" target="_blank" id="kv-20231220_doc_mobile_app">
                                <img src="https://banner.zaif.jp/banner/banner_app_202404.png" alt="App renewal">
                            </a>
                        </div>
                        <div class="swiper-slide" style="width: 343px; margin-right: 16px;" role="group"
                             aria-label="5 / 8" data-swiper-slide-index="4">
                            <a href="/doc_zaifcard" target="_blank" id="kv-20231220_zaifcard">
                                <img src="https://banner.zaif.jp/banner/banner_zaif_card_202404.png" alt="Zaif Card">
                            </a>
                        </div>
                        <div class="swiper-slide" style="width: 343px; margin-right: 16px;" role="group"
                             aria-label="6 / 8" data-swiper-slide-index="5">
                            <a href="https://zaif-pr.jp/manga/wakaru_otegarutrade/" target="_blank"
                               id="kv-20231220_otegaru_manga">
                                <img src="https://banner.zaif.jp/banner/banner_otegaru_manga_202404.png"
                                     alt="Easy automated trading">
                            </a>
                        </div>
                        <div class="swiper-slide" style="width: 343px; margin-right: 16px;" role="group"
                             aria-label="7 / 8" data-swiper-slide-index="6">
                            <a href="https://corp.zaif.jp/info/18434/" target="_blank"
                               id="kv-20231220_cs\manage_notice_01">
                                <img src="https://banner.zaif.jp/banner/banner_cs_notice_01.png"
                                     alt="Information update input guide">
                            </a>
                        </div>
                        <div class="swiper-slide" role="group" aria-label="8 / 8" data-swiper-slide-index="7"
                             style="width: 343px; margin-right: 16px;">
                            <a href="https://corp.zaif.jp/info/15904/" target="_blank"
                               id="kv-20231220_cs_manage_notice_02">
                                <img src="https://banner.zaif.jp/banner/banner_cs_notice_02.png" alt="Crime Alert">
                            </a>
                        </div>
                    </div>
                    <div class="controls only_pc">
                        <div class="swiper_pagination swiper-pagination-fraction swiper-pagination-horizontal"><span
                                class="swiper-pagination-current"><font style="vertical-align: inherit;"><font
                                        style="vertical-align: inherit;">1</font></font></span><font
                                style="vertical-align: inherit;"><font style="vertical-align: inherit;">
                                    / </font></font><span class="swiper-pagination-total"><font
                                    style="vertical-align: inherit;"><font
                                        style="vertical-align: inherit;">8</font></font></span></div>
                        <div class="swiper_prev" tabindex="0" role="button" aria-label="Previous slide"
                             aria-controls="swiper-wrapper-3d6b10f81b75ddb43">
                            <img src="https://d2p8taqyjofgrq.cloudfront.net/images/top/icon/prev.svg" alt="previous">
                        </div>
                        <div class="swiper_next" tabindex="0" role="button" aria-label="Next slide"
                             aria-controls="swiper-wrapper-3d6b10f81b75ddb43">
                            <img src="https://d2p8taqyjofgrq.cloudfront.net/images/top/icon/next.svg" alt="next">
                        </div>
                    </div>
                    <span class="swiper-notification" aria-live="assertive" aria-atomic="true"></span></div>
            </section>

            <section class="features_section">
                <h2><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">What Zaif can
                            do</font></font></h2>

                <div class="articles">
                    <article>
                        <div class="text">
                            <h4><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"># Point
                                        1</font></font></h4>
                            <h3>
                                <p><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">No
                                            handling fee</font></font></p>
                                <p><span class="emphasis"><font style="vertical-align: inherit;"><font
                                                style="vertical-align: inherit;">Start investing with a small amount</font></font></span>
                                </p>
                            </h3>
                            <p class="description"><font style="vertical-align: inherit;"><font
                                        style="vertical-align: inherit;">
                                        Zaif's Easy Buying and Selling (Sales Office) has no sales fees and allows you
                                        to buy and sell crypto assets in increments of a few hundred yen, making it a
                                        safe option for those who want to try investing first.
                                    </font></font></p>
                        </div>
                        <div class="image">
                            <img src="https://d2p8taqyjofgrq.cloudfront.net/images/top/feature_1.jpg"
                                 alt="Start investing with no fees and small amounts" loading="lazy">
                        </div>
                    </article>

                    <article>
                        <div class="text">
                            <h4><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"># Point
                                        2</font></font></h4>
                            <h3>
                                <p><span class="emphasis"><font style="vertical-align: inherit;"><font
                                                style="vertical-align: inherit;">A full range of cryptocurrencies</font></font></span><font
                                        style="vertical-align: inherit;"><font style="vertical-align: inherit;"> and
                                            services</font></font></p>
                            </h3>
                            <p class="description"><font style="vertical-align: inherit;"><font
                                        style="vertical-align: inherit;">
                                        You can buy and sell 26 types of crypto assets, including Bitcoin. You can also
                                        enjoy investing in the crypto assets you want to support after learning about
                                        the characteristics, development philosophy, and uses of each crypto asset.
                                    </font></font><br><font style="vertical-align: inherit;"><font
                                        style="vertical-align: inherit;">
                                        In addition, it also supports services such as savings and automated trading, so
                                        you can choose a service that suits your investment style.
                                    </font></font></p>
                        </div>
                        <div class="image">
                            <img src="https://d2p8taqyjofgrq.cloudfront.net/images/top/feature_2.jpg"
                                 alt="A full range of cryptocurrencies and services" loading="lazy">
                        </div>
                    </article>

                    <article>
                        <div class="text">
                            <h4><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"># Point
                                        3</font></font></h4>
                            <h3>
                                <p><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Because
                                            there is a proper explanation</font></font></p>
                                <p><span class="emphasis"><font style="vertical-align: inherit;"><font
                                                style="vertical-align: inherit;">Even beginners can continue</font></font></span>
                                </p>
                            </h3>
                            <p class="description"><font style="vertical-align: inherit;"><font
                                        style="vertical-align: inherit;">
                                        Even if you don't know anything about cryptocurrencies, you can gradually learn
                                        from explanatory articles and news, so you can continue investing without
                                        getting discouraged along the way.
                                    </font></font></p>
                        </div>
                        <div class="image">
                            <img src="https://d2p8taqyjofgrq.cloudfront.net/images/top/feature_3.jpg"
                                 alt="There are detailed explanations so even beginners can follow along"
                                 loading="lazy">
                        </div>
                    </article>
                </div>
                <a href="/verify_email" class="register_button">
                    <p>
                        <span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Get started now</font></font></span><img
                            src="https://d2p8taqyjofgrq.cloudfront.net/images/top/icon/right_circle.svg"
                            alt="Membership Registration">
                    </p>
                </a>
            </section>

            <section class="pickup_services_section">
                <article>
                    <h3>
                        <p><span class="emphasis"><font style="vertical-align: inherit;"></font></span><font
                                style="vertical-align: inherit;"></font><br class="only_pc"><font
                                style="vertical-align: inherit;"><font style="vertical-align: inherit;">Easily trade
                                    crypto assets </font><font style="vertical-align: inherit;">anywhere
                                    with </font><span class="emphasis"><font style="vertical-align: inherit;">just your smartphone and one hand .</font></span></font>
                        </p>
                    </h3>
                    <div class="image">
                        <img src="https://d2p8taqyjofgrq.cloudfront.net/images/top/sp_app.jpg" alt="Smartphone app"
                             loading="lazy">
                    </div>

                </article>

                <article>
                    <h3>
                        <p><span class="emphasis"><font style="vertical-align: inherit;"><font
                                        style="vertical-align: inherit;">Zaif Card is convenient for</font></font></span><font
                                style="vertical-align: inherit;"><font style="vertical-align: inherit;">
                                    transactions! </font></font><br class="only_pc"><font
                                style="vertical-align: inherit;"><font style="vertical-align: inherit;">The more you use
                                    it, the more </font></font><span class="emphasis"><font
                                    style="vertical-align: inherit;"><font
                                        style="vertical-align: inherit;">Bitcoin</font></font></span><font
                                style="vertical-align: inherit;"><font style="vertical-align: inherit;"> you get.</font></font>
                        </p>
                    </h3>
                    <div class="image">
                        <img src="https://d2p8taqyjofgrq.cloudfront.net/images/top/zaif_card.jpg" alt="Zaif Card"
                             loading="lazy">
                    </div>
                    <div class="links">
                        <a href="#" class="application_button">
                            <p>
                                <span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Apply here</font></font></span><img
                                    src="https://d2p8taqyjofgrq.cloudfront.net/images/top/icon/right_circle_blue.svg"
                                    alt="application">
                            </p>
                        </a>
                    </div>
                </article>
            </section>

            <section class="steps_section">
                <h2><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Steps to start
                            trading</font></font></h2>

                <div class="contents">
                    <div class="steps">
                        <ol>
                            <li>
                                <div class="icon">
                                    <img src="https://d2p8taqyjofgrq.cloudfront.net/images/top/step_1.png"
                                         alt="Open an account" loading="lazy">
                                </div>
                                <div class="step_label">
                                    <p class="title"><font style="vertical-align: inherit;"><font
                                                style="vertical-align: inherit;">1. Open an account</font></font></p>
                                    <p class="description"><font style="vertical-align: inherit;"><font
                                                style="vertical-align: inherit;">
                                                Create an account with your email address and password
                                            </font></font></p>
                                </div>
                            </li>
                            <li>
                                <div class="icon">
                                    <img src="https://d2p8taqyjofgrq.cloudfront.net/images/top/step_2.png"
                                         alt="Identity authentication" loading="lazy">
                                </div>
                                <div class="step_label">
                                    <p class="title"><font style="vertical-align: inherit;"><font
                                                style="vertical-align: inherit;">2. Identity Verification</font></font>
                                    </p>
                                    <p class="description"><font style="vertical-align: inherit;"><font
                                                style="vertical-align: inherit;">
                                                Enter the personal information required to open an account. Submit your
                                                identity verification documents via smartphone or mail.
                                            </font></font></p>
                                </div>
                            </li>
                            <li>
                                <div class="icon">
                                    <img src="https://d2p8taqyjofgrq.cloudfront.net/images/top/step_3.png" alt="payment"
                                         loading="lazy">
                                </div>
                                <div class="step_label">
                                    <p class="title"><font style="vertical-align: inherit;"><font
                                                style="vertical-align: inherit;">3. Deposit</font></font></p>
                                    <p class="description"><font style="vertical-align: inherit;"><font
                                                style="vertical-align: inherit;">
                                                Deposit the funds for your transaction into your Zaif account and you're
                                                ready to go!
                                            </font></font></p>
                                </div>
                            </li>
                        </ol>
                    </div>

                    <div class="cta">
                        <img src="https://d2p8taqyjofgrq.cloudfront.net/images/top/feature_1.jpg" alt="Start trading"
                             loading="lazy">
                        <p class="label"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Start
                                    trading as soon as possible!</font></font></p>
                        <a href="/verify_email" class="register_button">
                            <p>
                                <span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Get started now</font></font></span><img
                                    src="https://d2p8taqyjofgrq.cloudfront.net/images/top/icon/right_circle.svg"
                                    alt="Membership Registration">
                            </p>
                        </a>
                    </div>
                </div>
            </section>

            <section class="news_section">
                <div class="headline">
                    <h2><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">News from
                                Zaif</font></font></h2>
                    <a href="https://corp.zaif.jp/" target="_blank">
                        <p><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">See All</font></font>
                        </p>
                    </a>
                </div>

                <div class="articles">
                    <ul>
                        <li>
                            <article>
                                <div class="icon">
                                    <img src="https://d2p8taqyjofgrq.cloudfront.net/images/top/icon/news_icon_info.png"
                                         alt="Information" loading="lazy">
                                </div>
                                <div class="text">
                                    <a href="https://corp.zaif.jp/info/20241224_1-0-0-0" target="_blank">
                                        <p class="title"><font style="vertical-align: inherit;"><font
                                                    style="vertical-align: inherit;">[Advance Notice] Discontinuation of
                                                    Monacoin (MONA) handling on Zaif Payment</font></font></p>
                                    </a>
                                    <div class="article_footer">
                                        <p></p>
                                        <p><font style="vertical-align: inherit;"><font
                                                    style="vertical-align: inherit;">2024/12/27 12:00:00</font></font>
                                        </p>
                                    </div>
                                </div>
                            </article>
                        </li>
                        <li>
                            <article>
                                <div class="icon">
                                    <img src="https://d2p8taqyjofgrq.cloudfront.net/images/top/icon/news_icon_info.png"
                                         alt="Information" loading="lazy">
                                </div>
                                <div class="text">
                                    <a href="https://corp.zaif.jp/info/20241224_1-0-1" target="_blank">
                                        <p class="title"><font style="vertical-align: inherit;"><font
                                                    style="vertical-align: inherit;">[Important] Regarding our service
                                                    provision schedule during the New Year holidays</font></font></p>
                                    </a>
                                    <div class="article_footer">
                                        <p></p>
                                        <p><font style="vertical-align: inherit;"><font
                                                    style="vertical-align: inherit;">2024/12/26 17:13:09</font></font>
                                        </p>
                                    </div>
                                </div>
                            </article>
                        </li>
                        <li>
                            <article>
                                <div class="icon">
                                    <img src="https://d2p8taqyjofgrq.cloudfront.net/images/top/icon/news_icon_info.png"
                                         alt="Information" loading="lazy">
                                </div>
                                <div class="text">
                                    <a href="https://corp.zaif.jp/info/20241225_3" target="_blank">
                                        <p class="title"><font style="vertical-align: inherit;"><font
                                                    style="vertical-align: inherit;">Zaif launches new project to enable
                                                    Bitcoin staking services using Bflux and Babylon Bitcoin Staking
                                                    protocols</font></font></p>
                                    </a>
                                    <div class="article_footer">
                                        <p></p>
                                        <p><font style="vertical-align: inherit;"><font
                                                    style="vertical-align: inherit;">2024/12/25 18:51:30</font></font>
                                        </p>
                                    </div>
                                </div>
                            </article>
                        </li>
                        <li>
                            <article>
                                <div class="icon">
                                    <img src="https://d2p8taqyjofgrq.cloudfront.net/images/top/icon/news_icon_info.png"
                                         alt="Information" loading="lazy">
                                </div>
                                <div class="text">
                                    <a href="https://corp.zaif.jp/info/20241224_1-0-0" target="_blank">
                                        <p class="title"><font style="vertical-align: inherit;"><font
                                                    style="vertical-align: inherit;">Notice of discontinuation of DOT
                                                    (Polkadot) and MBX (MARBLEX)</font></font></p>
                                    </a>
                                    <div class="article_footer">
                                        <p></p>
                                        <p><font style="vertical-align: inherit;"><font
                                                    style="vertical-align: inherit;">2024/12/25 15:08:09</font></font>
                                        </p>
                                    </div>
                                </div>
                            </article>
                        </li>
                        <li>
                            <article>
                                <div class="icon">
                                    <img src="https://d2p8taqyjofgrq.cloudfront.net/images/top/icon/news_icon_info.png"
                                         alt="Information" loading="lazy">
                                </div>
                                <div class="text">
                                    <a href="https://corp.zaif.jp/info/20241224_1-0" target="_blank">
                                        <p class="title"><font style="vertical-align: inherit;"><font
                                                    style="vertical-align: inherit;">About customer asset
                                                    management</font></font></p>
                                    </a>
                                    <div class="article_footer">
                                        <p></p>
                                        <p><font style="vertical-align: inherit;"><font
                                                    style="vertical-align: inherit;">2024/12/25 12:06:41</font></font>
                                        </p>
                                    </div>
                                </div>
                            </article>
                        </li>
                    </ul>
                </div>
            </section>

            <section class="services_section">
                <h2><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">List of
                            services</font></font></h2>
                <div class="services">
                    <article>
                        <img src="https://d2p8taqyjofgrq.cloudfront.net/images/top/service_1.svg"
                             alt="Easy Trading and Orderbook Trading" loading="lazy">
                        <h3><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
                                    Easy Buying and Selling and
                                </font></font><br><font style="vertical-align: inherit;"><font
                                    style="vertical-align: inherit;">
                                    Orderbook Trading
                                </font></font></h3>
                        <p class="description only_pc"><font style="vertical-align: inherit;"><font
                                    style="vertical-align: inherit;">
                                    No complicated operating knowledge is required. The user-friendly design allows
                                    stress-free buying and selling operations.
                                </font></font></p>
                    </article>
                    <article>
                        <img src="https://d2p8taqyjofgrq.cloudfront.net/images/top/service_2.svg"
                             alt="Easy Trading and Orderbook Trading" loading="lazy">
                        <h3><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
                                    Learn about crypto assets with Zaif
                                </font></font></h3>
                        <p class="description only_pc"><font style="vertical-align: inherit;"><font
                                    style="vertical-align: inherit;">
                                    You can read articles and news about cryptocurrencies from your home page, so you
                                    can learn little by little.
                                </font></font></p>
                    </article>
                    <article>
                        <img src="https://d2p8taqyjofgrq.cloudfront.net/images/top/service_3.svg"
                             alt="Easy Trading and Orderbook Trading" loading="lazy">
                        <h3><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
                                    Coin Stacks
                                </font></font></h3>
                        <p class="description only_pc"><font style="vertical-align: inherit;"><font
                                    style="vertical-align: inherit;">
                                    If you believe that Bitcoin and cryptocurrencies have a promising future but want to
                                    avoid high-risk investments and speculative methods, you can also take advantage of
                                    installment investment plans.
                                </font></font></p>
                    </article>
                    <article>
                        <img src="https://d2p8taqyjofgrq.cloudfront.net/images/top/service_4.svg"
                             alt="Easy Trading and Orderbook Trading" loading="lazy">
                        <h3><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
                                    Chat Community
                                </font></font></h3>
                        <p class="description only_pc"><font style="vertical-align: inherit;"><font
                                    style="vertical-align: inherit;">
                                    Users can interact with each other. </font></font><br><font
                                style="vertical-align: inherit;"><font style="vertical-align: inherit;">There are many
                                    topics to discuss, including market trends and the latest information on
                                    cryptocurrencies.
                                </font></font></p>
                    </article>
                    <article>
                        <img src="https://d2p8taqyjofgrq.cloudfront.net/images/top/service_5.svg"
                             alt="Easy Trading and Orderbook Trading" loading="lazy">
                        <h3><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
                                    Social Tip
                                </font></font></h3>
                        <p class="description only_pc"><font style="vertical-align: inherit;"><font
                                    style="vertical-align: inherit;">
                                    You can easily send crypto assets to any Twitter account.
                                </font></font></p>
                    </article>
                </div>
            </section>
        </main>
        <script>
            const bannerSwiper = new Swiper('.banner_swiper', {
                slidesPerView: 1.2,
                spaceBetween: 16,
                centeredSlides: true,
                loop: true,
                breakpoints: {
                    1025: {
                        slidesPerView: 3,
                        spaceBetween: 16,
                        centeredSlides: false,
                    },
                },
                pagination: {
                    el: '.swiper_pagination',
                    type: 'fraction',
                },
                navigation: {
                    nextEl: ".swiper_next",
                    prevEl: ".swiper_prev",
                },
            });

            const displayCurrencyList = () => {
                const currencies = {
                    'btc_jpy': {
                        'instant_ticker': 'btc',
                        'trade_url': '/sp/instant_exchange/btc/buy',
                        'item': 'BTC',
                    },
                    'eth_jpy': {
                        'instant_ticker': 'eth',
                        'trade_url': '/sp/instant_exchange/eth/buy',
                        'item': 'ETH',
                    },
                    'snpt_jpy': {
                        'instant_ticker': 'snpt',
                        'trade_url': '/sp/instant_exchange/snpt/buy',
                        'unit_point': 4,
                        'item': 'SNPT',
                    },
                    'skeb_jpy': {
                        'instant_ticker': 'skeb',
                        'trade_url': '/sp/instant_exchange/skeb/buy',
                        'unit_point': 4,
                        'item': 'SKEB',
                    },
                    'zpg_jpy': {
                        'instant_ticker': 'zpg',
                        'trade_url': '/sp/instant_exchange/zpg/buy',
                        'item': 'ZPG',
                    },
                    'bora_jpy': {
                        'instant_ticker': 'bora',
                        'trade_url': '/sp/instant_exchange/bora/buy',
                        'unit_point': 4,
                        'item': 'BORA',
                    },
                    'xym_jpy': {
                        'instant_ticker': 'xym',
                        'trade_url': '/sp/instant_exchange/xym/buy',
                        'unit_point': 3,
                        'item': 'XYM',
                    },
                    'xem_jpy': {
                        'instant_ticker': 'xem',
                        'trade_url': '/sp/instant_exchange/xem/buy',
                        'unit_point': 3,
                        'item': 'XEM',
                    },
                    'mbx_jpy': {
                        'instant_ticker': 'mbx',
                        'trade_url': '/sp/instant_exchange/mbx/buy',
                        'unit_point': 4,
                        'item': 'MBX',
                    }
                }

                var tradeInfo = new TradeService(currencies);

                tradeInfo.dictionary.InstantTitle_ask = "{0}を買う";
                tradeInfo.dictionary.InstantTitle_bid = "{0}を売る";

                tradeInfo.start();

                page_visibility.hidden_method = function () {
                    tradeInfo.timer.clear();
                };
                page_visibility.show_method = function () {
                    tradeInfo.restart();
                };
                page_visibility.touchstart_method = function () {
                    tradeInfo.timer.clear();
                };
                page_visibility.touchend_method = function () {
                    tradeInfo.restart();
                };
            }

            document.addEventListener('DOMContentLoaded', displayCurrencyList);
        </script>


        <a href="#wrapper" onclick="smoothLink($(this));return false;">
            <div class="page-top">
                <span class="page-top-icon glyphicon glyphicon-arrow-up"></span>
            </div>
        </a>


        <footer class="footer">

            <p class="copy"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">© Zaif
                        Inc.</font></font></p>
        </footer>


    </div>
</div>


<script type="text/javascript">
    $(function () {
        $(".link-language").on("click", function (e) {
            return change_langage($(this))
        });
        $(".btn-language").on("click", function (e) {
            return change_langage($(this))
        });
        $(".modal").on("hidden.bs.modal", function () {
            $(".modal-backdrop").remove();
        });
    });

    function change_langage($btn) {
        var data = $btn.data();
        $.cookie("locale", data.locale, {path: "/", expires: 3560});
        var url = location.href.split("#")[0];
        url = url.replace(/lang=(en|ja)/g, "lang=" + data.locale);
        window.location.href = url;
        return false;
    };

    function smoothLink($link) {
        var speed = 2000;
        var href = $link.attr("href");
        var target = $(href == "#" || href == "" ? 'html' : href);
        var position = target.offset().top;
        $('body,html').animate({scrollTop: position}, speed, 'easeOutQuint');
        return false;
    };
</script>


</body>
</html>
