<div class="sidebar-menu">
    <div class="sidebar-menu__inner desktop-user-sidebar">
        <span class="sidebar-menu__close d-xl-none d-block"><i class="fas fa-times"></i></span>
        <div class="sidebar-logo">
            <div class="copy-link side-menu-refer-link">
                <input type="text" class="copyText" value="{{ route('home') }}?reference={{ auth()->user()->username }}" readonly>
                <button class="copy-link__button text--white copyTextBtn" data-bs-toggle="tooltip"  data-bs-placement="right" title="@lang('Copy URL')">
                    <span class="copy-link__icon"><i class="las la-copy"></i>
                    </span>
                </button>
            </div>

            <a href="{{ route('user.home') }}" class="sidebar-logo__link">
                <img src="{{siteLogo()}}">
            </a>
        </div>
        <ul class="sidebar-menu-list">
            <li class="sidebar-menu-list__item ">
                <a href="{{ route('user.home') }}" class="sidebar-menu-list__link {{ menuActive('user.home') }}">
                    <span class="icon"><span class="icon-dashboard"></span></span>
                    <span class="text">@lang('Dashboard')</span>
                </a>
            </li>
            <li class="sidebar-menu-list__item ">
                <a href="{{route('user.order.open')}}" class="sidebar-menu-list__link {{ menuActive('user.order.*') }} ">
                    <span class="icon"><span class="icon-order"></span></span>
                    <span class="text">@lang('Manage Order')</span>
                </a>
            </li>
            <li class="sidebar-menu-list__item ">
                <a href="{{route('user.stock.index')}}" class="sidebar-menu-list__link {{ menuActive('user.stock.index') }} ">
                    <span class="icon"><span class="icon-order"></span></span>
                    <span class="text">@lang('Stock')</span>
                </a>
            </li>
            <li class="sidebar-menu-list__item ">
                <a href="{{route('user.stock.my')}}" class="sidebar-menu-list__link {{ menuActive('user.stock.my') }} ">
                    <span class="icon"><span class="icon-order"></span></span>
                    <span class="text">@lang('My Stock')</span>
                </a>
            </li>
            <li class="sidebar-menu-list__item ">
                <a href="{{route('user.stock.transactions')}}" class="sidebar-menu-list__link {{ menuActive('user.stock.transactions') }} ">
                    <span class="icon"><span class="icon-order"></span></span>
                    <span class="text">@lang('Stock History')</span>
                </a>
            </li>
            <li class="sidebar-menu-list__item ">
                <a href="{{route('trade')}}" class="sidebar-menu-list__link {{ menuActive('user.trade') }} ">
                    <span class="icon"><span class="icon-trade"></span></span>
                    <span class="text">@lang('Trade')</span>
                </a>
            </li>
            <li class="sidebar-menu-list__item ">
                <a href="{{route('user.trade.history')}}" class="sidebar-menu-list__link {{ menuActive('user.trade.history') }} ">
                    <span class="icon"><span class="icon-trade"></span></span>
                    <span class="text">@lang('Trade History')</span>
                </a>
            </li>

            @if(checkAgent())
            <li class="sidebar-menu-list__item ">
                <a href="{{route('user.p2p.dashboard')}}" class="sidebar-menu-list__link {{ menuActive('user.p2p.dashboard') }} ">
                    <span class="icon"><span class="icon-trade"></span></span>
                    <span class="text">@lang('P2P Center')</span>
                </a>
            </li>

            @else
            <li class="sidebar-menu-list__item ">
                <a href="{{route('p2p')}}" class="sidebar-menu-list__link {{ menuActive('p2p') }} ">
                    <span class="icon"><span class="icon-trade"></span></span>
                    <span class="text">@lang('P2P')</span>
                </a>
            </li>
            <li class="sidebar-menu-list__item ">
                <a href="{{route('user.p2p.dashboard')}}" class="sidebar-menu-list__link {{ menuActive('user.p2p.dashboard') }} ">
                    <span class="icon"><span class="icon-trade"></span></span>
                    <span class="text">@lang('P2P Pending Order')</span>
                </a>
            </li>
            @endif

            <li class="sidebar-menu-list__item ">
                <a href="{{ route('user.wallet.overview') }}" class="sidebar-menu-list__link {{ menuActive('user.wallet.*') }}">
                    <span class="icon"><span class="icon-wallet"></span></span>
                    <span class="text">@lang('Manage Wallet')</span>
                </a>
            </li>
            <li class="sidebar-menu-list__item ">
                <a href="{{ route('user.deposit.history') }}" class="sidebar-menu-list__link {{ menuActive('user.deposit.*') }}">
                    <span class="icon"><span class="icon-deposit"></span></span>
                    <span class="text">@lang('Deposit History')</span>
                </a>
            </li>
            <li class="sidebar-menu-list__item ">
                <a href="{{ route('user.withdraw.history') }}" class="sidebar-menu-list__link {{ menuActive('user.withdraw.history') }}">
                    <span class="icon"><span class="icon-withdraw"></span></span>
                    <span class="text">@lang('Withdraw History')</span>
                </a>
            </li>
            <li class="sidebar-menu-list__item ">
                <a href="{{ route('user.referrals') }}" class="sidebar-menu-list__link {{ menuActive('user.referrals') }}">
                    <span class="icon"><span class="icon-affiliation"></span></span>
                    <span class="text">@lang('My Affiliation')</span>
                </a>
            </li>
            <li class="sidebar-menu-list__item ">
                <a href="{{ route('user.transactions') }}" class="sidebar-menu-list__link {{ menuActive('user.transactions') }}">
                    <span class="icon"><span class="icon-transaction"></span></span>
                    <span class="text">@lang('Transaction Histoy')</span>
                </a>
            </li>
            <li class="sidebar-menu-list__item ">
                <a href="{{ route('ticket.index') }}" class="sidebar-menu-list__link {{ menuActive('ticket.*') }}">
                    <span class="icon"><span class="icon-support"></span></span>
                    <span class="text">@lang('Get Support')</span>
                </a>
            </li>
            <li class="sidebar-menu-list__item ">
                <a href="{{ route('user.twofactor') }}" class="sidebar-menu-list__link {{ menuActive('user.twofactor') }}">
                    <span class="icon"><span class="icon-security"></span></span>
                    <span class="text">@lang('Security')</span>
                </a>
            </li>
            <li class="sidebar-menu-list__item ">
                <a href="{{ route('user.logout') }}" class="sidebar-menu-list__link">
                    <span class="icon"><span class="icon-logout"></span></span>
                    <span class="text">@lang('Logout')</span>
                </a>
            </li>
        </ul>
    </div>

    <div class="sidebar-menu__inner mobile-user-sidebar">
        <span class="sidebar-menu__close d-xl-none d-block"><i class="fas fa-times"></i></span>
        <div class="sidebar-logo d-none">
            <div class="copy-link side-menu-refer-link">
                <input type="text" class="copyText" value="{{ route('home') }}?reference={{ auth()->user()->username }}" readonly>
                <button class="copy-link__button text--white copyTextBtn" data-bs-toggle="tooltip"  data-bs-placement="right" title="@lang('Copy URL')">
                    <span class="copy-link__icon"><i class="las la-copy"></i>
                    </span>
                </button>
            </div>

        </div>
        <ul class="sidebar-menu-list">
            <li class="sidebar-menu-list__item account-section">
                <div class="row">
                    <div class="col-3 d-flex justify-content-center">
                        @if(auth()->user()->image)
                        <img class="m-user-image" src="{{ getImage(getFilePath('userProfile').'/'. auth()->user()->image,getFileSize('userProfile'),true) }}">
                        @else
                        <img class="m-user-image" src="{{asset('core/public/default_profile.png')}}">
                        @endif
                    </div>
                    <div class="col-9">
                        <h4 class="mb-1">
                            {{auth()->user()->fullname}}

                            <button class="copy-link__button text--white copyTextBtn float-right" data-bs-toggle="tooltip"  data-bs-placement="right" title="@lang('Copy URL')">
                                <span class="copy-link__icon">
                                    <i class="las la-copy"></i>
                                </span>
                            </button>
                        </h4>

                        <p>
                            @if(auth()->user()->kv=='0')
                                <span class="badge-pending">Unverified <i class="fa fa-info-circle ml-1"></i></span>
                            @elseif(auth()->user()->kv=='2')
                                <span class="badge-pending">Pending <i class="fa fa-info-circle ml-1"></i></span>
                            @elseif(auth()->user()->kv=='1')
                                <span class="badge-verified">Verified <i class="fa fa-certificate ml-1"></i></span>
                            @endif

                                @if(auth()->user()->group_expert && auth()->user()->group_expert=='yes')
                                    <span class="group-expert" style="font-size: 11px;margin-left: 12px;margin-right: 9px; background: rgba(245,226,13,0.9);padding: 3px 5px;border-radius: 5px;">
                                    Group Expert
                                </span>
                                @endif
                        </p>

                    </div>
                </div>
            </li>


                <li class="sidebar-menu-list__item separate-dashboard">
                    <a href="{{ route('user.home') }}"
                       class="sidebar-menu-list__link {{ menuActive('user.home') }}">
                        <span class="icon"><span class="icon-dashboard"></span></span>
                        <span class="text">@lang('Dashboard')</span>
                        <i class="fa fa-angle-right float-right"></i>
                    </a>
                </li>


            <!--Account Details -->
            <div class="separate-section-sidebar">
                <h6>Account Details</h6>
                <li class="sidebar-menu-list__item ">
                    <a href="{{ route('user.profile.setting') }}"
                       class="sidebar-menu-list__link {{ menuActive('user.profile.setting') }}">
                        <span class="icon"><span class="icon-dashboard"></span></span>
                        <span class="text">@lang('Profile')</span>
                        <i class="fa fa-angle-right float-right"></i>
                    </a>
                </li>
                <li class="sidebar-menu-list__item ">
                    <a href="{{ route('user.change.password') }}"
                       class="sidebar-menu-list__link {{ menuActive('user.change.password') }}">
                        <span class="icon"><span class="icon-dashboard"></span></span>
                        <span class="text">@lang('Change Password')</span>
                        <i class="fa fa-angle-right float-right"></i>
                    </a>
                </li>
                <li class="sidebar-menu-list__item ">
                    <a href="{{ route('user.twofactor') }}"
                       class="sidebar-menu-list__link flex-nowrap {{ menuActive('user.twofactor') }}">
                        <span class="icon"><span class="icon-dashboard"></span></span>
                        <span class="text d-block">@lang('Security')</span>
                        <i class="fa fa-angle-right float-right"></i>

                    </a>
                </li>

                @if(auth()->user()->kv=='0')
                <li class="sidebar-menu-list__item ">
                    <a href="{{ route('user.kyc.form') }}"
                       class="sidebar-menu-list__link flex-nowrap {{ menuActive('user.kyc.form') }}">
                        <span class="icon"><span class="icon-dashboard"></span></span>
                        <span class="text d-block">@lang('KYC Form')</span>
                        <i class="fa fa-angle-right float-right"></i>

                    </a>
                </li>
                @endif


            </div>


            <!-- Orders -->
            <div class="separate-section-sidebar">
                <h6>Orders</h6>
                <li class="sidebar-menu-list__item ">
                    <a href="{{ route('user.order.open') }}"
                       class="sidebar-menu-list__link {{ menuActive('user.order.open') }}">
                        <span class="icon"><span class="icon-dashboard"></span></span>
                        <span class="text">@lang('Trade Order')</span>
                        <i class="fa fa-angle-right float-right"></i>
                    </a>
                </li>
                <li class="sidebar-menu-list__item ">
                    <a href="{{ route('user.stock.my') }}"
                       class="sidebar-menu-list__link {{ menuActive('user.stock.my') }}">
                        <span class="icon"><span class="icon-dashboard"></span></span>
                        <span class="text">@lang('Market Order')</span>
                        <i class="fa fa-angle-right float-right"></i>
                    </a>
                </li>
            </div>

            <!-- History -->
            <div class="separate-section-sidebar">
                <h6>Histories</h6>

                <li class="sidebar-menu-list__item ">
                    <a href="{{ route('user.stock.transactions') }}"
                       class="sidebar-menu-list__link {{ menuActive('user.stock.transactions') }}">
                        <span class="icon"><span class="icon-dashboard"></span></span>
                        <span class="text">@lang('Market History')</span>
                        <i class="fa fa-angle-right float-right"></i>
                    </a>
                </li>
                <li class="sidebar-menu-list__item ">
                    <a href="{{ route('user.stock.daily.interest') }}"
                       class="sidebar-menu-list__link {{ menuActive('user.stock.daily.interest') }}">
                        <span class="icon"><span class="icon-dashboard"></span></span>
                        <span class="text">@lang('Daily Interest')</span>
                        <i class="fa fa-angle-right float-right"></i>
                    </a>
                </li>

                <li class="sidebar-menu-list__item ">
                    <a href="{{ route('user.trade.history') }}"
                       class="sidebar-menu-list__link {{ menuActive('user.trade.history') }}">
                        <span class="icon"><span class="icon-dashboard"></span></span>
                        <span class="text">@lang('Trade History')</span>
                        <i class="fa fa-angle-right float-right"></i>
                    </a>
                </li>

                <li class="sidebar-menu-list__item ">
                    <a href="{{ route('user.deposit.history') }}"
                       class="sidebar-menu-list__link {{ menuActive('user.deposit.history') }}">
                        <span class="icon"><span class="icon-dashboard"></span></span>
                        <span class="text">@lang('Deposit History')</span>
                        <i class="fa fa-angle-right float-right"></i>
                    </a>
                </li>

                <li class="sidebar-menu-list__item ">
                    <a href="{{ route('user.withdraw.history') }}"
                       class="sidebar-menu-list__link {{ menuActive('user.withdraw.history') }}">
                        <span class="icon"><span class="icon-dashboard"></span></span>
                        <span class="text">@lang('Withdraw History')</span>
                        <i class="fa fa-angle-right float-right"></i>
                    </a>
                </li>
                <li class="sidebar-menu-list__item ">
                    <a href="{{ route('user.transactions') }}"
                       class="sidebar-menu-list__link {{ menuActive('user.transactions') }}">
                        <span class="icon"><span class="icon-dashboard"></span></span>
                        <span class="text">@lang('Transactions')</span>
                        <i class="fa fa-angle-right float-right"></i>
                    </a>
                </li>
            </div>

            <!-- Wallets -->
            <div class="separate-section-sidebar">
                <h6>Wallets</h6>
                <li class="sidebar-menu-list__item ">
                    <a href="{{ route('user.wallet.overview') }}"
                       class="sidebar-menu-list__link {{ menuActive('user.wallet.overview') }}">
                        <span class="icon"><span class="icon-dashboard"></span></span>
                        <span class="text">@lang('Manage Wallet')</span>
                        <i class="fa fa-angle-right float-right"></i>
                    </a>
                </li>

                @if(checkAgent())
                    <li class="sidebar-menu-list__item ">
                        <a href="{{ route('user.p2p.dashboard') }}"
                           class="sidebar-menu-list__link {{ menuActive('user.p2p.dashboard') }}">
                            <span class="icon"><span class="icon-dashboard"></span></span>
                            <span class="text">@lang('P2P')</span>
                            <i class="fa fa-angle-right float-right"></i>
                        </a>
                    </li>
                @else
                    <li class="sidebar-menu-list__item ">
                        <a href="{{ route('user.p2p.dashboard') }}"
                           class="sidebar-menu-list__link {{ menuActive('user.p2p.dashboard') }}">
                            <span class="icon"><span class="icon-dashboard"></span></span>
                            <span class="text">@lang('P2P Pending Order')</span>
                            <i class="fa fa-angle-right float-right"></i>
                        </a>
                    </li>


                    <li class="sidebar-menu-list__item ">
                        <a href="{{ route('p2p') }}"
                           class="sidebar-menu-list__link {{ menuActive('user.p2p.dashboard') }}">
                            <span class="icon"><span class="icon-dashboard"></span></span>
                            <span class="text">@lang('P2P')</span>
                            <i class="fa fa-angle-right float-right"></i>
                        </a>
                    </li>
                @endif


            </div>


            <!-- Affiliate -->
            <li class="sidebar-menu-list__item separate-dashboard">
                <a href="{{ route('user.referrals') }}"
                   class="sidebar-menu-list__link {{ menuActive('user.referrals') }}">
                    <span class="icon"><span class="icon-dashboard"></span></span>
                    <span class="text">@lang('My Referral')</span>
                    <i class="fa fa-angle-right float-right"></i>
                </a>
            </li>



            <!-- Support -->
            <div class="separate-section-sidebar">
                <h6>Support</h6>
                <li class="sidebar-menu-list__item ">
                    <a href="{{ route('ticket.index') }}"
                       class="sidebar-menu-list__link {{ menuActive('ticket.index') }}">
                        <span class="icon"><span class="icon-dashboard"></span></span>
                        <span class="text">@lang('Support')</span>
                        <i class="fa fa-angle-right float-right"></i>
                    </a>
                </li>
            </div>



            <!-- Affiliate -->
            <li class="sidebar-menu-list__item separate-dashboard">
                <a href="{{ route('user.logout') }}"
                   class="sidebar-menu-list__link {{ menuActive('user.logout') }}">
                    <span class="icon"><span class="icon-dashboard"></span></span>
                    <span class="text">@lang('Logout')</span>
                    <i class="fa fa-angle-right float-right"></i>
                </a>
            </li>
        </ul>
    </div>

</div>



