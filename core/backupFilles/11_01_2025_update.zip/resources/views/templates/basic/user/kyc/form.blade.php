@extends($activeTemplate.'layouts.master')
@section('content')
    {{--    <div class="container">--}}
    {{--        <div class="row justify-content-center">--}}
    {{--            <div class="col-lg-8">--}}
    {{--                <div class="card custom--card">--}}
    {{--                    <div class="card-header">--}}
    {{--                        <h5 class="card-title">@lang('KYC Form')</h5>--}}
    {{--                    </div>--}}
    {{--                    <div class="card-body">--}}
    {{--                        <form action="{{route('user.kyc.submit')}}" method="post" enctype="multipart/form-data">--}}
    {{--                            @csrf--}}

    {{--                                <x-viser-form identifier="act" identifierValue="kyc" />--}}

    {{--                            <div class="form-group">--}}
    {{--                                <button type="submit" class="btn btn--base w-100">@lang('Submit')</button>--}}
    {{--                            </div>--}}
    {{--                        </form>--}}
    {{--                    </div>--}}
    {{--                </div>--}}
    {{--            </div>--}}
    {{--        </div>--}}
    {{--    </div>--}}












    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-12">

                <section class="wizard-section">
                    <div class="row no-gutters">
                        <div class="col-lg-12 col-md-12">
                            <div class="form-wizard">
                                <form action="{{route('user.kyc.submit')}}" method="post" id="kycForm" role="form">
                                    @csrf


                                    <div class="form-wizard-header">
                                        <h2>Time To Verify Your Account</h2>
                                        <ul class="list-unstyled form-wizard-steps clearfix">
                                            <li class="active"><span>1</span></li>
                                            <li><span>2</span></li>
                                            <li><span>3</span></li>
                                            <li><span>4</span></li>
                                            <li><span>5</span></li>
                                        </ul>
                                    </div>

                                    <fieldset class="wizard-fieldset show">
                                        <h5>Personal Information</h5>
                                        <div class="form-group">
                                            <input type="text" class="form-control wizard-required" name="first_name" id="fname">
                                            <label for="fname" class="wizard-form-text-label">First Name*</label>
                                            <div class="wizard-form-error"></div>
                                        </div>

                                        <div class="form-group">
                                            <input type="text" class="form-control wizard-required" name="last_name" id="lname">
                                            <label for="lname" class="wizard-form-text-label">Last Name*</label>
                                            <div class="wizard-form-error"></div>
                                        </div>

                                        <div class="form-group">
                                            <input type="text" class="form-control wizard-required" name="maiden_name" id="maiden_name">
                                            <label for="maiden_name" class="wizard-form-text-label">Mother's Maiden Name*</label>
                                            <div class="wizard-form-error"></div>
                                        </div>

                                        <div class="form-group">
                                            <input type="text" class="form-control wizard-required" name="phone" id="pnumber">
                                            <label for="pnumber" class="wizard-form-text-label">Enter Number With Country Code*</label>
                                            <div class="wizard-form-error"></div>
                                        </div>


                                        <div class="form-group">
                                            <select name="home_owner" class="form-control">
                                                <option selected></option>
                                                <option value="Own Home">Own Home</option>
                                                <option value="Family Home">Family Home</option>
                                                <option value="Renting Home">Renting Home</option>
                                                <option value="Others">Others</option>
                                            </select>
                                            <label class="wizard-form-text-label">Home Ownership Status*</label>
                                        </div>

                                        <div class="form-group">
                                            Marital Status
                                            <br>
                                            <div class="wizard-form-radio">
                                                <input name="marital_status" id="married" type="radio">
                                                <label for="married">Married</label>
                                            </div>
                                            <div class="wizard-form-radio">
                                                <input name="marital_status" checked id="single" type="radio">
                                                <label for="single">Single</label>
                                            </div>
                                            <div class="wizard-form-radio">
                                                <input name="marital_status" id="divorced" type="radio">
                                                <label for="divorced">Divorced</label>
                                            </div>
                                        </div>

                                        <div class="form-group clearfix">
                                            <a href="javascript:;" class="form-wizard-next-btn float-right">Next</a>
                                        </div>
                                    </fieldset>

                                    <fieldset class="wizard-fieldset">
                                        <h5>Financial Information</h5>

                                        <div class="form-group">
                                            <select name="occupation" class="form-control">
                                                <option selected></option>
                                                <option value="Student">Student</option>
                                                <option value="Employee">Employee</option>
                                                <option value="Government Employee">Government Employee</option>
                                                <option value="Freelancer">Freelancer</option>
                                                <option value="Others">Others</option>
                                            </select>
                                            <label class="wizard-form-text-label">Occupation*</label>
                                        </div>

                                        <div class="form-group">
                                            <select name="income_source" class="form-control">
                                                <option selected></option>
                                                <option value="Salary">Salary</option>
                                                <option value="Savings">Savings</option>
                                                <option value="Others">Others</option>
                                            </select>
                                            <label class="wizard-form-text-label">Source Of Income*</label>
                                        </div>

                                        <div class="form-group">
                                            <select name="annual_income" class="form-control">
                                                <option selected></option>
                                                <option value="<50 million"> <50 million </option>
                                                <option value="50-200 million"> 50-200 million </option>
                                                <option value="250-500 million"> 250-500 million </option>
                                                <option value="500-1.5 billion"> 500-1.5 billion </option>
                                                <option value="250-500 billion"> >1.5 billion </option>
                                            </select>
                                            <label class="wizard-form-text-label">Annual Income*</label>
                                        </div>

                                        <div class="form-group">
                                            <select name="account_purpose" class="form-control">
                                                <option selected></option>
                                                <option value="Hedging"> Hedging </option>
                                                <option value="Investment"> Investment </option>
                                                <option value="Speculation"> Speculation </option>
                                                <option value="Others"> Others </option>
                                            </select>
                                            <label class="wizard-form-text-label">Purpose Of Account*</label>
                                        </div>


                                        <div class="form-group clearfix">
                                            <a href="javascript:;" class="form-wizard-previous-btn float-left">Previous</a>
                                            <a href="javascript:;" class="form-wizard-next-btn float-right">Next</a>
                                        </div>
                                    </fieldset>

                                    <fieldset class="wizard-fieldset">
                                        <h5>ID Verification</h5>

                                        <div class="form-group">
                                            <select name="document_type"  class="form-control document_type">
                                                <option selected></option>
                                                <option value="ID Card">ID Card</option>
                                                <option value="Passport">Passport</option>
                                                <option value="Driving Licence">Driving Licence</option>
                                            </select>
                                            <label class="wizard-form-text-label">Document Type*</label>
                                        </div>

                                        <div>
                                            <div class="form-group id-card-section doc-type d-none">
                                                <input type="text" placeholder="Enter ID-Card Number" name="id_number" class="form-control id_number">
                                            </div>
                                        </div>

                                        <div>
                                            <div class="form-group passport-card-section doc-type d-none">
                                                <input type="text" placeholder="Enter Passport Number" name="passport_number" class="form-control passport_number">
                                            </div>
                                        </div>

                                        <div>
                                            <div class="form-group dl-card-section doc-type d-none">
                                                <input type="text" placeholder="Enter Driving Licence Number" name="dl_number" class="form-control dl_number">
                                            </div>
                                        </div>


                                        <div class="form-group">
                                            <label>Front Page* (Max Size: 2MB)</label>
                                            <input type="file" name="front_page" class="form-control front_page">
                                            <div class="wizard-form-error"></div>
                                        </div>
                                        <div class="form-group">
                                            <label>Back Page* (Max Size: 2MB)</label>
                                            <input type="file" name="back_page" class="form-control back_page">
                                            <div class="wizard-form-error"></div>
                                        </div>
                                        <div class="form-group">
                                            <label>Selfie* (Max Size: 2MB)</label>
                                            <input type="file" name="selfie" class="form-control selfie">
                                            <div class="wizard-form-error"></div>
                                        </div>


                                        <div class="form-group clearfix">
                                            <a href="javascript:;" class="form-wizard-previous-btn float-left">Previous</a>
                                            <a href="javascript:;" class="form-wizard-next-btn float-right">Next</a>
                                        </div>
                                    </fieldset>

                                    <fieldset class="wizard-fieldset">
                                        <h5>US Stock Financial Information</h5>

                                        <div class="form-group">
                                            <select name="net_worth_estimate" class="form-control">
                                                <option selected></option>
                                                <option value="<500 million"> < 500 million</option>
                                                <option value="500-1.0 billion"> 500-1 billion </option>
                                                <option value="1-5 billion"> 1-5 billion </option>
                                                <option value="5-10 billion"> 5-10 billion </option>
                                                <option value="10 billion"> > 10 billion </option>
                                            </select>
                                            <label class="wizard-form-text-label">Net Wroth Estimate*</label>
                                        </div>

                                        <div class="form-group">
                                            Have you had any experienced in investment?
                                            <br>
                                            <div class="wizard-form-radio">
                                                <input name="experienced_in_investment" id="experienced_yes" type="radio">
                                                <label for="experienced_yes">Yes</label>
                                            </div>
                                            <div class="wizard-form-radio">
                                                <input name="experienced_in_investment" checked id="experienced_no" type="radio">
                                                <label for="experienced_no">No</label>
                                            </div>
                                        </div>

                                        <div class="form-group">
                                            Have you been declared bankrupt by court?
                                            <br>
                                            <div class="wizard-form-radio">
                                                <input name="bankrupt_by_court" id="bankrupt_yes" type="radio">
                                                <label for="bankrupt_yes">Yes</label>
                                            </div>
                                            <div class="wizard-form-radio">
                                                <input name="bankrupt_by_court" checked id="bankrupt_no" type="radio">
                                                <label for="bankrupt_no">No</label>
                                            </div>
                                        </div>

                                        <div class="form-group clearfix">
                                            <a href="javascript:;" class="form-wizard-previous-btn float-left">Previous</a>
                                            <a href="javascript:;" class="form-wizard-next-btn float-right">Next</a>
                                        </div>
                                    </fieldset>

                                    <fieldset class="wizard-fieldset">
                                        <h5>Emergency Contacts</h5>

                                        <div class="form-group">
                                            <select name="relationship" class="form-control">
                                                <option selected></option>
                                                <option value="father">Father</option>
                                                <option value="brother">Brother</option>
                                                <option value="wife">Wife</option>
                                                <option value="others">Other</option>
                                            </select>
                                            <label class="wizard-form-text-label">Relationship</label>
                                        </div>


                                        <div class="form-group">
                                            <input type="text" class="form-control wizard-required" name="relation_full_name" id="honame">
                                            <label for="honame" class="wizard-form-text-label">Full Name*</label>
                                            <div class="wizard-form-error"></div>
                                        </div>
                                        <div class="form-group">
                                            <input type="text" class="form-control wizard-required"
                                                   name="emergency_phone" id="emergency_phone">
                                            <label for="emergency_phone" class="wizard-form-text-label">Phone
                                                Number*</label>
                                            <div class="wizard-form-error"></div>
                                        </div>

                                        <div class="form-group">
                                            <input type="text" class="form-control wizard-required" name="address" id="address">
                                            <label for="address" class="wizard-form-text-label">Address*</label>
                                            <div class="wizard-form-error"></div>
                                        </div>


                                        <div class="form-group clearfix">
                                            <a href="javascript:;" class="form-wizard-previous-btn float-left">Previous</a>

                                            <button class="form-wizard-submit float-right kycFormSubmit" type="button">Submit</button>
                                        </div>
                                    </fieldset>

                                </form>
                            </div>
                        </div>
                    </div>
                </section>

            </div>
        </div>
    </div>

@endsection



@push('style')

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css"  />

    <style>

        .wizard-content-left {
            background-blend-mode: darken;
            background-color: rgba(0, 0, 0, 0.45);
            background-image: url("https://i.ibb.co/X292hJF/form-wizard-bg-2.jpg");
            background-position: center center;
            background-size: cover;
            height: 100vh;
            padding: 30px;
        }
        .wizard-content-left h1 {
            color: #ffffff;
            font-size: 38px;
            font-weight: 600;
            padding: 12px 20px;
            text-align: center;
        }

        .form-wizard {
            color: #888888;
            padding: 30px;
        }
        .form-wizard .wizard-form-radio {
            display: inline-block;
            margin-left: 5px;
            position: relative;
        }
        .form-wizard .wizard-form-radio input[type="radio"] {
            -webkit-appearance: none;
            -moz-appearance: none;
            -ms-appearance: none;
            -o-appearance: none;
            appearance: none;
            background-color: #dddddd;
            height: 25px;
            width: 25px;
            display: inline-block;
            vertical-align: middle;
            border-radius: 50%;
            position: relative;
            cursor: pointer;
        }
        .form-wizard .wizard-form-radio input[type="radio"]:focus {
            outline: 0;
        }
        .form-wizard .wizard-form-radio input[type="radio"]:checked {
            background-color: #0066ff;
        }
        .form-wizard .wizard-form-radio input[type="radio"]:checked::before {
            content: "";
            position: absolute;
            width: 10px;
            height: 10px;
            display: inline-block;
            background-color: #ffffff;
            border-radius: 50%;
            left: 1px;
            right: 0;
            margin: 0 auto;
            top: 8px;
        }
        .form-wizard .wizard-form-radio input[type="radio"]:checked::after {
            content: "";
            display: inline-block;
            webkit-animation: click-radio-wave 0.65s;
            -moz-animation: click-radio-wave 0.65s;
            animation: click-radio-wave 0.65s;
            background: #000000;
            content: '';
            display: block;
            position: relative;
            z-index: 100;
            border-radius: 50%;
        }
        .form-wizard .wizard-form-radio input[type="radio"] ~ label {
            padding-left: 10px;
            cursor: pointer;
        }
        .form-wizard .form-wizard-header {
            text-align: center;
        }
        .form-wizard .form-wizard-next-btn, .form-wizard .form-wizard-previous-btn, .form-wizard .form-wizard-submit {
            background-color: #0066ff;
            color: #ffffff;
            display: inline-block;
            min-width: 100px;
            min-width: 120px;
            padding: 10px;
            text-align: center;
        }
        .form-wizard .form-wizard-next-btn:hover, .form-wizard .form-wizard-next-btn:focus, .form-wizard .form-wizard-previous-btn:hover, .form-wizard .form-wizard-previous-btn:focus, .form-wizard .form-wizard-submit:hover, .form-wizard .form-wizard-submit:focus {
            color: #ffffff;
            opacity: 0.6;
            text-decoration: none;
        }
        .form-wizard .wizard-fieldset {
            display: none;
        }
        .form-wizard .wizard-fieldset.show {
            display: block;
        }
        .form-wizard .wizard-form-error {
            display: none;
            background-color: #d70b0b;
            position: absolute;
            left: 0;
            right: 0;
            bottom: 0;
            height: 2px;
            width: 100%;
        }
        .form-wizard .form-wizard-previous-btn {
            background-color: #0066ff;
        }
        .form-wizard .form-control {
            font-weight: 300;
            height: auto !important;
            padding: 15px;
            color: white !important;
            background: #060d0ea6 !important;
            border: none;
            -webkit-text-fill-color: white !important;
        }
        .form-wizard .form-control:focus {
            box-shadow: none;
        }
        .form-wizard .form-group {
            position: relative;
            margin: 25px 0;
        }
        .form-wizard .wizard-form-text-label {
            position: absolute;
            left: 10px;
            top: 16px;
            transition: 0.2s linear all;
        }
        .form-wizard .focus-input .wizard-form-text-label {
            color: #0066ff;
            top: -18px;
            transition: 0.2s linear all;
            font-size: 12px;
        }
        .form-wizard .form-wizard-steps {
            margin: 30px 0;
        }
        .form-wizard .form-wizard-steps li {
            width: 20%;
            float: left;
            position: relative;
        }
        .form-wizard .form-wizard-steps li::after {
            background-color: #f3f3f3;
            content: "";
            height: 5px;
            left: 0;
            position: absolute;
            right: 0;
            top: 50%;
            transform: translateY(-50%);
            width: 100%;
            border-bottom: 1px solid #dddddd;
            border-top: 1px solid #dddddd;
        }
        .form-wizard .form-wizard-steps li span {
            background-color: #dddddd;
            border-radius: 50%;
            display: inline-block;
            height: 40px;
            line-height: 40px;
            position: relative;
            text-align: center;
            width: 40px;
            z-index: 1;
        }
        .form-wizard .form-wizard-steps li:last-child::after {
            width: 50%;
        }
        .form-wizard .form-wizard-steps li.active span, .form-wizard .form-wizard-steps li.activated span {
            background-color: #0066ff;
            color: #ffffff;
        }
        .form-wizard .form-wizard-steps li.active::after, .form-wizard .form-wizard-steps li.activated::after {
            background-color: #0066ff;
            left: 50%;
            width: 50%;
            border-color: #0066ff;
        }
        .form-wizard .form-wizard-steps li.activated::after {
            width: 100%;
            border-color: #0066ff;
        }
        .form-wizard .form-wizard-steps li:last-child::after {
            left: 0;
        }
        .form-wizard .wizard-password-eye {
            position: absolute;
            right: 32px;
            top: 50%;
            transform: translateY(-50%);
            cursor: pointer;
        }
        @keyframes click-radio-wave {
            0% {
                width: 25px;
                height: 25px;
                opacity: 0.35;
                position: relative;
            }
            100% {
                width: 60px;
                height: 60px;
                margin-left: -15px;
                margin-top: -15px;
                opacity: 0.0;
            }
        }
        @media screen and (max-width: 767px) {
            .wizard-content-left {
                height: auto;
            }
            .form-wizard{
                padding: 0px !important;
            }
        }

    </style>

@endpush

@push('script')
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>

    <script>
        jQuery(document).ready(function() {
            // click on next button
            jQuery('.form-wizard-next-btn').click(function() {
                var parentFieldset = jQuery(this).parents('.wizard-fieldset');
                var currentActiveStep = jQuery(this).parents('.form-wizard').find('.form-wizard-steps .active');
                var next = jQuery(this);
                var nextWizardStep = true;
                parentFieldset.find('.wizard-required').each(function(){
                    var thisValue = jQuery(this).val();

                    if( thisValue == "") {
                        jQuery(this).siblings(".wizard-form-error").slideDown();
                        nextWizardStep = false;
                    }
                    else {
                        jQuery(this).siblings(".wizard-form-error").slideUp();
                    }
                });
                if( nextWizardStep) {
                    next.parents('.wizard-fieldset').removeClass("show","400");
                    currentActiveStep.removeClass('active').addClass('activated').next().addClass('active',"400");
                    next.parents('.wizard-fieldset').next('.wizard-fieldset').addClass("show","400");
                    jQuery(document).find('.wizard-fieldset').each(function(){
                        if(jQuery(this).hasClass('show')){
                            var formAtrr = jQuery(this).attr('data-tab-content');
                            jQuery(document).find('.form-wizard-steps .form-wizard-step-item').each(function(){
                                if(jQuery(this).attr('data-attr') == formAtrr){
                                    jQuery(this).addClass('active');
                                    var innerWidth = jQuery(this).innerWidth();
                                    var position = jQuery(this).position();
                                    jQuery(document).find('.form-wizard-step-move').css({"left": position.left, "width": innerWidth});
                                }else{
                                    jQuery(this).removeClass('active');
                                }
                            });
                        }
                    });
                }
            });
            //click on previous button
            jQuery('.form-wizard-previous-btn').click(function() {
                var counter = parseInt(jQuery(".wizard-counter").text());;
                var prev =jQuery(this);
                var currentActiveStep = jQuery(this).parents('.form-wizard').find('.form-wizard-steps .active');
                prev.parents('.wizard-fieldset').removeClass("show","400");
                prev.parents('.wizard-fieldset').prev('.wizard-fieldset').addClass("show","400");
                currentActiveStep.removeClass('active').prev().removeClass('activated').addClass('active',"400");
                jQuery(document).find('.wizard-fieldset').each(function(){
                    if(jQuery(this).hasClass('show')){
                        var formAtrr = jQuery(this).attr('data-tab-content');
                        jQuery(document).find('.form-wizard-steps .form-wizard-step-item').each(function(){
                            if(jQuery(this).attr('data-attr') == formAtrr){
                                jQuery(this).addClass('active');
                                var innerWidth = jQuery(this).innerWidth();
                                var position = jQuery(this).position();
                                jQuery(document).find('.form-wizard-step-move').css({"left": position.left, "width": innerWidth});
                            }else{
                                jQuery(this).removeClass('active');
                            }
                        });
                    }
                });
            });
            //click on form submit button
            jQuery(document).on("click",".form-wizard .form-wizard-submit" , function(){
                var parentFieldset = jQuery(this).parents('.wizard-fieldset');
                var currentActiveStep = jQuery(this).parents('.form-wizard').find('.form-wizard-steps .active');
                parentFieldset.find('.wizard-required').each(function() {
                    var thisValue = jQuery(this).val();
                    if( thisValue == "" ) {
                        jQuery(this).siblings(".wizard-form-error").slideDown();
                    }
                    else {
                        jQuery(this).siblings(".wizard-form-error").slideUp();
                    }
                });
            });
            // focus on input field check empty or not
            jQuery(".form-control").on('focus', function(){
                var tmpThis = jQuery(this).val();
                var thisName = jQuery(this).attr('name');

                if(thisName=='id_number' || thisName=='passport_number' || thisName=='dl_number'){
                    return;
                }

                if(tmpThis == '' ) {
                    jQuery(this).parent().addClass("focus-input");
                }
                else if(tmpThis !='' ){
                    jQuery(this).parent().addClass("focus-input");
                }

            }).on('blur', function(){
                var tmpThis = jQuery(this).val();
                var thisName = jQuery(this).attr('name');

                if(thisName=='id_number' || thisName=='passport_number' || thisName=='dl_number'){
                    return;
                }


                if(tmpThis == '' ) {
                    jQuery(this).parent().removeClass("focus-input");
                    jQuery(this).siblings('.wizard-form-error').slideDown("3000");
                }
                else if(tmpThis !='' ){
                    jQuery(this).parent().addClass("focus-input");
                    jQuery(this).siblings('.wizard-form-error').slideUp("3000");
                }
            });
        });


        $(document).on('change', '.document_type', function (e){
            const type=$(this).val();

            $('.doc-type').addClass('d-none');

            if(type=='ID Card'){
                $('.id-card-section').removeClass('d-none');
            }else if(type=='Passport'){
                $('.passport-card-section').removeClass('d-none')
            }else if(type=='Driving Licence'){
                $('.dl-card-section').removeClass('d-none')
            }

        });


        // $(document).ready(function () {
        //     const maxFileSize = 2 * 1024 * 1024; // 2MB in bytes

        //     // Function to validate file size
        //     function validateFileSize(input, type) {
        //         const file = input.files[0]; // Get the selected file
        //          if (file) {
        //             if (file.size > maxFileSize) {
        //                 if(type=='front_page') {
        //                     toastr.error('Please upload front page less than  2MB. Please upload a smaller file.');
        //                     $('.front_page').val('');

        //                 }else if(type='back_page') {
        //                     toastr.error('Please upload back page less than  2MB. Please upload a smaller file.');
        //                     $('.back_page').val('');

        //                 }else if(type=='selfie') {
        //                     toastr.error('Please upload selfie less than  2MB. Please upload a smaller file.');
        //                     $('.selfie').val('');

        //                 }
        //             } else {
        //             }
        //         } else {
        //         }
        //     }



        //     // Attach the change event listener to each file input
        //     $(".front_page").on("change", function () {
        //         validateFileSize(this,'front_page');
        //     });
        //     $(".back_page").on("change", function () {
        //         validateFileSize(this,'back_page');
        //     });
        //     $(".selfie").on("change", function () {
        //         validateFileSize(this,'selfie');
        //     });
        // });


        $(document).on('click', '.kycFormSubmit', function (e){

            const document_type=$('.document_type').val();

            let doc_number=null;

            if(document_type=='ID Card'){
                doc_number=$('.id_number').val();

                if(!doc_number){
                    toastr.error('Please Enter ID-Card Number');
                    return;
                }
            }

            if(document_type=='Passport'){
                doc_number=$('.passport_number').val();

                if(!doc_number){
                    toastr.error('Please Enter Passport Number');
                    return;
                }
            }

            if(document_type=='Driving Licence'){
                doc_number=$('.dl_number').val();

                if(!doc_number){
                    toastr.error('Please Enter Driving Licence Number');
                    return;
                }
            }



            $.ajax({
                type:'POST',
                url:'{{route('user.kyc.data.check')}}',
                data:{
                    doc_number:doc_number,document_type:document_type,'_token':'{{csrf_token()}}'
                },

                success:function (res){
                    if(res.status=='success'){

                        $('#kycForm').submit();
                    }else{
                        toastr.error(res.message);
                    }
                }
            })







        })


    </script>

@endpush
