@extends($activeTemplate . 'layouts.master')
@section('content')
    <div class="row justify-content-end gy-3">
        <div class="col-12">

            <div class="row">
                <div class="col-md-12">
                    <div class="row stock-sec">

                        <div class="col-md-12">
                            <button type="button" class="btn btn-success buyStock d-s-buy-btn btn-custom-class btn-sm">
                                Buy Stock
                            </button>
                        </div>
                    </div>
                </div>

                <div class="col-md-12 mt-3">

                    <!-- TradingView Widget BEGIN -->
                    <div class="tradingview-widget-container">
                        <div class="tradingview-widget-container__widget"></div>

                        <script type="text/javascript" src="https://s3.tradingview.com/external-embedding/embed-widget-symbol-overview.js" async>
                            {
                                "symbols": [
                                [
                                    "{{$stock->stock_code}}"
                                ]
                            ],
                                "chartOnly": false,
                                "width": "100%",
                                "height": "100%",
                                "locale": "en",
                                "colorTheme": "dark",
                                "autosize": true,
                                "showVolume": false,
                                "showMA": false,
                                "hideDateRanges": false,
                                "hideMarketStatus": false,
                                "hideSymbolLogo": false,
                                "scalePosition": "right",
                                "scaleMode": "Normal",
                                "fontFamily": "-apple-system, BlinkMacSystemFont, Trebuchet MS, Roboto, Ubuntu, sans-serif",
                                "fontSize": "10",
                                "noTimeScale": false,
                                "valuesTracking": "1",
                                "changeMode": "price-and-percent",
                                "chartType": "area",
                                "maLineColor": "#2962FF",
                                "maLineWidth": 1,
                                "maLength": 9,
                                "headerFontSize": "medium",
                                "lineWidth": 2,
                                "lineType": 0,
                                "dateRanges": [
                                "1d|1",
                                "1m|30",
                                "3m|60",
                                "12m|1D",
                                "60m|1W",
                                "all|1M"
                            ]
                            }
                        </script>
                    </div>
                    <!-- TradingView Widget END -->

                    <div class="row mt-3 mobile-view-buy">
                        <div class="col-md-8">
                            <button type="button" style="width: 100%;" class="btn btn-success d-block buyStock btn-custom-class btn-sm">
                                Buy Stock
                            </button>
                        </div>
                    </div>

                    <div class="row desc-sec-stock">
                        <div class="col-md-12">
                            <p>{!! $stock->short_description !!}</p>
                            <div class="mt-2">
                                {!! $stock->description !!}
                            </div>
                        </div>
                    </div>

                    <div class="row mt-5">
                        @if($videos)
                            @foreach($videos as $key=>$video)
                                <div class="col-md-3 col-12">
                                    <div class="video-section">
                                        <video controls>
                                            <source src="{{ getImage(getFilePath('currency') .'/'.$video->video,getFileSize('currency')) }}" type="video/mp4">
                                        </video>
                                    </div>

                                </div>
                            @endforeach
                        @endif
                    </div>

                </div>
            </div>

        </div>
    </div>

    <!-- Modal -->
    <div class="modal fade modal-lg" id="butStockModal" style="background: rgb(35, 35, 35);" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered "  role="document">
            <div class="modal-content" style="background: #000000;">
                <form action="{{route('user.stock.buy')}}" method="post">
                    @csrf

                    <input type="hidden" name="id" value="{{$stock->id}}">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLongTitle">Confirm Buy</h5>
                        <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-12 col-12">
                                <div>
                                    <strong>Stock:</strong> {{$stock->name}}
                                </div>

                            </div>
                            <div class="col-md-12">
                                <div class="mt-2">
                                    <label for="">Buy In</label>
                                    <div class="form-group mb-3 d-flex mt-3 justify-content-between">
                                        <div>
                                            <input type="radio" name="type" class="choose-stock-type" checked id="fix" value="fix">
                                            <label for="fix"><b>Mutual Fund</b></label>
                                        </div>

                                        <div>
                                            <input type="radio" name="type" class="choose-stock-type ml-3" id="unfix" value="unfix">
                                            <label for="unfix"><b>Live Market</b></label>
                                        </div>
                                    </div>

                                    <div class="stock-fix-section">
                                        <div class="row">
                                            <div class="col-md-6 col-6">
                                                <label for="">Enter Amount</label>
                                                <input type="text" class="form-control iv-amnt" placeholder="Enter Amount" name="invest_amount">
                                            </div>
                                            <div class="col-md-6 col-6">
                                                <label class="d-block" for="">Holding time</label>
                                                <select name="invest_time" class="form-control">
                                                    <option value="month">1 Month</option>
                                                    <option value="half_year">6 Month</option>
                                                    <option value="year">1 Year</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="form-group custom-stock-section" style="display: none">

                                        <button type="button" class="btn custom-stock-btn" data-name="25">25%</button>
                                        <button type="button" class="btn custom-stock-btn ml-2" data-name="50">50%</button>
                                        <button type="button" class="btn custom-stock-btn ml-2 active" data-name="100">100%</button>
                                    </div>

                                </div>

                            </div>
                        </div>


                        <input type="hidden" name="unfix_amount" class="unfix_amount" value="100">

                        <div class="alert alert-info mt-3">
                            <small>
                                <strong>Info! </strong> {{$stock->short_description}}
                            </small>
                        </div>

                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary btn-custom-class btn-sm" data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary btn-custom-class confirmBuy btn-sm">Confirm</button>
                    </div>
                </form>
            </div>
        </div>
    </div>


    <x-confirmation-modal isCustom="true"/>
@endsection

@push('topContent')
    <h4 class="mb-4">{{ __($pageTitle) }}</h4>
@endpush

@push('script-lib')
    <script src="{{ asset('assets/global/js/select2.min.js') }}"></script>
@endpush
@push('style-lib')
    <link rel="stylesheet" href="{{ asset('assets/global/css/select2.min.css') }}">

    <style>
        .tradingview-widget-container{
            min-height: 400px;
        }
        .btn-custom-class{
            padding: 10px 20px !important;
        }
        .custom-stock-btn.active,.custom-stock-btn.active:hover{
            background: #1329b8 !important;
            border: 1px solid #0022ff;
        }
        .custom-stock-btn:hover {
            background: #a3a3a3;
        }
        .custom-stock-btn{
            background: #a3a3a3;
            padding: 10px 20px !important;
        }
        .custom-stock-section{
            transition: visibility 0s linear 0.33s, opacity 0.33s linear;
        }
        .mobile-view-buy{
            display: none;
        }
        .desc-sec-stock{
            margin-top: 50px;
        }
        .iv-amnt{
            color: black !important;
        }
        .video-section {
            text-align: center;
            }
        .video-section video{
            height: 160px;
            width: 95%;
            margin: 0 auto;
        }

        @media(max-width: 700px) {
            .mobile-view-buy{
                display: block !important;
            }
            .d-s-buy-btn{
                display: none;
            }

            .video-section video{
                height: 185px;
                width: 90%;
                margin: 0 auto;
            }

        }

        .dashboard__right{
            min-height: 1800px;
        }
    </style>
@endpush


@push('script')
    <script>
        "use strict";

        $(document).on('click', '.custom-stock-btn', function (e) {
            e.preventDefault();

            const name = $(this).attr('data-name');
            $('.unfix_amount').val(name);

            $('.custom-stock-btn').removeClass('active');
            $(this).addClass('active');
        });


        $(document).on('click', '.buyStock', function (e){

            $('#butStockModal').modal('show');
        });

        $(document).on('click', '.choose-stock-type', function (e){

            const type=$(this).val();
            if(type=='unfix'){
                $('.custom-stock-section').show();
                $('.stock-fix-section').hide();
            }else{
                $('.custom-stock-section').hide();
                $('.stock-fix-section').show();
            }
        });

    </script>
@endpush
