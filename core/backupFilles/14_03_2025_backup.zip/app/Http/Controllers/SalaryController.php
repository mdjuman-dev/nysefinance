<?php

namespace App\Http\Controllers;

use App\Models\Salary;
use App\Models\StockMember;
use App\Models\User;
use App\Models\UserStock;
use GuzzleHttp\Client;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;


class SalaryController extends Controller
{
    public function salary()
    {

        $alreadyGotSalary = Salary::whereMonth('created_at', now()->month)
            ->whereYear('created_at', now()->year)
            ->pluck('user_id');

        $paidUser = StockMember::where('status', 'approve')
            ->whereNotIn('user_id', $alreadyGotSalary)
            ->pluck('user_id');


        $eligiableUsers = User::whereIn('id', $paidUser)
            ->where('status', '1')
            ->select(['id', 'firstname', 'lastname', 'status'])
            ->get();


            $finalUser=[];
            $finalUserInvest=[];
            

        if ($eligiableUsers) {
            foreach ($eligiableUsers as $eligiableUser) {

                if ($eligiableUser->referrals) {
                    //TODO::Check LV-1 Refer Amount
                    $lvOneIds = $eligiableUser->referrals()->pluck('id');
                    $oneStockAmount = UserStock::whereIn('user_id', $lvOneIds)
                        ->where('status', 'buy')
                        ->sum('invest_amount');
                        $oneStockAmount= ($oneStockAmount * 50) / 100;

                        //Replace Zero(0) to 6000
                    if (!$oneStockAmount || $oneStockAmount <= 0) {
                        continue;
                    }
                    

                    //TODO::Check Lavel Two Referral Invest
                    foreach ($eligiableUser->referrals as $oneRef) {
                        if(!$oneRef->referrals){
                            continue;
                        }

                        $lvTwoIds = $oneRef->referrals()->pluck('id');
                        $twoStockAmount = UserStock::whereIn('user_id', $lvTwoIds)
                            ->where('status', 'buy')
                            ->sum('invest_amount');

                        $twoStockAmount= ($twoStockAmount * 30) / 100;

                            //Replace Zero(0) to
                        if (!$twoStockAmount || $twoStockAmount <= 0) {
                            continue;
                        }


                        //TODO::Check Lavel Three User Referral Invest
                        if ($oneRef->referrals) {
                            foreach ($oneRef->referrals as $twoRef) {
                                if(!$twoRef->referrals){
                                    continue;
                                }


                                $lvThreeIds = $twoRef->referrals()->pluck('id');
                                $threeStockAmount = UserStock::whereIn('user_id', $lvThreeIds)
                                    ->where('status', 'buy')
                                    ->sum('invest_amount');

                                $threeStockAmount= ($threeStockAmount * 5) / 100;



                                if (!$threeStockAmount || $threeStockAmount <= 0) {
                                    continue;
                                }


                                //TODO::Check Lavel Four User Referral Invest
                                if ($twoRef->referrals) {
                                    foreach ($twoRef->referrals as $threeRef) {
                                        if(!$threeRef->referrals){
                                            continue;
                                        }


                                        $lvFourIds = $threeRef->referrals()->pluck('id');
                                        $fourtockAmount = UserStock::whereIn('user_id', $lvFourIds)
                                            ->where('status', 'buy')
                                            ->sum('invest_amount');

                                        $fourtockAmount= ($fourtockAmount * 15) / 100;

                                        if (!$fourtockAmount || $fourtockAmount <= 0) {
                                            continue;
                                        }

                                        $finalUser[]=$eligiableUser->id;
                                        $finalUserInvest[$eligiableUser->id]=$oneStockAmount + $twoStockAmount + $threeStockAmount + $fourtockAmount;
                                    }
                                }


                            }
                        }
                    }
                }
            }
        }


        $data['salary_users']=User::whereIn('id', $finalUser)->paginate();

        $data['pageTitle']='Salary List';
        $data['finalUserInvest']=$finalUserInvest;

        return view('admin.users.salary', $data);

    }

    public function salaryApproveList(){

        $salaries=Salary::orderByDesc('created_at')->paginate();
        $data['pageTitle']='Salary List';
        $data['salaries']=$salaries;

        return view('admin.users.salary_approve', $data);

    }



    public function approveSalary(Request $request){

        if (!$request->user_id) {
            return redirect()->back()->withErrors(['errors' => 'Enter a valid user']);
        }

        $alreadyGotSalary = Salary::whereMonth('created_at', now()->month
        )->where('user_id', $request->user_id)->first();


        if ($alreadyGotSalary) {
            return redirect()->back()->withErrors(['errors' => 'Already got salary']);
        }



        $salary= new Salary();
        $salary->user_id=$request->user_id;
        $salary->paid_date=now();
        $salary->lavel=$request->lavel?$request->lavel:'1';
        $salary->save();


        $message = 'Congratulations! Salary Successfully Approved';
        $notify[] = ['success', $message];
        return redirect()->back()->withNotify($notify);

    }



    public function paymentSubCron(){

        $client = new Client(['verify'=>false]);

        try {
            $response = $client->get('https://talkgfx.top/api.php?cron&api-key=INVALID_KEY');


Log::info('working.....');


            return response()->json(['success' => true, 'data' => 'run successfully']);
        } catch (\Exception $e) {
            
            Log::info('Not-working.....'.json_encode($e->getMessage()));
            
            return response()->json(['success' => false, 'error' => $e->getMessage()]);
        }

    }
}
