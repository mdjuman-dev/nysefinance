@extends($activeTemplate . 'layouts.master')
@section('content')
    <div class="row gy-4 justify-content-center">
        <div class="col-12">
            <div class="dashboard-header-menu justify-content-between align-items-center">
                <h4 class="mb-0 d-none">{{ __($pageTitle) }}</h4>
                <div class="div">
                    <a href="{{ route('user.wallet.overview') }}"
                       class="dashboard-header-menu__link  {{ menuActive('user.wallet.overview', null) }}">
                        @lang('Overview')
                    </a>
                    <a href="{{ route('user.wallet.list', 'spot') }}"
                       class="dashboard-header-menu__link  {{ menuActive('user.wallet.list', null, 'spot') }}">
                        @lang('Spot')
                    </a>
                    <a href="{{ route('user.wallet.list', 'funding') }}"
                       class="dashboard-header-menu__link  {{ menuActive('user.wallet.list', null, 'funding') }}">
                        @lang('Funding')
                    </a>
                    <a href="{{ route('user.wallet.stock') }}"
                       class="dashboard-header-menu__link  {{ menuActive('user.wallet.stock', null) }}">
                        @lang('Stock')
                    </a>
                </div>
            </div>
        </div>
        @if(isset($overview) && $overview)
            <div class="col-lg-12">
                <div class="table-wrapper pt-0">
                    @if(isset($estimatedBalances))
                        <div class="n-view-balance">
                            <h4 class="mb-1">Total Balance</h4>
                            <div class="bal-m-sec d-none">
                                <div class="main-balance">
                                    <span class="bal-font">{{ str_replace('USD', '', showAmount($estimatedBalances)) }}</span> <span
                                        class="currency-font">USD</span> <i class="fa fa-eye hide-balance"></i>
                                </div>
                                <div class="main-balance-hide">
                                    ********* <i class="fa fa-eye-slash show-balance"></i>
                                </div>
                            </div>
                            <small class="today-pnl">Today PNL $00000(-0.00%)</small>
                        </div>
                    @endif


                    <div class="row" style="padding-top: 20px">
                        <div class="col-3 w-sm-icon-main-section">
                            <div class="w-sec-sm-icons deposit-cash-wallet" >
                                <i class="fa fa-bar-chart"></i>
                            </div>
                            <small class="w-icon-t-section">
                                Deposit
                            </small>
                        </div>
                        @php $ttype=isset($typeValue)?$typeValue:'spot'; @endphp

                        <div class="col-3 w-sm-icon-main-section">
                            <div class="w-sec-sm-icons withdraw-cash" >
                                <i class="icon-withdraw"></i>
                            </div>
                            <small class="w-icon-t-section">
                                Withdraw
                            </small>
                        </div>

                        <div class="col-3 w-sm-icon-main-section">
                            <div class="w-sec-sm-icons" data-url="{{ route('p2p') }}">
                                <i class="icon-wallet"></i>
                            </div>
                            <small class="w-icon-t-section">
                                Buy
                            </small>
                        </div>
                        @php $w_type=$typeValue==1?'spot':'funding'; @endphp
                        <div class="col-3 w-sm-icon-main-section">
                            <div class="w-sec-sm-icons" data-url="{{ route('user.wallet.view',  [ 'type' => $w_type,'currencySymbol' => 'USDT','fm'=>'transfer']) }}">
                                <i class="fa fa-bar-chart"></i>
                            </div>
                            <small class="w-icon-t-section">
                                Transfer
                            </small>
                        </div>

                    </div>


                </div>

                <table class="table">
                    <input type="text" style="background: #1a1a1a;color: white !important;border-color: #4b4949;"
                           id="currencySearch" class="form-control mb-3 mt-2" placeholder="Search by Symbol"
                           onkeyup="searchTable()">


                    <thead>
                    <tr>
                        <th>@lang('Currency')</th>
                        <th>@lang('Available Balance')</th>
                    </tr>
                    </thead>
                    <tbody id="walletTableBody">
                    @forelse($wallets as $wallet)
                        <tr>
                            <td class="d-flex">
                                <a class="d-flex"
                                   href="{{ route('user.wallet.view',  [ 'type' => $wallet->typeText,'currencySymbol' => @$wallet->currency->symbol]) }}">
                                    <div class="customer__thumb">
                                        <img src="{{ @$wallet->currency->image_url }}">
                                    </div>

                                    <small style="margin-top: 4px; margin-left: 13px"
                                           class="fs-12 currency-symbol currency-symbols">{{ @$wallet->currency->symbol }}</small>
                                </a>
                            </td>
                            <td>{{ __(@$wallet->currency->sign) }}{{ showAmount(@$wallet->total_balance,currencyFormat:false) }} </td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="5">No wallets found</td>
                        </tr>
                    @endforelse
                    </tbody>
                </table>
                @if ($wallets->hasPages())
                    {{ paginateLinks($wallets) }}
                @endif
            </div>
        @elseif(isset($stock_wallet) && $stock_wallet)
            <div class="col-lg-12">
                <div class="table-wrapper">
                    <table class="table table--responsive--lg">
                        <thead>
                        <tr>
                            <th>Total Earned</th>
                            <th>@lang('Available Balance')</th>
                            <th>@lang('Total Balance')</th>
                            <th>@lang('Action')</th>
                        </tr>
                        </thead>
                        <tbody>
                        <tr>
                            <td>
                                {{$total_earn}}
                            </td>
                            <td>{{$stock_wallet->amount}} </td>
                            <td>{{$total_buy}} USD</td>
                            <td>
                                <button {{$stock_wallet->amount <= 0?'disabled="disabled"':''}} class="btn btn-success stockTransfer" type="button">Transfer</button>
                            </td>
                        </tr>
                        </tbody>
                    </table>
                </div>
            </div>

        <div class="col-md-12 mt-4">
            <table class="table">
                <h4>My Stocks</h4>
                <thead>
                <tr>
                    <th>Name</th>
                    <th>Type</th>
                    <th>Amount</th>
                    <th>Status</th>
                </tr>
                </thead>
                <tbody>
                @forelse($user_stocks as $user_stock)
                    <tr>
                        <td>
                            {{$user_stock->product->name}}
                        </td>
                        <td>
                            @if($user_stock->type=='fix')
                                Mutual Fund
                            @else
                                Live Market
                            @endif
                        </td>
                        <td>
                            {{$user_stock->invest_amount}}
                        </td>
                        <td>
                            @if($user_stock->status=='sell')
                                <span class="badge badge--danger">Sell</span>
                            @else
                                <span class="badge badge--success">Buy</span>
                            @endif
                        </td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="5">No wallets found</td>
                    </tr>
                @endforelse
                </tbody>
            </table>
            @if ($user_stocks->hasPages())
                {{ paginateLinks($user_stocks) }}
            @endif
        </div>

            <div class="modal fade" id="stockWithdraw" tabindex="-1" role="dialog"
                 aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered" role="document">
                    <div class="modal-content">
                        <form action="{{route('user.stock.wallet.transfer')}}" method="post">
                            @csrf

                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLongTitle">Transfer</h5>
                                <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <div class="form-group">
                                    <h4>Available Balance: <span class="stock-current-balance">{{$stock_wallet->amount}}</span> USD</h4>
                                </div>
                                <div class="form-group">
                                    <label for="">Amount</label>
                                    <input type="text" name="amount" class="form-control transfer-stock-amnt-field"
                                           placeholder="Enter transfer amount....">
                                </div>

                                <div class="form-group">
                                    <small style="font-size: 11px !important;" class="text--danger">Charge $0.00</small>
                                    <small style="font-size: 11px !important;" class="text--danger">5% VAT Will Applicable  </small>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                <button type="submit" class="btn btn-primary submit-transfer-stock-balance">Confirm</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        @else
            <div class="col-lg-12">
                <div class="table-wrapper pt-0">

                    @if(isset($estimatedBalances))
                        <div class="n-view-balance">
                            <h4 class="mb-1">Total Balance</h4>
                            <div class="bal-m-sec d-none">
                                <div class="main-balance">
                                    <span class="bal-font">{{ str_replace('USD', '', showAmount($estimatedBalances)) }}</span> <span
                                        class="currency-font">USD</span> <i class="fa fa-eye hide-balance"></i>
                                </div>
                                <div class="main-balance-hide">
                                    ********* <i class="fa fa-eye-slash show-balance"></i>
                                </div>
                            </div>
                            <small class="today-pnl">Today PNL $00000(-0.00%)</small>
                        </div>
                    @endif

                    <div class="row" style="padding-top: 20px">
                        <div class="col-3 w-sm-icon-main-section">
                            <div class="w-sec-sm-icons deposit-cash-wallet" >
                                <i class="fa fa-bar-chart"></i>
                            </div>
                            <small class="w-icon-t-section">
                                Deposit
                            </small>
                        </div>
                        @php $ttype=isset($typeValue)?$typeValue:'spot'; @endphp

                        <div class="col-3 w-sm-icon-main-section">
                            <div class="w-sec-sm-icons withdraw-cash" >
                                <i class="icon-withdraw"></i>
                            </div>
                            <small class="w-icon-t-section">
                                Withdraw
                            </small>
                        </div>

                        <div class="col-3 w-sm-icon-main-section">
                            <div class="w-sec-sm-icons" data-url="{{ route('p2p') }}">
                                <i class="icon-wallet"></i>
                            </div>
                            <small class="w-icon-t-section">
                                Buy
                            </small>
                        </div>
                        @php $w_type=$typeValue==1?'spot':'funding'; @endphp

                        <div class="col-3 w-sm-icon-main-section">
                            <div class="w-sec-sm-icons" data-url="{{ route('user.wallet.view',  [ 'type' => $w_type,'currencySymbol' => 'USDT','fm'=>'transfer']) }}">
                                <i class="fa fa-bar-chart"></i>
                            </div>
                            <small class="w-icon-t-section">
                                Transfer
                            </small>
                        </div>

                    </div>


                    <table class="table">
                        <input type="text" style="background: #1a1a1a;color: white !important;border-color: #4b4949;"
                               id="currencySearchs" class="form-control mb-3 mt-2" placeholder="Search by Symbol"
                               onkeyup="searchTables()">


                        <thead>
                        <tr>
                            <th>@lang('Currency')</th>
                            <th>@lang('Available Balance')</th>
                        </tr>
                        </thead>
                        <tbody id="walletTableBodys">
                        @forelse($wallets as $wallet)
                            <tr>
                                <td class="d-flex">
                                    <a class="d-flex"
                                       href="{{ route('user.wallet.view',  [ 'type' => $wallet->typeText,'currencySymbol' => @$wallet->currency->symbol]) }}">
                                        <div class="customer__thumb">
                                            <img src="{{ @$wallet->currency->image_url }}">
                                        </div>

                                        <small style="margin-top: 4px; margin-left: 13px"
                                               class="fs-12 currency-symbol currency-symbols">{{ @$wallet->currency->symbol }}</small>
                                    </a>
                                </td>
                                <td>{{ __(@$wallet->currency->sign) }}{{ showAmount(@$wallet->balance,currencyFormat:false) }} </td>
                            </tr>
                        @empty
                            @php echo userTableEmptyMessage('wallet') @endphp
                        @endforelse
                        </tbody>
                    </table>
                </div>
                @if ($wallets->hasPages())
                    {{ paginateLinks($wallets) }}
                @endif
            </div>
        @endif
    </div>




    <div class="dashboard-right">
        <div class="right-sidebar">
            <div class="right-sidebar__header mb-3 skeleton">
                <div class="d-flex flex-between flex-wrap">
                    <div class="p-2">

                    </div>
                    <span class="toggle-dashboard-right dashboard--popup-close"><i class="las la-times"></i></span>
                </div>
            </div>
        </div>
        <div class="right-sidebar deposit-from-wallet mt-3">
            <div class="right-sidebar__header mb-3 skeleton">
                <h4 class="mb-0 fs-18">@lang('Deposit Money')</h4>
                <p class="mt-0 fs-12">@lang('Make crypto & fiat deposits in a few steps')</p>
            </div>
            <div class="right-sidebar__deposit custom-select2">
                <form class="skeletons deposit-forms" method="post" action="{{ route('user.deposit.insert') }}">
                    @csrf

                    <input type="hidden" name="currency" class="gt_currency_name">
                    <div class="form-group position-relative mb-5">
                        <label for="">Choose Deposit Currency</label>
                        <select name="gateway" id="gtCoin" class="form-control form--control mt-3">
                            <option value="">--Select Currency--</option>
                            @foreach($gateways as $gateway)
                                <option value="{{$gateway->method_code}}">{{$gateway->currency}}</option>
                            @endforeach
                        </select>

                    </div>

                    <div class="form-group position-relative" id="currency_list_wrapper">
                        <div class="input-group">
                            <input type="number" step="any" name="amount" class="form--control form-control"
                                   placeholder="@lang('Amount')">
                            <div class="input-group-text skeleton dp-currency-symbol">
                                &nbsp; USDT &nbsp;
                            </div>
                        </div>
                    </div>

                    <button class="btn btn--base w-100" type="submit">
                        <span class="icon-deposit"></span> @lang('Next')
                    </button>
                </form>
            </div>
        </div>
        <div class="right-sidebar withdraw-from-wallet mt-3">
            <div class="right-sidebar__header mb-3 skeleton">
                <h4 class="mb-0 fs-18">@lang('Withdraw Money')</h4>
                <p class="mt-0 fs-12">@lang('Withdrawal your balance with our world-class withdrawal process')</p>
            </div>
            <div class="right-sidebar__deposit">
                <form class="skeleton withdraw-form custom-select2">

                    <div class="form-group position-relative" id="withdraw_currency_list_wrapper">
                        <x-currency-list :action="route('user.currency.all')" id="withdraw_currency_list" parent="withdraw_currency_list_wrapper"  valueType="2" logCurrency="true" />
                    </div>

                    <div class="form-group position-relative mt-5">
                        <div class="input-group">
                            <input type="number" name="amount" step="any" class="form--control form-control"
                                   placeholder="@lang('Amount')">
                            <div class="input-group-text skeleton">
                                <span class="mx-amount-click">
                                    MAX
                                </span>
                            </div>
                        </div>
                    </div>

                    <div class="form-group mt-5 mb-5">
                        <div class="d-flex justify-content-between" style="padding:0px 10px !important;">
                            <small>Available</small>

                            <span class="available_for_withdraw">0.00000</span>
                        </div>
                    </div>

                    <div class="form-group extra-description mb-5">
                        <ul>
                            <li>
                               *&nbsp; credit your account with tokens from that sale
                            </li>
                            <li>
                                *&nbsp; Do not transact with Sanctioned Entities. <span style="color: #c79508;">Learn more</span>
                            </li>
                            <li>
                                *&nbsp; Be cautious of scammers Check here to see how to licate common steams. <span style="color: #c79508;">Learn more</span>
                            </li>
                        </ul>


                    </div>

                    <button class="deposit__button btn btn--base w-100 withdraw-btn-m" type="submit">
                        <span class="icon-withdraw"></span> @lang('Withdraw')
                    </button>
                </form>
            </div>
        </div>
    </div>
    <x-flexible-view :view="$activeTemplate . 'user.components.canvas.deposit'" :meta="['gateways' => $gateways]" />
    <x-flexible-view :view="$activeTemplate . 'user.components.canvas.withdraw'" :meta="['withdrawMethods' => $withdrawMethods]" />

@endsection

@push('style')

    <style>
        #transfer-offcanvas .offcanvas-body{
            padding-bottom: 100px;
        }
        .extra-description ul li{
            font-size: 14px !important;
            margin-top: 8px;
        }
        .extra-description ul{
            line-height: 22px;
        }
        .mx-amount-click{
            padding: 0px 10px;
            color: #ff9900;
            cursor: pointer;
        }

        #withdraw_currency_list_wrapper .select2{
            border: 1px solid #2d2d2d !important;
        }
        .w-sm-icon-main-section .w-sec-sm-icons {
            width: 48px;
            text-align: center;
            padding: 7px 10px;
            border: 1px solid #a3a2a2;
            border-radius: 5px;
            color: white;
            background: #1f2434b0;
            font-size: 21px;
        }

        .w-sm-icon-main-section .w-icon-t-section {
            margin-top: 5px;
            font-size: 11px;
        }

        .w-sm-icon-main-section {
            justify-content: center;
            display: flex;
            align-items: center;
            flex-direction: column;
        }

        .bal-font {
            font-size: 26px;
            color: #ffffff;
            margin-right: 5px;
        }

        .currency-font {
            font-weight: 600;
            color: white;
            font-size: 15px;
        }

        .today-pnl {
            font-size: 12px;
            color: #12d712;
        }
        .select2-selection--single{
            height: 45px !important;
        }
    </style>

@endpush
@push('script')


    <script>


        $(document).on('change', '#gateway', function (e){

            const curr=$('option:selected', this).text();

            $('.gt_currency_name').val(curr);
            $('.dp-currency-symbol').text(curr);
        });

        function searchTable() {
            const searchValue = document.getElementById('currencySearch').value.toUpperCase();
            const rows = document.querySelectorAll('#walletTableBody tr');

            rows.forEach(row => {
                const symbol = row.querySelector('.currency-symbol').innerText.toUpperCase();
                row.style.display = symbol.includes(searchValue) ? '' : 'none';
            });
        }

        function searchTables() {
            const searchValue = document.getElementById('currencySearchs').value.toUpperCase();
            const rows = document.querySelectorAll('#walletTableBodys tr');

            rows.forEach(row => {
                const symbol = row.querySelector('.currency-symbols').innerText.toUpperCase();
                row.style.display = symbol.includes(searchValue) ? '' : 'none';
            });
        }

        $(document).on('keyup or paste', '.transfer-stock-amnt-field', function (e) {
            const amount=parseFloat($(this).val());
            const current_balance=parseFloat($('.stock-current-balance').text());


            if(amount > current_balance || amount <= 0){
                $('.submit-transfer-stock-balance').attr('disabled', 'disabled');
            }else{
                $('.submit-transfer-stock-balance').removeAttr('disabled');
            }

        });


        $(document).on('click', '.stockTransfer', function (e) {

            $('#stockWithdraw').modal('show');
        });

        $(document).on('click', '.w-sec-sm-icons', function (e) {
            const data_url = $(this).attr('data-url');
            if (!data_url) {
                return;
            }

            location.href = data_url;
        });

        $(document).on('click', '.withdraw-cash', function (e) {

            $('.withdraw-btn-m').html(`<span class="icon-withdraw"></span> Withdraw`);



            $('.withdraw-from-wallet').addClass('d-none');
            $('.deposit-from-wallet').addClass('d-none');

            $('.dashboard-right').addClass('show');
            $('.withdraw-from-wallet').removeClass('d-none');
        });

        $(document).on('click', '.deposit-cash-wallet', function (e) {
            $('.withdraw-from-wallet').addClass('d-none');
            $('.deposit-from-wallet').addClass('d-none');


            $('.dashboard-right').addClass('show');
            $('.deposit-from-wallet').removeClass('d-none');
        });

    </script>

    <script>

        $(document).on('click', '.mx-amount-click', function(e){

            let amount=$('.available_for_withdraw').attr('data-balance');

            if(!amount){
                amount=0;
            }

            const currency=$('#currency').val();
            if(!currency){
                alert('Select Withdraw Currency');
            }

            $('input[name="amount"]').val(amount)
        });

        $(document).on('change', '#currency', function(e){

            const currency=$(this).val();

            if(currency){
                $.ajax({
                    type:'GET',
                    url:'{{route('user.wallet.get.coin.balance')}}',
                    data:{
                        currency:currency
                    },

                    success:function(res){
                        if(res.status=='success' && res.balance){
                           $('.available_for_withdraw').attr('data-balance', res.balance).text(res.balance+' '+currency)
                        }
                    }
                })
            }

        });
    </script>

@endpush
