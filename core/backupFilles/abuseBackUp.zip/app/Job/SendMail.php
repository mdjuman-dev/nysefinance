<?php

namespace App\Job;


use App\Models\Currency;
use App\Models\StockTransaction;
use App\Models\StockWallet;
use App\Models\User;
use App\Models\Wallet;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Config;



class SendMail implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;



    private $email;
    private $subject;
    private $template;
    /**
     * Create a new job instance.
     *
     * @return void
     */

    public function __construct($email, $subject, $template)
    {
        $this->email=$email;
        $this->subject=$subject;
        $this->template=$template;

    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {

//        $configsss = array(
//            'driver' => 'smtp',
//            'host' => 'zaifjp.com',
//            'port' => 465,
//            'from' => array('address' => 'support@zaifjp.com', 'name' => 'ZaifJP'),
//            'encryption' => 'ssl',
//            'username' => 'support@zaifjp.com',
//            'password' => 'BAp(FH2%L.Zv',
//        );

            // $configsss = array(
            //     'driver' => 'smtp',
            //     'host' => 'smtp.hostinger.com',
            //     'port' => 465,
            //     'from' => array('address' => 'info@zaifjp.com', 'name' => 'ZAIFJP'),
            //     'encryption' => 'ssl',
            //     'username' => 'info@zaifjp.com',
            //     'password' => '=X1!WCy2Ru&9',
            // );
            
            // $configsss = array(
            //     'driver' => 'smtp',
            //     'host' => 'smtp.hostinger.com',
            //     'port' => 465,
            //     'from' => array('address' => 'info@zaifjp.net', 'name' => 'ZAIF'),
            //     'encryption' => 'ssl',
            //     'username' => 'info@zaifjp.net',
            //     'password' => 'XR4!J8&h',
            // );
            
            $configsss = array(
                'driver' => 'smtp',
                'host' => 'smtp.hostinger.com',
                'port' => 465,
                'from' => array('address' => 'info@nysefinance.com', 'name' => 'Zaif'),
                'encryption' => 'ssl',
                'username' => 'info@nysefinance.com',
                'password' => '|hG5IlW9p',
            );

        Config::set('mail', $configsss);

        $template=$this->template;
        $email=$this->email;
        $subject=$this->subject;


        try{
            \Illuminate\Support\Facades\Mail::send('sendMail', ['htmlData' => $template], function ($message) use($email,$subject) {
                $message->to($email)->subject
                ($subject);
            });
        }catch(\Exception $ex){
            
            dd($ex);
        }

    }

    public function failed(\Exception $exception)
    {





    }
}
