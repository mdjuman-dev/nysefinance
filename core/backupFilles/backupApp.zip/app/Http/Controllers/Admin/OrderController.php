<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Order;
use App\Models\Trade;
use Illuminate\Http\Request;


class OrderController extends Controller
{
    public function open(Request $request)
    {
        $pageTitle = "Open Order";
        $orders    = $this->orderData('open', $request->date_range);

        return view('admin.order.list', compact('pageTitle', 'orders'));
    }
    public function history()
    {
        $pageTitle = "Order History";
        $orders    = $this->orderData();
        return view('admin.order.list', compact('pageTitle', 'orders'));
    }

    protected function orderData($scope = null, $date_range=null)
    {
        $query = Order::filter(['order_side', 'user_id', 'status'])->searchable(['pair:symbol', 'pair.coin:symbol', 'pair.market.currency:symbol'])->with('pair', 'pair.coin', 'pair.market.currency')->orderBy('id', 'desc');
        if ($scope) {
            $query->$scope();
        }

        if ($date_range) {
            if ($date_range == 'today') {
                $query->whereDate('created_at', now());
            } elseif ($date_range == 'yesterday') {
                $query->whereDate('created_at', now()->subDay());
            } elseif ($date_range == 'weekly') {
                $query->whereBetween('created_at', [now()->startOfWeek(), now()->endOfWeek()]);
            } elseif ($date_range == 'monthly') {
                $query->whereMonth('created_at', now()->month)
                    ->whereYear('created_at', now()->year);
            } elseif ($date_range == 'last_year') {
                $query->whereYear('created_at', now()->subYear()->year);
            }
        }

        return $query->paginate(getPaginate());
    }

    public function tradeHistory()
    {
        $pageTitle = "Trade History";
        $trades    = Trade::filter(['trade_side', 'trader_id'])->searchable(['order.pair:symbol', 'order.pair.coin:symbol', 'order.pair.market.currency:symbol'])->with('order.pair', 'order.pair.coin', 'order.pair.market.currency')->orderBy('id', 'desc')->paginate(getPaginate());
        return view('admin.order.trade_history', compact('pageTitle', 'trades'));
    }
}
