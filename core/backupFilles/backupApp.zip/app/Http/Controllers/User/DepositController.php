<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use App\Models\Deposit;
use Illuminate\Http\Request;

class DepositController extends Controller
{

    public function pendingRequest()
    {

        $pageTitle='Deposit Request';
        $deposits=Deposit::where('user_id', auth()->user()->id)->orderByDesc('created_at')->paginate(getPaginate());

        return view('Template::user.deposit.request', compact('pageTitle', 'deposits'));




    }

    public function checkOutPage($id)
    {

        $deposit=Deposit::where('id', $id)->where('user_id', auth()->user()->id)->firstOrFail();

        if($deposit->status !='2'){
            $notifye[] = ['error', 'This deposit request is not pending yet.'];
            return redirect()->back()->withNotify($notifye);
        }


        $crypto_address=$deposit->address;

        $deposit_id=$deposit->id;

        $amount=$deposit->amount;

        return view('crypto_pay', compact('crypto_address','deposit_id','amount'));


    }
}
