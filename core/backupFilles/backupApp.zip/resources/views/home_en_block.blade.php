<div class="container">

    <style>
        @import url('https://fonts.googleapis.com/css?family=Montserrat:300');
        body{
            background: #3498DB;
            color: #fff;
            font-family: 'Montserrat', sans-serif;
            font-size: 16px;
        }
        h1{
            font-size: 30vh;
        }
        h2 span{
            font-size: 4rem;
            font-weight: 600;
        }
        a:link, a:visited{
            text-decoration: none;
            color: #fff;
        }
        h3 a:hover{
            text-decoration: none;
            background: #fff;
            color: #3498DB;
            cursor: pointer;
        }
        .container{
            padding: 100px 100px !important;
        }

    </style>

    <h1>:(</h1><br>
    <h2>A <span>404</span> error occured, Page not found, check the URL and try again.</h2><br><br>
</div>
