<?php

namespace App\Http\Controllers;

use App\Job\SendStateMentEmail;
use App\Models\StockMember;
use App\Models\User;
use App\Models\WeeklyStatement;
use Illuminate\Http\Request;

class StatementController extends Controller
{


    public function sendStatement(){


        $fixDate=now();

        $ableDateData=WeeklyStatement::whereDate('next_date', $fixDate)->first();

        if($ableDateData){

            $stockMembersIds=StockMember::where('status','approve')->pluck('user_id');

            $all_users=User::where('status', '1')->whereIn('id', $stockMembersIds)->select(['id','firstname','lastname','email'])->get();

            if($all_users->isNotEmpty()){

                foreach($all_users as $usr){
                    SendStateMentEmail::dispatch($usr->id, $usr->email, $usr->fullname);
                }

            }

            $ableDateData->next_date=now()->addWeek();
            $ableDateData->save();

        }


    }




}
