@extends('admin.layouts.app')
@section('panel')

    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-body p-0">
                    <div class="table-responsive--md  table-responsive">
                        <table class="table table--light style--two">
                            <thead>
                            <tr>
                                <th>@lang('User')</th>
                                <th>@lang('Amount')</th>
                                <th>@lang('Type')</th>
                                <th>@lang('For')</th>
                                <th>@lang('Remark')</th>
                                <th>@lang('Date')</th>
                            </tr>
                            </thead>
                            <tbody>
                            @forelse($interests as $interest)
                                <tr>
                                    <td>
                                        {{$interest->user->fullname}}
                                        <br>
                                        {{$interest->user->email}}
                                    </td>
                                    <td>
                                        {{$interest->amount}} (USDT)
                                    </td>
                                    <td>
                                        Interest
                                    </td>
                                    <td>
                                        {{$interest->user_stock->product->name}}
                                    </td>
                                    <td>
                                        {{$interest->remark}}
                                    </td>
                                    <td>
                                        {{$interest->created_at->format('d-m-Y h:i A')}}
                                    </td>
                                </tr>
                            @empty
                                <tr>
                                    <td class="text-muted text-center" colspan="100%">No Data Available</td>
                                </tr>
                            @endforelse
                            </tbody>
                        </table>
                    </div>
                </div>
                @if ($interests->hasPages())
                    <div class="card-footer py-4">
                        {{ paginateLinks($interests) }}
                    </div>
                @endif
            </div>
        </div>
    </div>

@endsection

@push('breadcrumb-plugins')
    <a href="{{route('admin.stock.index')}}" class="float-right btn btn-primary">Back</a>
@endpush

@push('script')

@endpush
