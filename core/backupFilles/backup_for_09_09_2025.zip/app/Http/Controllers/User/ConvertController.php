<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use App\Models\Currency;
use App\Models\Transaction;
use App\Models\Wallet;
use GuzzleHttp\Client;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class ConvertController extends Controller
{
    public function convert($type = null)
    {
        $data['pageTitle'] = 'Stock Wallet';

        $data['currencies'] = Currency::orderByDesc('created_at')->get();


        return view('Template::user.wallet.convert', $data);
    }


    public function convertBalance(Request $request)
    {

        $wallet = Wallet::where('user_id', auth()->user()->id)->where('currency_id', $request->currency_id)->where('wallet_type', '1')->first();

        if (!$wallet) {
            return response()->json(['status' => 'failed', 'message' => 'Wallet not found']);
        }

        return response()->json(['status' => 'success', 'balance' => number_format($wallet->balance, 4)]);

    }


private function getCoinGeckoId($symbol)
{
    $map = [
        'BTC' => 'bitcoin',
        'ETH' => 'ethereum',
        'BNB' => 'binancecoin',
        'USDT' => 'tether',
        'USDC' => 'usd-coin',
        'SOL' => 'solana',
        'XRP' => 'ripple',
        'DOGE' => 'dogecoin',
        'TRX' => 'tron',
        'ADA' => 'cardano',
        'MATIC' => 'matic-network',
        'SHIB' => 'shiba-inu',
        'DOT' => 'polkadot',
        'LTC' => 'litecoin',
        'BCH' => 'bitcoin-cash',
        'AVAX' => 'avalanche-2',
        'XLM' => 'stellar',
        'LINK' => 'chainlink',
        'ATOM' => 'cosmos',
        'NEAR' => 'near',
        'FIL' => 'filecoin',
        'PEPE' => 'pepe',
        'WBTC' => 'wrapped-bitcoin',
        'DAI' => 'dai',
        'OP' => 'optimism',
        'ARB' => 'arbitrum',
        'APT' => 'aptos',
        'INJ' => 'injective',
        'LDO' => 'lido-dao',
        'IMX' => 'immutable-x',
        'GRT' => 'the-graph',
        'AAVE' => 'aave',
        'SAND' => 'the-sandbox',
        'MANA' => 'decentraland',
        'FTM' => 'fantom',
        'EGLD' => 'multiversx',
        'CRO' => 'crypto-com-chain',
        'KAVA' => 'kava',
        'QNT' => 'quant-network',
        'RUNE' => 'thorchain',
        'ALGO' => 'algorand',
        'HBAR' => 'hedera-hashgraph',
        'TWT' => 'trust-wallet-token',
        // Add more as needed
    ];

    $symbol = strtoupper($symbol);
    return $map[$symbol] ?? null;
}



public function convertRate(Request $request)
{
    if (!$request->from_coin || !$request->to_coin) {
        return response()->json(['status' => 'failed', 'message' => 'Please enter a valid coin']);
    }

    $currency = Currency::where('symbol', strtoupper($request->from_coin))->first();
    if (!$currency) {
        return response()->json(['status' => 'failed', 'message' => 'Invalid coin']);
    }

    $wallet = Wallet::where('user_id', auth()->user()->id)
        ->where('currency_id', $currency->id)
        ->where('wallet_type', '1')
        ->first();

    if (!$wallet) {
        return response()->json(['status' => 'failed', 'message' => 'Wallet not found']);
    }

    $fromId = $this->getCoinGeckoId($request->from_coin);
    $to = strtolower($request->to_coin);

    if (!$fromId || !$to) {
        return response()->json(['status' => 'failed', 'message' => 'Invalid coin symbol']);
    }

    try {
        $url = "https://api.coingecko.com/api/v3/simple/price?ids={$fromId}&vs_currencies={$to}";
        $client = new Client();
        $response = $client->get($url);
        $data = json_decode($response->getBody(), true);

        if (!isset($data[$fromId][$to])) {
            return response()->json(['status' => 'failed', 'message' => 'Conversion rate not found']);
        }

        $price = $data[$fromId][$to];

        return response()->json([
            'status' => 'success',
            'convert_rate' => number_format($price, 8),
            'available_amount' => number_format($wallet->balance, 4),
        ]);
    } catch (\Exception $e) {
        return response()->json([
            'status' => 'failed',
            'message' => 'Something went wrong',
            'error' => $e->getMessage()
        ]);
    }
}



    // function convertRate(Request $request)
    // {

    //     if (!$request->from_coin || !$request->to_coin) {
    //         return response()->json(['status' => 'failed', 'message' => 'Please enter a valid coin']);
    //     }

    //     $currency = Currency::where('symbol', $request->from_coin)->first();
    //     if (!$currency) {
    //         return response()->json(['status' => 'failed', 'message' => 'Please enter a valid coin']);
    //     }

    //     $wallet = Wallet::where('user_id', auth()->user()->id)->where('currency_id', $currency->id)->where('wallet_type', '1')->first();

    //     if (!$wallet) {
    //         return response()->json(['status' => 'failed', 'message' => 'Wallet not found']);
    //     }


    //     $mergeCoin = strtoupper($request->from_coin . $request->to_coin);

    //     try {
    //         $URL="https://api.binance.com/api/v3/ticker/price?symbol=$mergeCoin";
    //         $client = new Client();
    //         $response = $client->get($URL);
    //         $data = json_decode($response->getBody(), true);
    //         $price = $data['price'];
            
    //         // dd($price);

    //         return response()->json(['status' => 'success', 'convert_rate' => number_format($price, 4), 'available_amount' => number_format($wallet->balance, 4)]);
    //     } catch (\Exception $e) {
    //         dd($e);
    //         return response()->json(['status' => 'failed', 'message' => 'Something went wrong']);
    //     }

    // }

    public function convertAmount(Request $request)
    {

        DB::beginTransaction();


        try {

            $fromCurrency = Currency::where('symbol', $request->from_coin)->first();
            $toCurrency = Currency::where('symbol', $request->to_coin)->first();
            if (!$fromCurrency || !$toCurrency) {
                return redirect()->back()->with('error', 'Currency not found');
            }

            $user = auth()->user();

            $fromWallet = Wallet::where('user_id', auth()->user()->id)->where('currency_id', $fromCurrency->id)->where('wallet_type', '1')->first();
            $toWallet = Wallet::where('user_id', auth()->user()->id)->where('currency_id', $toCurrency->id)->where('wallet_type', '1')->first();

            if (!$fromWallet || !$toWallet) {
                return redirect()->back()->with('error', 'Wallet not found');
            }


            $mergeCoin = strtoupper($request->from_coin . $request->to_coin);
            $client = new Client(['verify' => false]);
            $response = $client->get('https://api.binance.com/api/v3/ticker/price', [
                'query' => ['symbol' => $mergeCoin]
            ]);
            $data = json_decode($response->getBody(), true);
            $convert_rate = $data['price'];

            $toAmount = $request->fromAmount * $convert_rate;


            if ($fromWallet->balance < $request->fromAmount) {
                return redirect()->back()->with('error', 'Insufficient balance');
            }


            //From Wallet
            $deductAmount = $fromWallet->balance - $request->fromAmount;
            $fromWallet->balance = $deductAmount;
            $fromWallet->save();

            //To Wallet
            $addedAmount = $toWallet->balance + $toAmount;
            $toWallet->balance = $addedAmount;
            $toWallet->save();


            //Added
            $added_transaction = new Transaction();
            $added_transaction->user_id = $user->id;
            $added_transaction->wallet_id = $toWallet->id;
            $added_transaction->amount = $addedAmount;
            $added_transaction->post_balance = $addedAmount;
            $added_transaction->charge = 0;
            $added_transaction->trx_type = '+';
            $added_transaction->details = $addedAmount . ' ' . $request->to_coin . ' Added From' . $request->fromAmount . ' ' . $request->from_coin;
            $added_transaction->trx = Str::random(13);
            $added_transaction->remark = 'transfer';
            $added_transaction->save();

            //Minus
            $transaction = new Transaction();
            $transaction->user_id = $user->id;
            $transaction->wallet_id = $fromWallet->id;
            $transaction->amount = $request->fromAmount;
            $transaction->post_balance = $request->fromAmount;
            $transaction->charge = 0;
            $transaction->trx_type = '-';
            $transaction->details = $request->fromAmount . ' ' . $request->from_coin . ' = ' . $addedAmount . ' ' . $request->to_coin;
            $transaction->trx = Str::random(12);
            $transaction->remark = 'transfer';
            $transaction->save();

            DB::commit();

            return redirect()->back()->with('success', 'Converted from ' . $fromWallet->symbol . ' to ' . $toWallet->symbol);
        }catch (\Exception $e) {
            DB::rollBack();

            return redirect()->back()->with('error', 'Something went wrong');
        }

    }
}
