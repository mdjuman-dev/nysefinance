<?php

namespace App\Http\Controllers;

use App\Models\Order;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class FutureTradeController extends Controller
{
    public function orderList(Request $request, $symbol)
    {
        $validator = Validator::make($request->all(), [
            'status' => 'nullable|in:all,open,canceled,completed'
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => $validator->errors()->all()
            ]);
        }

        $query = Order::with('pair')->where('user_id', auth()->id());

        if ($request->status && $request->status != 'all') {
            $scope = $request->status;
            $query->$scope();
        }

        $orders = $query->orderBy('id', 'desc')->where('type', 'future')->take(20)->get();

        return response()->json([
            'success' => true,
            'orders'  => $orders
        ]);
    }
}
