@extends('admin.layouts.app')
@section('panel')

    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-body p-0">
                    <div class="table-responsive--md  table-responsive">
                        <table class="table table--light style--two">
                            <thead>
                            <tr>
                                <th>@lang('User')</th>
                                <th>@lang('Amount')</th>
                                <th>@lang('Type')</th>
                                <th>@lang('For')</th>
                                <th>@lang('Remark')</th>
                                <th>@lang('Date')</th>
                            </tr>
                            </thead>
                            <tbody>
                            @forelse($transactions as $transaction)
                                <tr>
                                    <td>
                                        {{$transaction->user->fullname}}
                                        <br>
                                        {{$transaction->user->email}}
                                    </td>
                                    <td>
                                        {{$transaction->amount}} (USDT)
                                    </td>
                                    <td>
                                        @if($transaction->type=='sell')
                                            <span class="badge badge--danger">Sell</span>
                                        @else
                                            <span class="badge badge--success">Buy</span>
                                        @endif

                                    </td>
                                    <td>
                                        @if($transaction->stock_type=='fix')
                                            <span class="badge badge--danger">Mutual Fund</span>
                                        @else
                                            <span class="badge badge--success">Live Market</span>
                                        @endif
                                    </td>
                                    <td>
                                        {{$transaction->remark}}
                                    </td>
                                    <td>
                                        {{$transaction->created_at->format('d-m-Y h:i A')}}
                                    </td>
                                </tr>
                            @empty
                                <tr>
                                    <td class="text-muted text-center" colspan="100%">No Data Available</td>
                                </tr>
                            @endforelse
                            </tbody>
                        </table>
                    </div>
                </div>
                @if ($transactions->hasPages())
                    <div class="card-footer py-4">
                        {{ paginateLinks($transactions) }}
                    </div>
                @endif
            </div>
        </div>
    </div>

@endsection

@push('breadcrumb-plugins')
    <a href="{{route('admin.stock.index')}}" class="float-right btn btn-primary">Back</a>
@endpush

@push('script')

@endpush
