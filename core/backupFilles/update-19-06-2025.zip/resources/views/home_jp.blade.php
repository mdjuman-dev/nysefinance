<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1,minimum-scale=1.0">


    <title>暗号資産・販売所 - Zaif</title>


    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="{{asset('core/public/en/css/bootstrap.min.css')}}">
    <link rel="stylesheet" href="{{asset('core/public/en/css/typeahead.js-bootstrap.css')}}">
    <link rel="stylesheet" href="{{asset('core/public/en/css/style.css')}}">
    <link rel="stylesheet" href="{{asset('core/public/en/css/baseaccount.css')}}">
    <link rel="stylesheet" href="{{asset('core/public/en/css/font-awesome.min.css')}}">
    <link rel="stylesheet" href="{{asset('core/public/en/css/swiper.min.css')}}">


    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin="">
    <link href="https://fonts.googleapis.com/css2?family=Noto+Sans+JP:wght@400;500;700&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="{{asset('core/public/en/css/style.css')}}">
    <link rel="stylesheet" href="{{asset('core/public/en/css/index.css')}}">

    <link rel="stylesheet" href="{{asset('core/public/en/css/logo-Index.css')}}">
    <link rel="stylesheet" href="{{asset('core/public/en/css/swiper.min.css')}}">
    <link rel="stylesheet" href="{{asset('core/public/en/css/animate.css')}}">
    <script src="{{asset('core/public/en/js/wow.min.js')}}"></script>

    <!--LP-->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Crimson+Text" rel="stylesheet">


    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
    <!-- Latest compiled and minified JavaScript -->
    <script src="{{asset('core/public/en/js/jquery-1.11.3.min.js')}}"></script>
    <script src="{{asset('core/public/en/js/jquery.cookie.js')}}"></script>
    <script src="{{asset('core/public/en/js/bootstrap.min.js')}}"></script>
    <script src="{{asset('core/public/en/js/typeahead.bundle.min.js')}}"></script>
    <script src="{{asset('core/public/en/js/jquery.toaster.min.js')}}"></script>
    <script src="{{asset('core/public/en/js/assets.min.js')}}"></script>
    <script src="{{asset('core/public/en/js/jquery.easing.js')}}"></script>
    <script src="{{asset('core/public/en/js/swiper.min.js')}}"></script>


    <script src="{{asset('core/public/en/js/bundle.min.js')}}"></script>
    <script src="{{asset('core/public/en/js/bundle.tracing.min.js')}}"></script>



    <script src="{{asset('core/public/en/js/swiper.min.js')}}"></script>


    <script src="{{asset('core/public/en/js/mathcontext.js')}}"></script>
    <script src="{{asset('core/public/en/js/bigdecimal.js')}}"></script>
    <script src="{{asset('core/public/en/js/jquery.color.js')}}"></script>
    <script src="{{asset('core/public/en/js/swiper-bundle.min.js')}}"></script>
    <script src="{{asset('core/public/en/js/swiper-bundle.min.js')}}"></script>
    <script src="{{asset('core/public/en/js/page-visibility.js')}}"></script>
    <script src="{{asset('core/public/en/js/currency_list.min.js')}}"></script>

    <script>
        new WOW().init();
    </script>


    <link rel="apple-touch-icon" href="{{asset('core/public/en/images/apple-touch-icon.png')}}">
    <link rel="apple-touch-icon" sizes="72x72" href="{{asset('core/public/en/images/apple-touch-icon-72x72.png')}}">
    <link rel="apple-touch-icon" sizes="76x76" href="{{asset('core/public/en/images/apple-touch-icon-76x76.png')}}">
    <link rel="apple-touch-icon" sizes="114x114" href="{{asset('core/public/en/images/apple-touch-icon-114x114.png')}}">
    <link rel="apple-touch-icon" sizes="120x120" href="{{asset('core/public/en/images/apple-touch-icon-120x120.png')}}">
    <link rel="apple-touch-icon" sizes="144x144" href="{{asset('core/public/en/images/apple-touch-icon-144x144.png')}}">
    <link rel="apple-touch-icon" sizes="152x152" href="{{asset('core/public/en/images/apple-touch-icon-152x152.png')}}">

</head>


<body class="column1">



<div id="wrapper">


    <header class="header" id="header">
        <nav class="navbar navbar-inverse navbar-fixed-top yamm">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <h1 id="logo"><a class="navbar-brand main-title" href="/"><img src="{{asset('core/public/en/images/zaif_blue.svg')}}"
                                                                               alt="Zaif 暗号資産取引所"></a></h1>
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar"
                        aria-expanded="false" aria-controls="navbar">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div id="navbar" class="navbar-collapse collapse navbar-right">
                <ul class="nav navbar-nav">
                    <li style="display: none !important;"><a href="#"></a></li>

                    Offical Website:





                    <li style="display: none !important;"><a href="#">e</a></li>


                    <li  class="dropdown yamm-fw">

                        <a class="dropdown-toggle" href="#" data-toggle="dropdown">Official Website<b class="caret"></b></a>
                        <ul class="dropdown-menu dropdown-service">
                            <li class="nav-service">
                                <div class="nav-service-list">
                                    <ul class="nav-service-listUp">
                                        <li><a href="www.zaif.jp">Zaif</a> </li>
                                        <li><a href="www.zaifjp.com">ZaifJP</a></li>
                                        <li><a href="www.corp.zaif.jp">Corp Zaif</a></li>
                                        <li><a href="www.zaif-nft.io">Zaif NFT</a></li>
                                    </ul>
                                </div>
                            </li>
                        </ul>
                    </li>

                    @if(!auth()->user())
                    <li><a href="{{route('user.login')}}" class="text-skyb">Login</a></li>
                    <li><a href="{{route('user.register')}}" class="text-skyb cv-header" data-toggle="header_tooltip"
                           data-placement="bottom" title="Click here to start trading">Register</a></li>
                    @else
                        <li><a href="{{route('user.home')}}" class="text-skyb"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Dashboard</font></font></a></li>

                    @endif
                    <li></li>
                    <li></li>


                    <li class="dropdown icon-container only_pc">
                        <a href="javascript:void(0)" class="dropdown-toggle text-skyb" data-toggle="dropdown"
                           role="button" aria-haspopup="true" aria-expanded="false">
                            <img src="{{asset('core/public/en/images/lang.png')}}" alt="language" class="icon-button">
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="link-language" href="{{route('home.jp')}}" data-locale="ja">Japanese</a></li>
                            <li role="separator" class="divider only_pc"></li>
                            <li><a class="link-language" href="{{route('home.en')}}" data-locale="en">English</a></li>
                        </ul>
                    </li>

                    <li class="only_sp"><a href="#contact" >Contact Support</a></li>
                    <li class="dropdown only_sp">
                        <a href="javascript:void(0)" class="dropdown-toggle text-skyb" data-toggle="dropdown"
                           role="button" aria-haspopup="true" aria-expanded="false">Language <span class="caret"></span></a>
                        <ul class="dropdown-menu">
                            <li><a class="link-language" href="/jp" data-locale="ja">Japanese</a></li>
                            <li role="separator" class="divider only_pc"></li>
                            <li><a class="link-language" href="/en" data-locale="en">English</a></li>
                        </ul>
                    </li>
                </ul>
            </div><!-- /.navbar-collapse -->
        </nav>
        <script>
            $(function () {
                $('[data-toggle="header_tooltip"]').tooltip();
            });
        </script>
    </header>


    <div id="main" class="clearfix">


        <main class="top_page">
            <section class="kv_section">
                <div class="kv">
                    <div class="text">
                        <p class="catchcopy">
                            <span class="emphasis">暗号資産</span>で
                            <br>
                            資産形成なら<img src="{{asset('core/public/en/images/zaif.png')}}" alt="zaif">
                        </p>
                        <p class="description">
                            少額からでも購入できるので、投資を始めやすい！
                            <br>
                            暗号資産投資をきっかけに大人の資産形成をはじめませんか？
                        </p>
                        <a href="https://apk.zaifjp.com/file/zaif-update-1.1.apk" class="register_button">
                            <p>
                                <span>APKをダウンロード</span><img src="{{asset('core/public/en/images/right_circle.svg')}}" alt="会員登録">
                            </p>
                        </a>
                    </div>
                    <div class="image">
                        <img src="{{asset('core/public/en/images/mock_sp.png')}}" alt="スマートフォンアプリ" loading="lazy">
                    </div>
                </div>
                <div class="coins">
                    <ul class="currency-list"></ul>
                </div>
            </section>

            <section class="banners_section">
                <div class="swiper banner_swiper">
                    <div class="swiper-wrapper">
                        <div class="swiper-slide">
                            <a href="#"
                               id="kv-20250110_snpt_buy_cp2">
                                <img src="{{asset('core/public/en/images/banner_snpt_buy2.pn')}}g" alt="SNPT上場記念！第2弾購入キャンペーン">
                            </a>
                        </div>
                        <div class="swiper-slide">
                            <a href="#">
                                <img src="{{asset('core/public/en/images/banner_zpg_zres.png')}}" alt="ZPG取記念！コイン積立キャンペーン">
                            </a>
                        </div>
                        <div class="swiper-slide">
                            <a href="#" id="kv-20240410_staking_appeal">
                                <img src="{{asset('core/public/en/images/banner_staking_appel2.png')}}" alt="ステーキングで新しい資産形成">
                            </a>
                        </div>
                        <div class="swiper-slide">
                            <a href="#" id="kv-20231220_doc_mobile_app">
                                <img src="{{asset('core/public/en/images/banner_app_202404.png')}}" alt="アプリリニューアル">
                            </a>
                        </div>
                        <div class="swiper-slide">
                            <a href="#" id="kv-20231220_zaifcard">
                                <img src="{{asset('core/public/en/images/banner_zaif_card_202404.png')}}" alt="Zaifカード">
                            </a>
                        </div>
                        <div class="swiper-slide">
                            <a href="#"
                               id="kv-20231220_otegaru_manga">
                                <img src="{{asset('core/public/en/images/banner_otegaru_manga_202404.png')}}" alt="自動売買おてがるトレード">
                            </a>
                        </div>
                        <div class="swiper-slide">
                            <a href="#"
                               id="kv-20231220_cs\manage_notice_01">
                                <img src="{{asset('core/public/en/images/banner_cs_notice_01.png')}}" alt="情報更新の入力案内">
                            </a>
                        </div>
                        <div class="swiper-slide">
                            <a href="#"
                               id="kv-20231220_cs_manage_notice_02">
                                <img src="{{asset('core/public/en/images/banner_cs_notice_02.png')}}" alt="犯罪への注意喚起">
                            </a>
                        </div>
                    </div>
                    <div class="controls only_pc">
                        <div class="swiper_pagination"></div>
                        <div class="swiper_prev">
                            <img src="{{asset('core/public/en/images/prev.svg')}}" alt="previous">
                        </div>
                        <div class="swiper_next">
                            <img src="{{asset('core/public/en/images/next.svg')}}" alt="next">
                        </div>
                    </div>
                </div>
            </section>

            <section class="features_section">
                <h2>Zaifだからできること</h2>

                <div class="articles">
                    <article>
                        <div class="text">
                            <h4># Point 1</h4>
                            <h3>
                                <p>手数料無料で</p>
                                <p><span class="emphasis">小額から始められる投資</span></p>
                            </h3>
                            <p class="description">
                                Zaifのかんたん売買（販売所）では販売手数料無料で、数百円単位から暗号資産を売買することができるため、まずはお試しで投資を始めてみたいという人にも安心です。
                            </p>
                        </div>
                        <div class="image">
                            <img src="{{asset('core/public/en/images/feature_1.jpg')}}" alt="手数料無料で小額から始められる投資" loading="lazy">
                        </div>
                    </article>

                    <article>
                        <div class="text">
                            <h4># Point 2</h4>
                            <h3>
                                <p><span class="emphasis">充実の取扱暗号資産</span>とサービス</p>
                            </h3>
                            <p class="description">
                                ビットコインを始めとする26種の暗号資産の売買が行えます。各暗号資産の特徴、開発思想、用途を知って応援したい暗号資産に投資してみるといった楽しみ方もあります。
                                <br>
                                また、積立や自動売買等のサービスにも対応しているので自分の投資スタイルに合わせたサービスを選べます。
                            </p>
                        </div>
                        <div class="image">
                            <img src="{{asset('core/public/en/images/feature_2.jpg')}}" alt="充実の取扱暗号資産とサービス" loading="lazy">
                        </div>
                    </article>

                    <article>
                        <div class="text">
                            <h4># Point 3</h4>
                            <h3>
                                <p>解説がちゃんとあるから</p>
                                <p><span class="emphasis">初心者でも続けられる</span></p>
                            </h3>
                            <p class="description">
                                暗号資産について知らなくても、解説記事やニュースから徐々に学べるので途中でくじけずに投資を続けられます。
                            </p>
                        </div>
                        <div class="image">
                            <img src="{{asset('core/public/en/images/feature_3.jpg')}}" alt="解説がちゃんとあるから初心者でも続けられる"
                                 loading="lazy">
                        </div>
                    </article>
                </div>


                <a href="{{asset('core/public/Zaif-Exchanges.pdf')}}" target="_blank" class="register_button">
                    <p>
                        <span><font style="vertical-align: inherit;">
                                <font style="vertical-align: inherit;">事業計画</font></font></span>
                        <img src="/core/public/en/images/right_circle.svg" alt="Membership Registration">
                    </p>
                </a>

            </section>

            <section class="pickup_services_section">
                <article>
                    <h3>
                        <p><span class="emphasis">スマホ一つ・片手操作</span>でどこでも、<br class="only_pc">かんたんに暗号資産取引を。
                        </p>
                    </h3>
                    <div class="image">
                        <img src="{{asset('core/public/en/images/sp_app.jpg')}}" alt="スマートフォンアプリ" loading="lazy">
                    </div>

                </article>

                <article>
                    <h3>
                        <p><span class="emphasis">Zaifカードは便利に</span>お取引！<br
                                class="only_pc">使えば使うほど<span class="emphasis">ビットコイン</span>がもらえる</p>
                    </h3>
                    <div class="image">
                        <img src="{{asset('core/public/en/images/zaif_card.jpg')}}" alt="Zaifカード" loading="lazy">
                    </div>
                    <div class="links">
                        <a href="#" class="application_button">
                            <p>
                                <span>お申し込みはこちら</span><img src="{{asset('core/public/en/images/right_circle_blue.svg')}}" alt="申し込み">
                            </p>
                        </a>
                    </div>
                </article>
            </section>

            <section class="steps_section">
                <h2>取引開始までのステップ</h2>

                <div class="contents">
                    <div class="steps">
                        <ol>
                            <li>
                                <div class="icon">
                                    <img src="{{asset('core/public/en/images/step_1.png')}}" alt="口座開設" loading="lazy">
                                </div>
                                <div class="step_label">
                                    <p class="title">1.口座開設</p>
                                    <p class="description">
                                        メールアドレスとパスワードを設定してアカウントを開設
                                    </p>
                                </div>
                            </li>
                            <li>
                                <div class="icon">
                                    <img src="{{asset('core/public/en/images/step_2.png')}}" alt="本人認証" loading="lazy">
                                </div>
                                <div class="step_label">
                                    <p class="title">2.本人確認</p>
                                    <p class="description">
                                        口座を開設するにあたって必要な本人情報を入力スマホ又は郵送で本人確認書類を提出
                                    </p>
                                </div>
                            </li>
                            <li>
                                <div class="icon">
                                    <img src="{{asset('core/public/en/images/step_3.png')}}" alt="入金" loading="lazy">
                                </div>
                                <div class="step_label">
                                    <p class="title">3.入金</p>
                                    <p class="description">
                                        取引の資金をZaifの自分のアカウントに入金して準備完了！
                                    </p>
                                </div>
                            </li>
                        </ol>
                    </div>

                    <div class="cta">
                        <img src="{{asset('core/public/en/images/feature_1.jpg')}}" alt="取引開始" loading="lazy">
                        <p class="label">最短即日でお取引スタート！</p>
                        <a href="{{route('user.register')}}" class="register_button">
                            <p>
                                <span>さっそくはじめる</span><img src="{{asset('core/public/en/images/right_circle.svg')}}" alt="会員登録">
                            </p>
                        </a>
                    </div>
                </div>
            </section>

            <section class="news_section">
                <div class="headline">
                    <h2>Zaifからのお知らせ</h2>
                    <a href="#">
                        <p>すべて見る</p>
                    </a>
                </div>

                <div class="articles">
                    <ul>
                        <li>
                            <article>
                                <div class="icon">
                                    <img src="{{asset('core/public/en/images/news_icon_info.png')}}" alt="インフォメーション" loading="lazy">
                                </div>
                                <div class="text">
                                    <a href="#">
                                        <p class="title">「SNPT」上場記念
                                            第2弾！SNPITゲームをもっと楽しもう！キャンペーン</p>
                                    </a>
                                    <div class="article_footer">
                                        <p></p>
                                        <p>2025/01/10 18:07:10</p>
                                    </div>
                                </div>
                            </article>
                        </li>
                        <li>
                            <article>
                                <div class="icon">
                                    <img src="{{asset('core/public/en/images/news_icon_info.pn')}}g" alt="インフォメーション" loading="lazy">
                                </div>
                                <div class="text">
                                    <a href="#">
                                        <p class="title">取り扱い廃止暗号資産における出金処理受付終了日のお知らせ</p>
                                    </a>
                                    <div class="article_footer">
                                        <p></p>
                                        <p>2025/01/08 17:58:50</p>
                                    </div>
                                </div>
                            </article>
                        </li>
                        <li>
                            <article>
                                <div class="icon">
                                    <img src="{{asset('core/public/en/images/news_icon_info.png')}}" alt="インフォメーション" loading="lazy">
                                </div>
                                <div class="text">
                                    <a href="#">
                                        <p class="title">【事前告知】Zaif
                                            Paymentにおけるモナコイン(MONA)の取扱い廃止について</p>
                                    </a>
                                    <div class="article_footer">
                                        <p></p>
                                        <p>2024/12/27 12:00:00</p>
                                    </div>
                                </div>
                            </article>
                        </li>
                        <li>
                            <article>
                                <div class="icon">
                                    <img src="{{asset('core/public/en/images/news_icon_info.png')}}" alt="インフォメーション" loading="lazy">
                                </div>
                                <div class="text">
                                    <a href="#">
                                        <p class="title">【重要】年末年始の当社サービス提供スケジュールについて</p>
                                    </a>
                                    <div class="article_footer">
                                        <p></p>
                                        <p>2024/12/26 17:13:09</p>
                                    </div>
                                </div>
                            </article>
                        </li>
                        <li>
                            <article>
                                <div class="icon">
                                    <img src="{{asset('core/public/en/images/news_icon_info.png')}}" alt="インフォメーション" loading="lazy">
                                </div>
                                <div class="text">
                                    <a href="#">
                                        <p class="title">Zaif、Bflux と Babylon Bitcoin Staking プロトコルによる
                                            ビットコインステーキングサービスを可能にする新しいプロジェクトを開始</p>
                                    </a>
                                    <div class="article_footer">
                                        <p></p>
                                        <p>2024/12/25 18:51:30</p>
                                    </div>
                                </div>
                            </article>
                        </li>
                    </ul>
                </div>
            </section>

            <section class="services_section">
                <h2>サービス一覧</h2>
                <div class="services">
                    <article>
                        <img src="{{asset('core/public/en/images/service_1.svg')}}" alt="かんたん取引とOrderbook Trading" loading="lazy">
                        <h3>
                            かんたん売買と
                            <br>
                            Orderbook Trading
                        </h3>
                        <p class="description only_pc">
                            むずかしい操作知識は不要。利用者に寄り添った設計で売買取引操作をストレスフリーに利用できます。
                        </p>
                    </article>
                    <article>
                        <img src="{{asset('core/public/en/images/service_2.svg')}}" alt="かんたん取引とOrderbook Trading" loading="lazy">
                        <h3>
                            Zaifで暗号資産を学ぶ
                        </h3>
                        <p class="description only_pc">
                            暗号資産に関する記事やニュースがホームから読めるので少しずつ学ぶことができます。
                        </p>
                    </article>
                    <article>
                        <img src="{{asset('core/public/en/images/service_3.svg')}}" alt="かんたん取引とOrderbook Trading" loading="lazy">
                        <h3>
                            コイン積み立て
                        </h3>
                        <p class="description only_pc">
                            ビットコインや暗号資産には将来性を感じるが、ハイリスクな投資・投機的な手法は避けたいという方には特におすすめな積立投資も利用できます。
                        </p>
                    </article>
                    <article>
                        <img src="{{asset('core/public/en/images/service_4.svg')}}" alt="かんたん取引とOrderbook Trading" loading="lazy">
                        <h3>
                            チャットコミュニティ
                        </h3>
                        <p class="description only_pc">
                            ユーザー同士で交流できます。<br>市場の動向や暗号資産の最新の情報など話題は色々。
                        </p>
                    </article>
                    <article>
                        <img src="{{asset('core/public/en/images/service_5.svg')}}" alt="かんたん取引とOrderbook Trading" loading="lazy">
                        <h3>
                            ソーシャルチップ
                        </h3>
                        <p class="description only_pc">
                            Twitterアカウントを宛先に暗号資産を簡単に送金することができます。
                        </p>
                    </article>
                </div>
            </section>
        </main>
        <script>
            const bannerSwiper = new Swiper('.banner_swiper', {
                slidesPerView: 1.2,
                spaceBetween: 16,
                centeredSlides: true,
                loop: true,
                breakpoints: {
                    1025: {
                        slidesPerView: 3,
                        spaceBetween: 16,
                        centeredSlides: false,
                    },
                },
                pagination: {
                    el: '.swiper_pagination',
                    type: 'fraction',
                },
                navigation: {
                    nextEl: ".swiper_next",
                    prevEl: ".swiper_prev",
                },
            });

            const displayCurrencyList = () => {
                const currencies = {
                    'btc_jpy': {
                        'instant_ticker': 'btc',
                        'trade_url': '#',
                        'item': 'BTC',
                    },
                    'eth_jpy': {
                        'instant_ticker': 'eth',
                        'trade_url': '#',
                        'item': 'ETH',
                    },
                    'snpt_jpy': {
                        'instant_ticker': 'snpt',
                        'trade_url': '#',
                        'unit_point': 4,
                        'item': 'SNPT',
                    },
                    'skeb_jpy': {
                        'instant_ticker': 'skeb',
                        'trade_url': '#',
                        'unit_point': 4,
                        'item': 'SKEB',
                    },
                    'zpg_jpy': {
                        'instant_ticker': 'zpg',
                        'trade_url': '#',
                        'item': 'ZPG',
                    },
                    'bora_jpy': {
                        'instant_ticker': 'bora',
                        'trade_url': '#',
                        'unit_point': 4,
                        'item': 'BORA',
                    },
                    'xym_jpy': {
                        'instant_ticker': 'xym',
                        'trade_url': '#',
                        'unit_point': 3,
                        'item': 'XYM',
                    },
                    'xem_jpy': {
                        'instant_ticker': 'xem',
                        'trade_url': '#',
                        'unit_point': 3,
                        'item': 'XEM',
                    },
                    'mbx_jpy': {
                        'instant_ticker': 'mbx',
                        'trade_url': '#',
                        'unit_point': 4,
                        'item': 'MBX',
                    }
                }

                var tradeInfo = new TradeService(currencies);

                tradeInfo.dictionary.InstantTitle_ask = "{0}を買う";
                tradeInfo.dictionary.InstantTitle_bid = "{0}を売る";

                tradeInfo.start();

                page_visibility.hidden_method = function () {
                    tradeInfo.timer.clear();
                };
                page_visibility.show_method = function () {
                    tradeInfo.restart();
                };
                page_visibility.touchstart_method = function () {
                    tradeInfo.timer.clear();
                };
                page_visibility.touchend_method = function () {
                    tradeInfo.restart();
                };
            }

            document.addEventListener('DOMContentLoaded', displayCurrencyList);
        </script>


        <a href="#wrapper" onclick="smoothLink($(this));return false;">
            <div class="page-top">
                <span class="page-top-icon glyphicon glyphicon-arrow-up"></span>
            </div>
        </a>
        <footer class="footer">

            <p class="copy">© Ｚａｉｆ　Ｉｎｃ．</p>
        </footer>
    </div>
</div>


<script type="text/javascript">
    $(function () {
        $(".link-language").on("click", function (e) {
            return change_langage($(this))
        });
        $(".btn-language").on("click", function (e) {
            return change_langage($(this))
        });
        $(".modal").on("hidden.bs.modal", function () {
            $(".modal-backdrop").remove();
        });
    });


</script>





</body>
</html>
