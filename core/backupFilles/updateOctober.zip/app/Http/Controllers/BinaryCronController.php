<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Constants\Status;
use App\Http\Controllers\User\BinaryTradeOrderController;
use App\Lib\CurlRequest;
use App\Lib\TradeManager;
use App\Models\AdminNotification;
use App\Models\BinaryTrade;
use App\Models\CoinPair;
use App\Models\CronJob;
use App\Models\CronJobLog;
use App\Models\FutureOrder;
use App\Models\FutureQueueOrder;
use App\Models\FutureTrade;
use App\Models\Order;
use App\Models\Transaction;
use App\Models\Wallet;
use Carbon\Carbon;
use Exception;

class BinaryCronController extends Controller
{

    public function incompleteBinary()
    {
        try {
            $incompleteTrades = BinaryTrade::inactive()->pending()->where('trade_ended_at', '<=', now()->subMinute(1))->with(['coinPair'])->orderBy('id', 'asc')->limit(20)->get();

            BinaryTrade::inactive()->pending()->where('trade_ended_at', '<=', now()->subMinute(1))->limit(20)->update(['win_status' => Status::BINARY_TRADE_PROCESSING]);

            BinaryTrade::inactive()->processing()->where('updated_at', '<=', now()->subMinute(10))->limit(20)->update(['win_status' => Status::BINARY_TRADE_PENDING]);

            $binaryTradeOrder = new BinaryTradeOrderController();

            foreach ($incompleteTrades as $trade) {
                $time = now()->parse($trade->trade_ended_at)->timestamp;
                $time = $time * 1000;

                $symbol = str_replace('_', '', @$trade->coinPair->symbol);

                $try = 1;

                while ($try <= 10) {
                    $response = CurlRequest::curlContent("https://api.binance.com/api/v3/klines?symbol=$symbol&interval=1s&startTime=$time&endTime=$time&limit=1");
                    $response = json_decode($response, true);

                    if (@$response[0][1]) {
                        break;
                    }

                    sleep(1);
                    $try++;
                }

                if (!@$response[0][1]) {
                    $this->refundBinaryTrade($trade);
                    continue;
                }

                $price = $response[0][1];
                $binaryTradeOrder->binaryTradeWinLoss($trade, $price);
            }

        } catch (Exception $ex) {
            throw new \Exception($ex->getMessage());
        }
    }

    private function refundBinaryTrade($trade)
    {
        $trade->status     = Status::ENABLE;
        $trade->win_status = Status::BINARY_TRADE_REFUND;
        $trade->save();

        $user           = $trade->user;
        $currencySymbol = $trade->coinPair->market->currency->symbol;
        $userWallet     = $user->wallets()->where('currency_id', $trade->coinPair->market->currency_id)->first();

        $userWallet->balance += $trade->amount;
        $userWallet->save();

        $transaction               = new Transaction();
        $transaction->user_id      = $user->id;
        $transaction->wallet_id    = $userWallet->id;
        $transaction->amount       = $trade->amount;
        $transaction->charge       = 0;
        $transaction->post_balance = $userWallet->balance;
        $transaction->trx          = getTrx();
        $transaction->trx_type     = '+';
        $transaction->details      = $trade->amount . ' ' . $currencySymbol . 'binary trade refunded';
        $transaction->remark       = 'binary_trade';
        $transaction->save();
    }

}
