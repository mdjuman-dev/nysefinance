<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use App\Models\Currency;
use App\Models\Transaction;
use App\Models\Wallet;
use GuzzleHttp\Client;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class ConvertController extends Controller
{
    public function convert($type = null)
    {
        $data['pageTitle'] = 'Stock Wallet';

        $data['currencies'] = Currency::orderByDesc('created_at')->get();

//        $symbols='';
//        foreach($data['currencies'] as $currency){
//            $symbols.=$currency->symbol.',';
//        }
//
//
//        dd($symbols);



        return view('Template::user.wallet.convert', $data);
    }

    public function convertCoinPairs()
    {

        try{

            $allowCurrencies = [
                'DOP','DZD','EGP','GEL','GHS','GTQ','HNL','IQD','IRR','JMD','JOD','KES','KGS','KHR',
                'KWD','KZT','LBP','LKR','MAD','MDL','MKD','MMK','NAD','NIO','NPR','OMR','PAB','QAR',
                'RSD','SAR','SSP','TND','TTD','UGX','UYU','UZS','VES','USD','AUD','X','CAD','CHF',
                'CLP','CNY','CZK','DKK','EUR','GBP','HKD','HUF','IDR','ILS','INR','JPYC','KRW','MXN',
                'MYR','NOK','NZD','PHP','PKR','PLN','RUB','SEK','SGD','THB','TRY','TWD','ZAR','AED',
                'BGN','HRK','MUR','RON','ISK','NGN','COP','ARS','PEN','VND','UAH','BOB','ALL','AMD',
                'AZN','BAM','BDT','BHD','BMD','BYN','CRC','CUP','BTC','ETH','USDT','BNB','SOL','USDC',
                'XRP','DOGE','TRX','TON','ADA','AVAX','SHIB','LINK','BCH','DOT','LEO','NEAR','DAI',
                'LTC','SUI','ZETA','HMSTR','PEPE','LBK','KLAUS','FET','KAS','XMR','AIC','XLM','FDUSD',
                'STX','RENDER','POL','WIF','OKB','IMX','FIL','BABYDOGE','ARB','OP','MNT','CRO','INJ',
                'HBAR','FTM','ATOM','VET','RUNE','BGB','BONK','GRT','SEI','POPCAT','FLOKI','JUP',
                'PYTH','TIA','THETA','HNT','WLD','AR','OM','KCS','ENA','ALGO','ONDO','MEW','BRETT',
                'LDO','MKR','BEAM','BSV','JASMY','APE','MATIC','BTT','CORE','FLOW','GT','GALA','RAY',
                'STRK','USDD','NOT','AXS','QNT','SAFE','PENDLE','AERO','MOG','FLR','EOS','ORDI','NEO',
                'GOAT','BLENDR','DYDX','EGLD'
            ];


            $client = new Client();
            $response = $client->get('https://api.binance.com/api/v3/exchangeInfo');
            $data = json_decode($response->getBody(), true);


            $pairs = [];

            $fromCoinPairs = [];
            $toCoinPairs = [];
            foreach ($data['symbols'] as $symbol) {

                $base = $symbol['baseAsset'];
                $quote = $symbol['quoteAsset'];

                // ✅ Only include pairs if BOTH base or quote are in your allowed list
                if (in_array($quote, $allowCurrencies)) {
                   $toCoinPairs[] = $quote;
                }
                if(in_array($base, $allowCurrencies)){
                    $fromCoinPairs[] = $base;
                }
            }



            $toCoinPairs = array_slice($toCoinPairs, 0, 500);
            $fromCoinPairs = array_slice($fromCoinPairs, 0, 500);

            $toCoinPairs = array_values(array_unique($toCoinPairs));
            $fromCoinPairs = array_values(array_unique($fromCoinPairs));

//            dd($fromCoinPairs, $toCoinPairs);


            return response()->json(['status' => 'success', 'from' => $fromCoinPairs, 'to' => $toCoinPairs]);

        }catch(\Exception $e){
            return response()->json(['status' => 'error']);
        }

    }


    public function convertBalance(Request $request)
    {

        $wallet = Wallet::where('user_id', auth()->user()->id)->where('currency_id', $request->currency_id)->where('wallet_type', '1')->first();

        if (!$wallet) {
            return response()->json(['status' => 'failed', 'message' => 'Wallet not found']);
        }

        return response()->json(['status' => 'success', 'balance' => number_format($wallet->balance, 4)]);

    }


    function convertRate(Request $request)
    {



        if (!$request->from_coin || !$request->to_coin) {
            return response()->json(['status' => 'failed', 'message' => 'Please enter a valid coin']);
        }

        $currency = Currency::where('symbol', $request->from_coin)->first();
        if (!$currency) {
            return response()->json(['status' => 'failed', 'message' => 'Please enter a valid coin']);
        }

        $wallet = Wallet::where('user_id', auth()->user()->id)->where('currency_id', $currency->id)->where('wallet_type', '1')->first();




        if (!$wallet) {
            return response()->json(['status' => 'failed', 'message' => 'Wallet not found']);
        }


        $mergeCoin = strtoupper($request->from_coin . $request->to_coin);




        try {
            $client = new Client(['verify' => false]);
            $response = $client->get('https://api.binance.com/api/v3/ticker/price?symbol='.$mergeCoin);
            $data = json_decode($response->getBody(), true);


            $price = $data['price'];

            return response()->json(['status' => 'success', 'convert_rate' => number_format($price, 4), 'available_amount' => number_format($wallet->balance, 4)]);
        } catch (\Exception $e) {

            return response()->json(['status' => 'failed', 'message' => 'Something went wrong']);
        }

    }

    public function convertAmount(Request $request)
    {

        DB::beginTransaction();


        try {


            if(!$request->fromAmount || $request->fromAmount <= 0){
//            return redirect()->back()->with('error', 'Please enter amount to convert');
            }


//            dd($request->all());

            $fromCurrency = Currency::where('symbol', $request->from_coin)->first();
            $toCurrency = Currency::where('symbol', $request->to_coin)->first();
            if (!$fromCurrency || !$toCurrency) {
                return redirect()->back()->with('error', 'Currency not found');
            }

            $user = auth()->user();

            $fromWallet = Wallet::where('user_id', auth()->user()->id)->where('currency_id', $fromCurrency->id)->where('wallet_type', '1')->first();

            if($fromWallet->balance <= 0){
                return redirect()->back()->with('error', 'Doesn\'t have enough balance');
            }




            $toWallet = Wallet::where('user_id', auth()->user()->id)->where('currency_id', $toCurrency->id)->where('wallet_type', '1')->first();

            if (!$fromWallet || !$toWallet) {
                return redirect()->back()->with('error', 'Wallet not found');
            }


            $mergeCoin = strtoupper($request->from_coin . $request->to_coin);
            $client = new Client(['verify' => false]);
            $response = $client->get('https://api.binance.com/api/v3/ticker/price', [
                'query' => ['symbol' => $mergeCoin]
            ]);
            $data = json_decode($response->getBody(), true);
            $convert_rate = $data['price'];

            $toAmount = $request->fromAmount * $convert_rate;


            if ($fromWallet->balance < $request->fromAmount) {
                return redirect()->back()->with('error', 'Insufficient balance');
            }


            //From Wallet
            $deductAmount = $fromWallet->balance - $request->fromAmount;
            $fromWallet->balance = $deductAmount;
            $fromWallet->save();

            //To Wallet
            $addedAmount = $toWallet->balance + $toAmount;
            $toWallet->balance = $addedAmount;
            $toWallet->save();


            //Added
            $added_transaction = new Transaction();
            $added_transaction->user_id = $user->id;
            $added_transaction->wallet_id = $toWallet->id;
            $added_transaction->amount = $addedAmount;
            $added_transaction->post_balance = $addedAmount;
            $added_transaction->charge = 0;
            $added_transaction->trx_type = '+';
            $added_transaction->details = $addedAmount . ' ' . $request->to_coin . ' Added From' . $request->fromAmount . ' ' . $request->from_coin;
            $added_transaction->trx = Str::random(13);
            $added_transaction->remark = 'transfer';
            $added_transaction->save();

            //Minus
            $transaction = new Transaction();
            $transaction->user_id = $user->id;
            $transaction->wallet_id = $fromWallet->id;
            $transaction->amount = $request->fromAmount;
            $transaction->post_balance = $request->fromAmount;
            $transaction->charge = 0;
            $transaction->trx_type = '-';
            $transaction->details = $request->fromAmount . ' ' . $request->from_coin . ' = ' . $addedAmount . ' ' . $request->to_coin;
            $transaction->trx = Str::random(12);
            $transaction->remark = 'transfer';
            $transaction->save();

            DB::commit();

            return redirect()->back()->with('success', 'Converted from ' . $fromWallet->symbol . ' to ' . $toWallet->symbol);
        }catch (\Exception $e) {
            DB::rollBack();

            return redirect()->back()->with('error', 'Something went wrong');
        }

    }
}
