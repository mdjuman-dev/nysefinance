@extends('admin.layouts.app')
@section('panel')
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-body p-0">
                    <div class="table-responsive--md  table-responsive">
                        <table class="table table--light style--two">
                            <thead>
                                <tr>
                                    <th>@lang('User')</th>
                                    <th>@lang('Stock Name')</th>
                                    <th>@lang('Type')</th>
                                    <th>@lang('Invest Amount')</th>
                                    <th>@lang('Interest')</th>
                                    <th>@lang('Action')</th>
                                </tr>
                            </thead>
                            <tbody>
                                @forelse($user_stocks as $user_stock)

                                    <tr>
                                        <td>
                                            <p>Name: {{$user_stock->user->fullname}}</p>
                                            <p>Email: {{$user_stock->user->email}}</p>
                                            <p>Username: <a href="{{ route('admin.users.detail', $user_stock->user_id) }}">
                                                {{$user_stock->user->username}}
                                                </a>
                                            </p>
                                        </td>
                                        <td>{{$user_stock->product->name}}</td>
                                        <td>
                                            @if($user_stock->type=='fix')
                                                <span class="badge badge--danger">Mutual Fund</span>
                                            @else
                                                <span class="badge badge--success">Live Market</span>
                                            @endif

                                        </td>
                                        <td>
                                        {{$user_stock->interest_amount}}</td>
                                        <td>
                                            {{$user_stock->interest}}
                                        </td>
                                        <td>

                                            <button type="button" data-user-id="{{$user_stock->user_id}}" data-id="{{$user_stock->id}}"
                                                    data-interest="{{$user_stock->interest}}"
                                                    class="btn btn-info edit-stock">Edit</button>

                                        </td>
                                    </tr>
                                @empty
                                    <tr>
                                        <td class="text-muted text-center" colspan="100%">No Data Available</td>
                                    </tr>
                                @endforelse
                            </tbody>
                        </table>
                    </div>
                </div>
                @if ($user_stocks->hasPages())
                    <div class="card-footer py-4">
                        {{ paginateLinks($user_stocks) }}
                    </div>
                @endif
            </div>
        </div>
    </div>



    <!-- Modal -->
    <div class="modal fade" id="editUserStockModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">

                <form action="{{route('admin.stock.update.user.stocks')}}" method="post">
                    @csrf

                    <input type="hidden" name="user_id" class="user_id">
                    <input type="hidden" name="id" class="id">


                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalCenterTitle">Edit User Stock</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="form-group">
                            <label for="">Interest</label>
                            <input type="text" name="interest" class="form-control interest">
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Save</button>
                    </div>

                </form>
            </div>
        </div>
    </div>



@endsection

@push('breadcrumb-plugins')
    <a href="{{route('admin.stock.sell.request')}}" class="float-right btn btn-success">Sell Request</a>
    <a href="{{route('admin.stock.create')}}" class="float-right btn btn-primary">New Stock</a>
@endpush

@push('script')

    <script>
        $(document).on('click', '.edit-stock', function (e){
            e.preventDefault();

            const user_id=$(this).attr('data-user-id');
            const id=$(this).attr('data-id');
            const interest=$(this).attr('data-interest');


            $('.id').val(id);
            $('.interest').val(interest);
            $('.user_id').val(user_id);

            $('#editUserStockModal').modal('show');


        })
    </script>
@endpush
