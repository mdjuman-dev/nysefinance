<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1,minimum-scale=1.0">


    <title>暗号資産・販売所 - Zaif</title>


    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="{{asset('core/public/en/css/bootstrap.min.css')}}">
    <link rel="stylesheet" href="{{asset('core/public/en/css/typeahead.js-bootstrap.css')}}">
    <link rel="stylesheet" href="{{asset('core/public/en/css/style.css')}}">
    <link rel="stylesheet" href="{{asset('core/public/en/css/baseaccount.css')}}">
    <link rel="stylesheet" href="{{asset('core/public/en/css/font-awesome.min.css')}}">
    <link rel="stylesheet" href="{{asset('core/public/en/css/swiper.min.css')}}">


    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin="">
    <link href="https://fonts.googleapis.com/css2?family=Noto+Sans+JP:wght@400;500;700&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="{{asset('core/public/en/css/style.css')}}">
    <link rel="stylesheet" href="{{asset('core/public/en/css/index.css')}}">

    <link rel="stylesheet" href="{{asset('core/public/en/css/logo-Index.css')}}">
    <link rel="stylesheet" href="{{asset('core/public/en/css/swiper.min.css')}}">
    <link rel="stylesheet" href="{{asset('core/public/en/css/animate.css')}}">
    <script src="{{asset('core/public/en/js/wow.min.js')}}"></script>

    <!--LP-->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Crimson+Text" rel="stylesheet">


    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
    <!-- Latest compiled and minified JavaScript -->
    <script src="{{asset('core/public/en/js/jquery-1.11.3.min.js')}}"></script>
    <script src="{{asset('core/public/en/js/jquery.cookie.js')}}"></script>
    <script src="{{asset('core/public/en/js/bootstrap.min.js')}}"></script>
    <script src="{{asset('core/public/en/js/typeahead.bundle.min.js')}}"></script>
    <script src="{{asset('core/public/en/js/jquery.toaster.min.js')}}"></script>
    <script src="{{asset('core/public/en/js/assets.min.js')}}"></script>
    <script src="{{asset('core/public/en/js/jquery.easing.js')}}"></script>
    <script src="{{asset('core/public/en/js/swiper.min.js')}}"></script>


    <script src="{{asset('core/public/en/js/bundle.min.js')}}"></script>
    <script src="{{asset('core/public/en/js/bundle.tracing.min.js')}}"></script>



    <script src="{{asset('core/public/en/js/swiper.min.js')}}"></script>


    <script src="{{asset('core/public/en/js/mathcontext.js')}}"></script>
    <script src="{{asset('core/public/en/js/bigdecimal.js')}}"></script>
    <script src="{{asset('core/public/en/js/jquery.color.js')}}"></script>
    <script src="{{asset('core/public/en/js/swiper-bundle.min.js')}}"></script>
    <script src="{{asset('core/public/en/js/swiper-bundle.min.js')}}"></script>
    <script src="{{asset('core/public/en/js/page-visibility.js')}}"></script>
    <script src="{{asset('core/public/en/js/currency_list.min.js')}}"></script>

    <script>
        new WOW().init();
    </script>


    <link rel="apple-touch-icon" href="{{asset('core/public/en/images/apple-touch-icon.png')}}">
    <link rel="apple-touch-icon" sizes="72x72" href="{{asset('core/public/en/images/apple-touch-icon-72x72.png')}}">
    <link rel="apple-touch-icon" sizes="76x76" href="{{asset('core/public/en/images/apple-touch-icon-76x76.png')}}">
    <link rel="apple-touch-icon" sizes="114x114" href="{{asset('core/public/en/images/apple-touch-icon-114x114.png')}}">
    <link rel="apple-touch-icon" sizes="120x120" href="{{asset('core/public/en/images/apple-touch-icon-120x120.png')}}">
    <link rel="apple-touch-icon" sizes="144x144" href="{{asset('core/public/en/images/apple-touch-icon-144x144.png')}}">
    <link rel="apple-touch-icon" sizes="152x152" href="{{asset('core/public/en/images/apple-touch-icon-152x152.png')}}">

</head>


<body class="column1">



<div id="wrapper">


    <header class="header" id="header">
        <nav class="navbar navbar-inverse navbar-fixed-top yamm">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <h1 id="logo"><a class="navbar-brand main-title" href="/"><img src="/core/public/en/images/zaif_blue.svg" alt="Zaif Cryptocurrency Exchange"></a></h1>
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                    <span class="sr-only"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Toggle navigation</font></font></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div id="navbar" class="navbar-collapse collapse navbar-right">
                <ul class="nav navbar-nav">
                    <li style="display: none !important;"><a href="#"></a></li>
                    <li style="display: none !important;"><a href="#"></a></li>


                    <li style="display: none !important;"><a href="#"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">e</font></font></a></li>


                    <li  class="dropdown yamm-fw">

                        <a class="dropdown-toggle" href="#" data-toggle="dropdown">Official Website<b class="caret"></b></a>
                        <ul class="dropdown-menu dropdown-service">
                            <li class="nav-service">
                                <div class="nav-service-list">
                                    <ul class="nav-service-listUp">
                                        <li><a href="www.zaif.jp">Zaif</a> </li>
                                        <li><a href="www.zaifjp.com">ZaifJP</a></li>
                                        <li><a href="www.corp.zaif.jp">Corp Zaif</a></li>
                                        <li><a href="www.zaif-nft.io">Zaif NFT</a></li>
                                    </ul>
                                </div>
                            </li>
                        </ul>
                    </li>

                    @if(!auth()->user())

                    <li><a href="/user/login" class="text-skyb"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Login</font></font></a></li>
                    <li><a href="/user/register" class="text-skyb cv-header" data-toggle="header_tooltip" data-placement="bottom" title="" data-original-title="Click here to start trading"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Register</font></font></a></li>

                    @else
                        <li><a href="{{route('user.home')}}" class="text-skyb"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Dashboard</font></font></a></li>

                    @endif

                    <li></li>
                    <li></li>


                    <li class="dropdown icon-container only_pc">
                        <a href="javascript:void(0)" class="dropdown-toggle text-skyb" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                            <img src="/core/public/en/images/lang.png" alt="language" class="icon-button">
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="link-language" href="/jp" data-locale="ja"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Japanese</font></font></a></li>
                            <li role="separator" class="divider only_pc"></li>
                            <li><a class="link-language" href="/en" data-locale="en"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">English</font></font></a></li>
                        </ul>
                    </li>

                    <li class="only_sp"><a href="#contact"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Contact Support</font></font></a></li>
                    <li class="dropdown only_sp">
                        <a href="javascript:void(0)" class="dropdown-toggle text-skyb" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Language&nbsp;</font></font><span class="caret"></span></a>
                        <ul class="dropdown-menu">
                            <li><a class="link-language" href="javascript:void(0)" data-locale="ja"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">English</font></font></a></li>
                            <li role="separator" class="divider only_pc"></li>
                            <li><a class="link-language" href="javascript:void(0)" data-locale="en"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">English</font></font></a></li>
                        </ul>
                    </li>
                </ul>
            </div><!-- /.navbar-collapse -->
        </nav>
        <script>
            $(function () {
                $('[data-toggle="header_tooltip"]').tooltip();
            });
        </script>
    </header>


    <div id="main" class="clearfix">


        <main class="top_page">
            <section class="kv_section">
                <div class="kv">
                    <div class="text">
                        <p class="catchcopy">
                            <span class="emphasis"><font style="vertical-align: inherit;"></font></span><font style="vertical-align: inherit;"></font><br><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
                                    If you want to build assets </font><font style="vertical-align: inherit;">with
                                </font><span class="emphasis"><font style="vertical-align: inherit;">crypto assets</font></span></font><img src="/core/public/en/images/zaif.png" alt="Zaif">
                        </p>
                        <p class="description"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
                                    You can purchase even a small amount, so it's easy to start investing!
                                </font></font><br><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
                                    Why not start building your adult assets with cryptocurrency investment?
                                </font></font></p>
                        <a href="https://apk.zaifjp.com/file/zaif-update-1.1.apk" class="register_button">
                            <p>
                                <span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Download APK</font></font></span><img src="/core/public/en/images/right_circle.svg" alt="Membership Registration">
                            </p>
                        </a>
                    </div>
                    <div class="image">
                        <img src="/core/public/en/images/mock_sp.png" alt="Smartphone app" loading="lazy">
                    </div>
                </div>
                <div class="coins">
                    <ul class="currency-list"><a href="#" class="action"><li id="cp_btc_jpy" style="background-color: rgb(255, 255, 255);"><p class="label ico-btc"><span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">BTC/JPY</font></font></span></p><p class="price down" style="display: block;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">14,558,540</font></font></p><p class="volatility down arrow-down"><span style="display: block;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">3.07%</font></font></span></p></li></a><a href="#"><li id="cp_eth_jpy" style="background-color: rgb(255, 255, 255);"><p class="label ico-eth"><span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">ETH/JPY</font></font></span></p><p class="price down" style="display: block;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">474,515</font></font></p><p class="volatility down arrow-down"><span style="display: block;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">8.75%</font></font></span></p></li></a><a href="#"><li id="cp_snpt_jpy"><p class="label ico-snpt"><span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">SNPT/JPY</font></font></span></p><p class="price down"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">5.6600</font></font></p><p class="volatility down arrow-down"><span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">4.39%</font></font></span></p></li></a><a href="#"><li id="cp_skeb_jpy"><p class="label ico-skeb"><span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">SKEB/JPY</font></font></span></p><p class="price down"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">0.0810</font></font></p><p class="volatility down arrow-down"><span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">12.8%</font></font></span></p></li></a><a href="#"><li id="cp_zpg_jpy"><p class="label ico-zpg"><span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">ZPG/JPY</font></font></span></p><p class="price down"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">13,472</font></font></p><p class="volatility down arrow-down"><span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">1.35%</font></font></span></p></li></a><a href="#"><li id="cp_bora_jpy"><p class="label ico-bora"><span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">BORA/JPY</font></font></span></p><p class="price down"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">20.7000</font></font></p><p class="volatility down arrow-down"><span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">10.96%</font></font></span></p></li></a><a href="#"><li id="cp_xym_jpy"><p class="label ico-xym"><span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">XYM/JPY</font></font></span></p><p class="price down"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">2.568</font></font></p><p class="volatility down arrow-down"><span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">6.14%</font></font></span></p></li></a><a href="#"><li id="cp_xem_jpy"><p class="label ico-xem"><span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">XEM/JPY</font></font></span></p><p class="price down"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">3.830</font></font></p><p class="volatility down arrow-down"><span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">7.14%</font></font></span></p></li></a><a href="#"><li id="cp_mbx_jpy"><p class="label ico-mbx"><span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">MBX/JPY</font></font></span></p><p class="price down"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">52.9999</font></font></p><p class="volatility down arrow-down"><span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">7.59%</font></font></span></p></li></a></ul>
                </div>
            </section>

            <section class="banners_section">
                <div class="swiper banner_swiper swiper-initialized swiper-horizontal swiper-backface-hidden">
                    <div class="swiper-wrapper" id="swiper-wrapper-aebfeeaf108b10b023" aria-live="polite">
                        <div class="swiper-slide swiper-slide-active" role="group" aria-label="1 / 8" data-swiper-slide-index="0" style="width: 343px; margin-right: 16px;">
                            <a href="#" id="kv-20250110_snpt_buy_cp2">
                                <img src="/core/public/en/images/banner_snpt_buy2.png" alt="SNPT Listing Commemoration! Second Purchase Campaign">
                            </a>
                        </div>
                        <div class="swiper-slide swiper-slide-next" role="group" aria-label="2 / 8" data-swiper-slide-index="1" style="width: 343px; margin-right: 16px;">
                            <a href="#">
                                <img src="/core/public/en/images/banner_zpg_zres.png" alt="ZPG Acquisition Celebration! Coin Accumulation Campaign">
                            </a>
                        </div>
                        <div class="swiper-slide" role="group" aria-label="3 / 8" data-swiper-slide-index="2" style="width: 343px; margin-right: 16px;">
                            <a href="#" id="kv-20240410_staking_appeal">
                                <img src="/core/public/en/images/banner_staking_appel2.png" alt="Staking is a new way to build assets">
                            </a>
                        </div>
                        <div class="swiper-slide" role="group" aria-label="4 / 8" data-swiper-slide-index="3" style="width: 343px; margin-right: 16px;">
                            <a href="#" id="kv-20231220_doc_mobile_app">
                                <img src="/core/public/en/images/banner_app_202404.png" alt="App renewal">
                            </a>
                        </div>
                        <div class="swiper-slide" role="group" aria-label="5 / 8" data-swiper-slide-index="4" style="width: 343px; margin-right: 16px;">
                            <a href="#" id="kv-20231220_zaifcard">
                                <img src="/core/public/en/images/banner_zaif_card_202404.png" alt="Zaif Card">
                            </a>
                        </div>
                        <div class="swiper-slide" role="group" aria-label="6 / 8" data-swiper-slide-index="5" style="width: 343px; margin-right: 16px;">
                            <a href="#" id="kv-20231220_otegaru_manga">
                                <img src="/core/public/en/images/banner_otegaru_manga_202404.png" alt="Easy automated trading">
                            </a>
                        </div>
                        <div class="swiper-slide" role="group" aria-label="7 / 8" data-swiper-slide-index="6" style="width: 343px; margin-right: 16px;">
                            <a href="#" id="kv-20231220_cs\manage_notice_01">
                                <img src="/core/public/en/images/banner_cs_notice_01.png" alt="Information update input guide">
                            </a>
                        </div>
                        <div class="swiper-slide" role="group" aria-label="8 / 8" data-swiper-slide-index="7" style="width: 343px; margin-right: 16px;">
                            <a href="#" id="kv-20231220_cs_manage_notice_02">
                                <img src="/core/public/en/images/banner_cs_notice_02.png" alt="Crime Alert">
                            </a>
                        </div>
                    </div>
                    <div class="controls only_pc">
                        <div class="swiper_pagination swiper-pagination-fraction swiper-pagination-horizontal"><span class="swiper-pagination-current"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">1</font></font></span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> / </font></font><span class="swiper-pagination-total"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">8</font></font></span></div>
                        <div class="swiper_prev" tabindex="0" role="button" aria-label="Previous slide" aria-controls="swiper-wrapper-aebfeeaf108b10b023">
                            <img src="/core/public/en/images/prev.svg" alt="previous">
                        </div>
                        <div class="swiper_next" tabindex="0" role="button" aria-label="Next slide" aria-controls="swiper-wrapper-aebfeeaf108b10b023">
                            <img src="/core/public/en/images/next.svg" alt="next">
                        </div>
                    </div>
                    <span class="swiper-notification" aria-live="assertive" aria-atomic="true"></span></div>
            </section>

            <section class="features_section">
                <h2><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">What Zaif can do</font></font></h2>

                <div class="articles">
                    <article>
                        <div class="text">
                            <h4><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"># Point 1</font></font></h4>
                            <h3>
                                <p><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">No handling fee</font></font></p>
                                <p><span class="emphasis"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Investments that can be started with a small amount</font></font></span></p>
                            </h3>
                            <p class="description"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
                                        Zaif's Easy Buying and Selling (Sales Office) has no sales fees and allows you to buy and sell crypto assets in units of a few hundred yen, making it a safe option for those who want to try investing first.
                                    </font></font></p>
                        </div>
                        <div class="image">
                            <img src="/core/public/en/images/feature_1.jpg" alt="Start investing with no fees and small amounts" loading="lazy">
                        </div>
                    </article>

                    <article>
                        <div class="text">
                            <h4><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"># Point 2</font></font></h4>
                            <h3>
                                <p><span class="emphasis"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">A full range of crypto assets</font></font></span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> and services</font></font></p>
                            </h3>
                            <p class="description"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
                                        You can buy and sell 26 types of crypto assets, including Bitcoin. You can also enjoy investing in the crypto assets you want to support after learning about the characteristics, development philosophy, and uses of each crypto asset.
                                    </font></font><br><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
                                        In addition, it also supports services such as savings and automated trading, so you can choose a service that suits your investment style.
                                    </font></font></p>
                        </div>
                        <div class="image">
                            <img src="/core/public/en/images/feature_2.jpg" alt="A full range of crypto assets and services" loading="lazy">
                        </div>
                    </article>

                    <article>
                        <div class="text">
                            <h4><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"># Point 3</font></font></h4>
                            <h3>
                                <p><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Because there is a proper explanation</font></font></p>
                                <p><span class="emphasis"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Even beginners can continue</font></font></span></p>
                            </h3>
                            <p class="description"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
                                        Even if you don't know anything about cryptocurrencies, you can gradually learn from explanatory articles and news, so you can continue investing without getting discouraged along the way.
                                    </font></font></p>
                        </div>
                        <div class="image">
                            <img src="/core/public/en/images/feature_3.jpg" alt="There are detailed explanations so even beginners can follow along" loading="lazy">
                        </div>
                    </article>
                </div>

                <a href="{{asset('core/public/Zaif-Exchanges.pdf')}}" target="_blank" class="register_button">
                    <p>
                        <span><font style="vertical-align: inherit;">
                                <font style="vertical-align: inherit;">Business Plan</font></font></span>
                        <img src="/core/public/en/images/right_circle.svg" alt="Membership Registration">
                    </p>
                </a>

            </section>

            <section class="pickup_services_section">
                <article>
                    <h3>
                        <p><span class="emphasis"><font style="vertical-align: inherit;"></font></span><font style="vertical-align: inherit;"></font><br class="only_pc"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Easily trade crypto assets
                                </font><font style="vertical-align: inherit;">anywhere with </font><span class="emphasis"><font style="vertical-align: inherit;">just your smartphone and one hand .</font></span></font></p>
                    </h3>
                    <div class="image">
                        <img src="/core/public/en/images/sp_app.jpg" alt="Smartphone app" loading="lazy">
                    </div>

                </article>

                <article>
                    <h3>
                        <p><span class="emphasis"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Zaif Card is convenient for</font></font></span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> transactions! </font></font><br class="only_pc"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">The more you use it, the more </font></font><span class="emphasis"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Bitcoin</font></font></span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> you get.</font></font></p>
                    </h3>
                    <div class="image">
                        <img src="/core/public/en/images/zaif_card.jpg" alt="Zaif Card" loading="lazy">
                    </div>
                    <div class="links">
                        <a href="#" class="application_button">
                            <p>
                                <span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Apply here</font></font></span><img src="/core/public/en/images/right_circle_blue.svg" alt="application">
                            </p>
                        </a>
                    </div>
                </article>
            </section>

            <section class="steps_section">
                <h2><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Steps to start trading</font></font></h2>

                <div class="contents">
                    <div class="steps">
                        <ol>
                            <li>
                                <div class="icon">
                                    <img src="/core/public/en/images/step_1.png" alt="Open an account" loading="lazy">
                                </div>
                                <div class="step_label">
                                    <p class="title"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">1. Open an account</font></font></p>
                                    <p class="description"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
                                                Create an account with your email address and password
                                            </font></font></p>
                                </div>
                            </li>
                            <li>
                                <div class="icon">
                                    <img src="/core/public/en/images/step_2.png" alt="Identity authentication" loading="lazy">
                                </div>
                                <div class="step_label">
                                    <p class="title"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">2. Identity Verification</font></font></p>
                                    <p class="description"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
                                                Enter the personal information required to open an account. Submit your identity verification documents via smartphone or mail.
                                            </font></font></p>
                                </div>
                            </li>
                            <li>
                                <div class="icon">
                                    <img src="/core/public/en/images/step_3.png" alt="payment" loading="lazy">
                                </div>
                                <div class="step_label">
                                    <p class="title"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">3. Deposit</font></font></p>
                                    <p class="description"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
                                                Deposit the funds for your transaction into your Zaif account and you're ready to go!
                                            </font></font></p>
                                </div>
                            </li>
                        </ol>
                    </div>

                    <div class="cta">
                        <img src="/core/public/en/images/feature_1.jpg" alt="Start trading" loading="lazy">
                        <p class="label"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Start trading as soon as possible!</font></font></p>
                        <a href="/user/register" class="register_button">
                            <p>
                                <span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Get started now</font></font></span><img src="/core/public/en/images/right_circle.svg" alt="Membership Registration">
                            </p>
                        </a>
                    </div>
                </div>
            </section>

            <section class="news_section">
                <div class="headline">
                    <h2><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">News from Zaif</font></font></h2>
                    <a href="#">
                        <p><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">See All</font></font></p>
                    </a>
                </div>

                <div class="articles">
                    <ul>
                        <li>
                            <article>
                                <div class="icon">
                                    <img src="/core/public/en/images/news_icon_info.png" alt="Information" loading="lazy">
                                </div>
                                <div class="text">
                                    <a href="#">
                                        <p class="title"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">"SNPT" Listing Commemoration 2nd Part! Let's enjoy the SNPIT game even more! Campaign</font></font></p>
                                    </a>
                                    <div class="article_footer">
                                        <p></p>
                                        <p><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">2025/01/10 18:07:10</font></font></p>
                                    </div>
                                </div>
                            </article>
                        </li>
                        <li>
                            <article>
                                <div class="icon">
                                    <img src="/core/public/en/images/news_icon_info.png" alt="Information" loading="lazy">
                                </div>
                                <div class="text">
                                    <a href="#">
                                        <p class="title"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Notification of the last day for withdrawal processing for discontinued cryptocurrencies</font></font></p>
                                    </a>
                                    <div class="article_footer">
                                        <p></p>
                                        <p><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">2025/01/08 17:58:50</font></font></p>
                                    </div>
                                </div>
                            </article>
                        </li>
                        <li>
                            <article>
                                <div class="icon">
                                    <img src="/core/public/en/images/news_icon_info.png" alt="Information" loading="lazy">
                                </div>
                                <div class="text">
                                    <a href="#">
                                        <p class="title"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">[Advance Notice] Discontinuation of Monacoin (MONA) handling on Zaif Payment</font></font></p>
                                    </a>
                                    <div class="article_footer">
                                        <p></p>
                                        <p><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">2024/12/27 12:00:00</font></font></p>
                                    </div>
                                </div>
                            </article>
                        </li>
                        <li>
                            <article>
                                <div class="icon">
                                    <img src="/core/public/en/images/news_icon_info.png" alt="Information" loading="lazy">
                                </div>
                                <div class="text">
                                    <a href="#">
                                        <p class="title"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">[Important] Regarding our service provision schedule during the New Year holidays</font></font></p>
                                    </a>
                                    <div class="article_footer">
                                        <p></p>
                                        <p><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">2024/12/26 17:13:09</font></font></p>
                                    </div>
                                </div>
                            </article>
                        </li>
                        <li>
                            <article>
                                <div class="icon">
                                    <img src="/core/public/en/images/news_icon_info.png" alt="Information" loading="lazy">
                                </div>
                                <div class="text">
                                    <a href="#">
                                        <p class="title"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Zaif launches new project to enable Bitcoin staking services using Bflux and Babylon Bitcoin Staking protocols</font></font></p>
                                    </a>
                                    <div class="article_footer">
                                        <p></p>
                                        <p><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">2024/12/25 18:51:30</font></font></p>
                                    </div>
                                </div>
                            </article>
                        </li>
                    </ul>
                </div>
            </section>

            <section class="services_section">
                <h2><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">List of services</font></font></h2>
                <div class="services">
                    <article>
                        <img src="/core/public/en/images/service_1.svg" alt="Easy Trading and Orderbook Trading" loading="lazy">
                        <h3><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
                                    Easy Buying and Selling and
                                </font></font><br><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
                                    Orderbook Trading
                                </font></font></h3>
                        <p class="description only_pc"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
                                    No complicated operating knowledge is required. The user-friendly design allows stress-free buying and selling operations.
                                </font></font></p>
                    </article>
                    <article>
                        <img src="/core/public/en/images/service_2.svg" alt="Easy Trading and Orderbook Trading" loading="lazy">
                        <h3><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
                                    Learn about crypto assets with Zaif
                                </font></font></h3>
                        <p class="description only_pc"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
                                    You can read articles and news about cryptocurrencies from your home page, so you can learn little by little.
                                </font></font></p>
                    </article>
                    <article>
                        <img src="/core/public/en/images/service_3.svg" alt="Easy Trading and Orderbook Trading" loading="lazy">
                        <h3><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
                                    Coin Stacks
                                </font></font></h3>
                        <p class="description only_pc"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
                                    If you believe that Bitcoin and cryptocurrencies have a promising future but want to avoid high-risk investments and speculative methods, you can also take advantage of installment investment plans.
                                </font></font></p>
                    </article>
                    <article>
                        <img src="/core/public/en/images/service_4.svg" alt="Easy Trading and Orderbook Trading" loading="lazy">
                        <h3><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
                                    Chat Community
                                </font></font></h3>
                        <p class="description only_pc"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
                                    Users can interact with each other. </font></font><br><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">There are many topics to discuss, including market trends and the latest information on cryptocurrencies.
                                </font></font></p>
                    </article>
                    <article>
                        <img src="/core/public/en/images/service_5.svg" alt="Easy Trading and Orderbook Trading" loading="lazy">
                        <h3><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
                                    Social Tip
                                </font></font></h3>
                        <p class="description only_pc"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
                                    You can easily send crypto assets to any Twitter account.
                                </font></font></p>
                    </article>
                </div>
            </section>
        </main>
        <script>
            const bannerSwiper = new Swiper('.banner_swiper', {
                slidesPerView: 1.2,
                spaceBetween: 16,
                centeredSlides: true,
                loop: true,
                breakpoints: {
                    1025: {
                        slidesPerView: 3,
                        spaceBetween: 16,
                        centeredSlides: false,
                    },
                },
                pagination: {
                    el: '.swiper_pagination',
                    type: 'fraction',
                },
                navigation: {
                    nextEl: ".swiper_next",
                    prevEl: ".swiper_prev",
                },
            });

            const displayCurrencyList = () => {
                const currencies = {
                    'btc_jpy': {
                        'instant_ticker': 'btc',
                        'trade_url': '#',
                        'item': 'BTC',
                    },
                    'eth_jpy': {
                        'instant_ticker': 'eth',
                        'trade_url': '#',
                        'item': 'ETH',
                    },
                    'snpt_jpy': {
                        'instant_ticker': 'snpt',
                        'trade_url': '#',
                        'unit_point': 4,
                        'item': 'SNPT',
                    },
                    'skeb_jpy': {
                        'instant_ticker': 'skeb',
                        'trade_url': '#',
                        'unit_point': 4,
                        'item': 'SKEB',
                    },
                    'zpg_jpy': {
                        'instant_ticker': 'zpg',
                        'trade_url': '#',
                        'item': 'ZPG',
                    },
                    'bora_jpy': {
                        'instant_ticker': 'bora',
                        'trade_url': '#',
                        'unit_point': 4,
                        'item': 'BORA',
                    },
                    'xym_jpy': {
                        'instant_ticker': 'xym',
                        'trade_url': '#',
                        'unit_point': 3,
                        'item': 'XYM',
                    },
                    'xem_jpy': {
                        'instant_ticker': 'xem',
                        'trade_url': '#',
                        'unit_point': 3,
                        'item': 'XEM',
                    },
                    'mbx_jpy': {
                        'instant_ticker': 'mbx',
                        'trade_url': '#',
                        'unit_point': 4,
                        'item': 'MBX',
                    }
                }

                var tradeInfo = new TradeService(currencies);

                tradeInfo.dictionary.InstantTitle_ask = "{0}を買う";
                tradeInfo.dictionary.InstantTitle_bid = "{0}を売る";

                tradeInfo.start();

                page_visibility.hidden_method = function () {
                    tradeInfo.timer.clear();
                };
                page_visibility.show_method = function () {
                    tradeInfo.restart();
                };
                page_visibility.touchstart_method = function () {
                    tradeInfo.timer.clear();
                };
                page_visibility.touchend_method = function () {
                    tradeInfo.restart();
                };
            }

            document.addEventListener('DOMContentLoaded', displayCurrencyList);
        </script>


        <a href="#wrapper" onclick="smoothLink($(this));return false;">
            <div class="page-top">
                <span class="page-top-icon glyphicon glyphicon-arrow-up"></span>
            </div>
        </a>
        <footer class="footer">

            <p class="copy"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">© Zaif Inc.</font></font></p>

            <div class="container" style="text-align:center">
                <div style="margin-top: 25px" class="section-ft-links">
                    <ul style="display: flex">
                        @php
                            $expect_name=['HOME','Market','Crypto Currency', 'p2p'];
                                $pages=\App\Models\Page::orderByDesc('created_at')->whereNotIn('name', $expect_name)->get();
                        @endphp

                        @foreach($pages as $page)
                            <li class="footer-menu__item" style="margin-left: 15px">
                                <a style="color: white !important;" href="/{{ $page->slug }}" class="footer-menu__link"> {{$page->name}}</a>
                            </li>
                        @endforeach
                    </ul>

                </div>
            </div>


        </footer>
    </div>
</div>


<script type="text/javascript">
    $(function () {
        $(".link-language").on("click", function (e) {
            return change_langage($(this))
        });
        $(".btn-language").on("click", function (e) {
            return change_langage($(this))
        });
        $(".modal").on("hidden.bs.modal", function () {
            $(".modal-backdrop").remove();
        });
    });


</script>





</body>
</html>
