<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Currency;
use App\Models\Product;
use App\Models\StockMember;
use App\Models\StockSellRequest;
use App\Models\StockTransaction;
use App\Models\StockWallet;
use App\Models\User;
use App\Models\UserStock;
use App\Models\Wallet;
use GuzzleHttp\Client;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class StockController extends Controller
{
    public function index()
    {
        $data['pageTitle'] = "Stocks";

        $data['products'] = Product::orderByDesc('created_at')->paginate(20);

        return view('admin.stock.list', $data);

    }

    public function create()
    {
        $data['pageTitle'] = "Stock Create";

        return view('admin.stock.create', $data);
    }

    public function store(Request $request)
    {

        $request->validate([
            'name' => 'required',
            'stock_code' => 'required',
            'description' => 'required',
            'image' => 'required',
            'price' => 'required',
        ]);


        $stock = new Product();
        $stock->name = $request->name;
        $stock->slug = Str::slug($request->name);
        $stock->short_description = $request->short_description;
        $stock->description = $request->description;
        $stock->stock_code = $request->stock_code;
        $stock->price = $request->price;
        $stock->fix_rate = $request->fix_rate;
        $stock->unfix_rate = $request->unfix_rate;
        if ($request->hasFile('image')) {
            $path = getFilePath('currency');
            $size = getFileSize('currency');
            try {
                $filename = fileUploader($request->image, $path, $size, @$stock->image);
                $stock->image = $filename;
            } catch (\Exception $exp) {
                $notify[] = ['error', 'Couldn\'t upload your image'];
                return back()->withNotify($notify);
            }
        }
        if ($request->hasFile('certificate_image')) {
            $path = getFilePath('currency');
            $size = getFileSize('currency');
            try {
                $filename = fileUploader($request->certificate_image, $path, $size, @$stock->certificate_image);
                $stock->certificate_image = $filename;
            } catch (\Exception $exp) {
                $notify[] = ['error', 'Couldn\'t upload your image'];
                return back()->withNotify($notify);
            }
        }
        $stock->save();

        $message = 'Stock Successfully Created';

        return returnBack($message, 'success');

    }

    public function edit($id)
    {
        $data['pageTitle'] = "Stock Edit";
        $data['product'] = Product::findOrFail($id);

        return view('admin.stock.edit', $data);
    }

    public function update(Request $request, $id)
    {

        $request->validate([
            'name' => 'required',
            'stock_code' => 'required',
            'description' => 'required',
            'price' => 'required',
        ]);


        $stock = Product::findOrFail($id);
        $stock->name = $request->name;
        $stock->slug = Str::slug($request->name);
        $stock->short_description = $request->short_description;
        $stock->description = $request->description;
        $stock->stock_code = $request->stock_code;
        $stock->price = $request->price;
        $stock->fix_rate = $request->fix_rate;
        $stock->unfix_rate = $request->unfix_rate;
        if ($request->hasFile('image')) {
            $path = getFilePath('currency');
            $size = getFileSize('currency');
            try {
                $filename = fileUploader($request->image, $path, $size, null);
                $stock->image = $filename;
            } catch (\Exception $exp) {
                $notify[] = ['error', 'Couldn\'t upload your image'];
                return back()->withNotify($notify);
            }
        }
        if ($request->hasFile('certificate_image')) {
            $path = getFilePath('currency');
            $size = getFileSize('currency');
            try {
                $filename = fileUploader($request->certificate_image, $path, $size, null);
                $stock->certificate_image = $filename;
            } catch (\Exception $exp) {
                $notify[] = ['error', 'Couldn\'t upload your image'];
                return back()->withNotify($notify);
            }
        }
        $stock->save();

        $message = 'Stock Successfully Updated';

        return returnBack($message, 'success');

    }

    public function delete($id)
    {
        $stock = Product::findOrFail($id);


        $stockUsed=UserStock::where('product_id', $stock->id)->first();
        if($stockUsed){
            $notify[] = ['error', 'Stock already used, can not delete it'];
            return back()->withNotify($notify);
        }

        $stock->delete();


        $message = 'Stock Successfully Deleted';

        return returnBack($message, 'success');
    }


    public function stockRequest()
    {
        $data['pageTitle'] = "Stock Sell Request";
        $data['sellRequests'] = StockSellRequest::with('user', 'product', 'user_stock')->orderByDesc('created_at')->paginate(20);


        return view('admin.stock.sell_request', $data);

    }
    public function stockMembers()
    {
        $data['pageTitle'] = "Stock Members";
        $data['stock_members'] = StockMember::with('user')->orderByDesc('created_at')->paginate(20);

        return view('admin.stock.stock_members', $data);

    }

    public function stockStatus(Request $request)
    {

        $request->validate([
            'request_status' => 'required',
            'request_id' => 'required',
        ]);


        DB::beginTransaction();


        try {
            $sellRequest = StockSellRequest::where('id', $request->request_id)->where('status', 'pending')->firstOrFail();
            $product = Product::where('id', $sellRequest->product_id)->firstOrFail();
            $user_stock = UserStock::where('id', $sellRequest->user_stock_id)->firstOrFail();
            if ($request->request_status == 'approve') {
                if (!$request->charge) {
                    return returnBack('Please enter charge to approve this request', 'error');
                }
                $stock_wallet = StockWallet::where('user_id', $sellRequest->user_id)->first();
                if (!$stock_wallet) {
                    return returnBack('User wallet not found try again after sometimes', 'error');
                }


                try {
                    $client = new Client(['verify' => false]);
                    $urls = "https://finnhub.io/api/v1/quote?symbol=" . $product->stock_code . "&token=crsr4hpr01qpjaduma70crsr4hpr01qpjaduma7g";
                    $response = $client->request('GET', $urls);
                    $response = $response->getBody()->getContents();
                    $response = json_decode($response, true);
                    $invest_amount = isset($response['c']) ? $response['c'] : $product->price;
                } catch (\Exception $exxxx) {
                    $invest_amount = $product->price;
                }

                $paidAmount = 0.00;
                if ($user_stock->invest_percent == '25') {
                    $paidAmount = ($invest_amount * 25) / 100;
                } elseif ($user_stock->invest_percent == '50') {
                    $paidAmount = ($invest_amount * 50) / 100;
                } elseif ($user_stock->invest_percent == '100') {
                    $paidAmount = ($invest_amount * 100) / 100;
                }
                $grandAmount = $paidAmount - $request->charge;


                //Create Stock Transaction
                $stockTran = new StockTransaction();
                $stockTran->user_id = $user_stock->user_id;
                $stockTran->type = 'sell';
                $stockTran->stock_type = 'unfix';
                $stockTran->amount = $grandAmount;
                $stockTran->charge = $request->charge;
                $stockTran->stock_id = $product->id;
                $stockTran->save();

                //Add Amount To Stock Wallet
                $stock_wallet_pre_amount = $stock_wallet->amount + $grandAmount;
                $stock_wallet->amount = $stock_wallet_pre_amount;
                $stock_wallet->save();

                //Approve Sell Request
                $sellRequest->status = 'approved';
                $sellRequest->charge = $request->charge;
                $sellRequest->save();

                //Update User Stock Status
                $user_stock->status='sell';
                $user_stock->save();
            }else{
                $sellRequest->status = 'rejected';
                $sellRequest->charge = '0.00';
                $sellRequest->save();

                $user_stock->status='sell';
                $user_stock->save();
            }

            DB::commit();

            return returnBack('Sell request successfully '.strtoupper($sellRequest->status), 'success');

        } catch (\Exception $e) {
            DB::rollBack();

            dd($e);
            return returnBack('Something went wrong try again after sometimes', 'error');
        }

    }

    public function transactions(Request $request)
    {

        $data['pageTitle'] = "Stock Transactions";
        if($request->user_id) {
            $data['transactions'] = StockTransaction::with('user', 'user_stock')->where('user_id', $request->user_id)->where('type', '!=', 'interest')->orderByDesc('created_at')->paginate(20);
        }else {
            $data['transactions'] = StockTransaction::with('user', 'user_stock')->where('type', '!=', 'interest')->orderByDesc('created_at')->paginate(20);
        }

        return view('admin.stock.transactions', $data);

    }


    public function interests(Request $request)
    {



        $data['pageTitle'] = "Stock Interest";

        $interests=StockTransaction::with('user','user_stock')->where('type', 'interest')->orderByDesc('created_at');

        if($request->user_id && $request->user_id !='null'){
            $interests=$interests->where('user_id', $request->user_id);
        }

        if($request->date){
            $dates=explode('-', $request->date);
            $startDate=isset($dates['0'])?$dates['0']:now()->subDays(7);
            $endDate=isset($dates['1'])?$dates['1']:now();

            $interests=$interests->whereBetween('created_at', [$startDate, $endDate]);
        }

        $interests=$interests->paginate(20);


        $data['interests'] = $interests;
        $data['users']=User::where('status', '1')->select(['id','email', 'firstname','lastname'])->orderByDesc('created_at')->get();

        return view('admin.stock.interest', $data);
    }

}
