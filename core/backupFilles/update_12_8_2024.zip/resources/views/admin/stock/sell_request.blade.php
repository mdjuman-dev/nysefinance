@extends('admin.layouts.app')
@section('panel')
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-body p-0">
                    <div class="table-responsive--md  table-responsive">
                        <table class="table table--light style--two">
                            <thead>
                            <tr>
                                <th>@lang('User')</th>
                                <th>@lang('Product')</th>
                                <th>@lang('Invest Percent')</th>
                                <th>@lang('Invest Amount')</th>
                                <th>@lang('Charge')</th>
                                <th>@lang('Status')</th>
                                <th>@lang('Action')</th>
                            </tr>
                            </thead>
                            <tbody>
                            @forelse($sellRequests as $sellRequest)

                                <tr>
                                    <td>
                                        {{$sellRequest->user->fullname}}
                                        <br>
                                        {{$sellRequest->user->email}}
                                    </td>
                                    <td>{{$sellRequest->product->name}}</td>
                                    <td>{{$sellRequest->user_stock->invest_percent}}</td>
                                    <td>{{$sellRequest->user_stock->invest_amount}}</td>
                                    <td>{{$sellRequest->charge}}</td>
                                    <td>
                                        {{strtoupper($sellRequest->status)}}
                                    </td>

                                    <td>
                                        @if($sellRequest->status=='pending')
                                        <button class="btn btn-success requestStatus" data-status="approve"
                                                data-id="{{$sellRequest->id}}" type="button">Approve
                                        </button>
                                        <button class="btn btn-danger requestStatus" data-status="reject"
                                                data-id="{{$sellRequest->id}}" type="button">Reject
                                        </button>
                                        @elseif($sellRequest->status=='approved')
                                        <button class="btn btn-success disabled" disabled="disabled">Approved</button>
                                        @else
                                        <button class="btn btn-danger disabled" disabled="disabled">Rejected</button>
                                        @endif

                                    </td>
                                </tr>
                            @empty
                                <tr>
                                    <td class="text-muted text-center" colspan="100%">No Data Available</td>
                                </tr>
                            @endforelse
                            </tbody>
                        </table>
                    </div>
                </div>
                @if ($sellRequests->hasPages())
                    <div class="card-footer py-4">
                        {{ paginateLinks($sellRequests) }}
                    </div>
                @endif
            </div>
        </div>
    </div>



    <!-- Modal -->
    <div class="modal fade" id="statusModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle"
         aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <form action="{{route('admin.stock.sell.status')}}" method="post">
                    @csrf
                    <input type="hidden" name="request_id">
                    <input type="hidden" name="request_status">
                    <div class="modal-header">
                        <h6 class="modal-title" id="exampleModalLongTitle">Confirm</h6>
                        <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <h6>Are you sure you want to <span class="request_status"></span> this sell request?</h6>

                        <div class="form-group charge-section mt-5 d-none">
                            <label for="">Change(flat)</label>
                            <input type="text" class="form-control" name="charge" placeholder="Enter charge amount">
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Confirm</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

@endsection

@push('breadcrumb-plugins')
    <a href="{{route('admin.stock.index')}}" class="float-right btn btn-primary">Back</a>
@endpush

@push('script')
    <script>
        $(document).on('click', '.requestStatus', function (e) {

            const id = $(this).attr('data-id');
            const status = $(this).attr('data-status');

            $('input[name=request_id]').val(id);
            $('input[name=request_status]').val(status);

            if(status=='approve'){
                $('.charge-section').removeClass('d-none');
            }else{
                $('.charge-section').addClass('d-none');
            }

            $('.request_status').text(status)

            $('#statusModal').modal('show');

        });
    </script>
@endpush
