<!doctype html>
<html lang="{{ config('app.locale') }}" itemscope itemtype="http://schema.org/WebPage">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title> {{ gs()->siteName(__($pageTitle)) }}</title>

{{--    @include('partials.seo')--}}

    <link href="{{ asset('assets/global/css/bootstrap.min.css') }}" rel="stylesheet">
    <link href="{{ asset('assets/global/css/all.min.css') }}" rel="stylesheet">
    <link rel="stylesheet" href="{{ asset('assets/global/css/line-awesome.min.css') }}"/>

    @stack('style-lib')
    <link rel="stylesheet" href="{{ asset($activeTemplateTrue . 'dashboard/css/icomoon.css') }}">
    <link rel="stylesheet" href="{{ asset($activeTemplateTrue . 'dashboard/css/main.css') }}">
    <link rel="stylesheet" href="{{ asset($activeTemplateTrue . 'css/custom.css') }}">

    @stack('style')

    <link rel="stylesheet" href="{{ asset($activeTemplateTrue . 'css/color.php') }}?color={{ gs('base_color') }}">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.9.1/summernote-bs4.min.css"/>

    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />


    @if (session('app'))
        <style>
            .dashboard-header,
            .dashboardBodyNav {
                display: none !important;
            }
        </style>
    @endif

    <style>
        .dashboard__right{
            padding-bottom: 130px;
        }
        .btn {
            padding: 10px 20px !important;
        }

        .side-menu-refer-link {
            display: none;
        }

        .m-user-image {
            display: none;
        }

        .mobile-footer-menu {
            display: none;
        }

        .username-for-m {
            display: block;
        }

        .dashboard-mob-view{
            display: block;
        }
        .section-stock-trade-view{
            display: none;
        }
        .ticker-tape-widget{
            display: none;
        }
        .sub-small-icon-section{
            display: none;
        }

        @media (max-width: 700px) {
            .dashboard-header__right {
                display: flex;
                justify-content: space-between;
            }

            .username-for-m {
                display: none;
            }

            .m-user-image {
                display: block;
                width: 46px;
                height: 45px;
                float: right;
                border-radius: 50px;
            }

            .user-info__button::before {
                display: none;
            }

            .sidebar-logo__link {
                display: none !important;
            }

            .side-menu-refer-link {
                display: block !important;
                background: #3b3d3b;
                padding: 10px 0px;
                color: white !important;
                border-radius: 5px;
            }

            .sidebar-logo {
                margin: 50px 10px 10px 10px !important;
            }

            .side-menu-refer-link copyTextBtn {
                color: white !important;
                margin-left: 5px;
            }

            .side-menu-refer-link input {
                background: initial !important;
                border: hidden !important;
                color: white;
            }

            .dashboard-header__inner {
                padding-top: 0px !important;
            }

            .mobile-footer-menu {
                display: block !important;
                position: fixed;
                bottom: 0px;
                width: 100%;
                z-index: 99999999999;
                background: #050808;
                padding: 10px 9px;
            }

            .m-menu-icon-sec i {
                font-size: 20px !important;
                color: #777777;
            }

            .dashboard__inner {
                padding-bottom: 150px !important;
            }

            .dashboard-header {
                position: fixed;
                top: 0px;
                width: 100%;
                z-index: 9;
            }

            .dashboard-body {
                margin-top: 53px;
                padding-top: 15px !important;
            }

            .dashboard-fluid .user-info__right {
                margin-top: 11px !important;
            }

            .dashboard-header__inner {
                padding-bottom: 8px !important;
            }

            .m-user-image {
                width: 40px !important;
                height: 40px !important;
            }

            .dashboard-fluid .dashboard-sidebar-filter__button i {
                font-size: 24px !important;
            }

            .dashboard-fluid .dashboard-sidebar-filter__button {
                padding: 0px !important;
                background: transparent !important;
            }

            .n-view-balance{
                display: block !important;
            }
            .sidebar-menu__inner{
                padding-bottom: 150px;
            }
            .dashboard-mob-view{
                display: none;
            }
            .section-stock-trade-view{
                display: flex;
            }
            .transection__title{
                margin-top: 40px;
            }
            .ticker-tape-widget{
                display: block;
            }
            .small-sub-icon a{
                text-align: center;
            }
            .small-sub-icon a span{
                display: block !important;
            }
            .small-sub-icon a i{
                background: #ff5200;
                padding: 5px 7px;
                font-size: 20px;
                border-radius: 5px;
                color: #0c0c0c;
            }
            .pagination .page-item .page-link{
                width: 80px !important;
                border-radius: 5px !important;
            }
            .mobile-user-sidebar{
                display: block !important;
                width: 100% !important;
                padding-bottom: 100px !important;
            }
            .desktop-user-sidebar{
                display: none !important;
            }
            .account-section{
                background: #2C2D27;
                padding: 17px;
                border-radius: 14px;
                color: white;
            }
            .account-section .copyTextBtn{
                margin-left: 5px;
                color: white !important;
            }
            .account-section .m-user-image{
                width: 50px !important;
                height: 50px !important;
            }
            .sidebar-menu.show-sidebar{
                width: 100%;
            }
            .separate-section-sidebar h6 {
                margin-left: 20px;
                color: white;
            }
            .separate-section-sidebar{
                margin-top: 30px;
                background: #2c2d27;
                border-radius: 10px;
                padding: 17px 5px;
            }
            .separate-section-sidebar .sidebar-menu-list__link .fa-angle-right{
                float: right;
            }
            .separate-section-sidebar .sidebar-menu-list__link .text{
                width: 100%;
            }
            .separate-section-sidebar .sidebar-menu-list__link{
                display: flex !important;
                flex-wrap: nowrap !important;
            }
            .separate-dashboard .sidebar-menu-list__link .fa-angle-right{
                float: right;
            }
            .separate-dashboard .sidebar-menu-list__link .text{
                width: 100%;
            }
            .separate-dashboard .sidebar-menu-list__link{
                display: flex !important;
                flex-wrap: nowrap !important;
            }
            .separate-dashboard{
                background: #2c2d27;
                border-radius: 10px;
                margin-top: 28px;
            }
            .dashboard-fluid .sidebar-menu-list{
                margin-top: 50px !important;
            }
            .single-weidgh-hart .livecoinwatch-widget-6{
                width: 98% !important;
            }
            .sm-icon-main-section .sec-sm-icons{
                width: 40px;
                text-align: center;
                padding: 10px 10px;
                border: 1px solid #a3a2a2;
                border-radius: 5px;
                color: white;
                background: #1f2434b0;
            }
            .sm-icon-main-section .icon-t-section{
                margin-top: 5px;
                font-size: 11px;
            }
            .sm-icon-main-section{
                justify-content: center;
                display: flex;
                align-items: center;
                flex-direction: column;
            }
            .sub-small-icon-section{
                margin-top: 20px;
                margin-bottom: 20px;
                display: block;
            }
            .sub-small-icon-section .sm-icon-main-section{
                width: 20% !important;
                padding-left: 6px !important;
                padding-right: 6px !important;
            }
            .deposit-con-sec-for-m{
                display: none !important;
            }
            .recent-tran-sec{
                display: none;
            }
            .user-info__right{
                display: none !important;
            }
            .dashboard-sidebar-filter__button.m-auto{
                margin-top: 11px !important;
            }
            .currency-font{
                font-size: 14px;
                color: white;
            }
            .n-view-balance{
                color: #e3e1e1 !important;
            }
            .scroll-top{
                display: none !important;
            }
            .bal-font{
                color: white !important;
            }

            #owl-demo {
                visibility: hidden;
            }
            .dashboard-right.show{
                width: 100% !important;
            }

        }

        .desktop-user-sidebar{
            background: #111e21 !important;
        }
        .desktop-user-sidebar{
            display: block;

        }
        .mobile-user-sidebar{
            display: none;
        }

        .m-menu-icon-sec {
            width: 20%;
            text-align: center;
        }

        .m-menu-icon-sec .icon-text-title {
            display: block;
            font-size: 12px;
            color: #999898 !important;
            font-weight: 700;
            font-family: monospace !important;
        }

        .mobile-menu-main-section {
            display: flex;
            justify-content: center;
        }

        .m-menu-icon-sec .active i {
            color: white !important;
        }

        .m-menu-icon-sec .active .icon-text-title {
            color: white !important;
        }

        .main-balance-hide {
            font-size: 20px;
            color: #a7a7a7;
            font-weight: 500;
            display: none;
        }

        .main-balance {
            font-size: 20px;
            color: #a7a7a7;
            font-weight: 500;
        }

        .hide-balance, .show-balance {
            cursor: pointer;
            margin-left: 7px;
            color: #9b9696;
        }
        .n-view-balance{
            display: none;
        }
        .badge-verified{
            color: #00db00;
            background: #0eb90e47;
            border-radius: 5px;
            padding: 2px 10px;
            font-size: 12px;
            margin-top: 5px;
        }
        .badge-pending{
            color: #fd0000;
            background: #bd0b0b47;
            border-radius: 5px;
            padding: 2px 10px;
            font-size: 12px;
            margin-top: 5px;
        }

        .select2-container .select2-selection--single{
            height: 50px !important;
        }
        .today-pnl {
            font-size: 12px;
            color: #12d712;
        }
        .offcanvas.show{
            width: 100% !important;
        }
    </style>
</head>
@php echo loadExtension('google-analytics') @endphp

<body>
@if (!request()->routeIs('user.home'))
    <div class="preloader">
        <div class="loader-p"></div>
    </div>
@endif

<div class="body-overlay"></div>
<div class="sidebar-overlay"></div>
<a class="scroll-top"><i class="fas fa-angle-double-up"></i></a>

<div class="dashboard-fluid position-relative">
    <div class="dashboard__inner">
        @include($activeTemplate . 'partials.user_sidebar')
        <div class="dashboard__right">
            @include($activeTemplate . 'partials.user_topbar')
            <div class="dashboard-body">
                <div class="d-flex justify-content-between mb-3 align-items-center dashboardBodyNav">

                    @if(isset($estimatedBalance))
                        <div class="n-view-balance">
                            <h4 class="mb-1">Total Balance</h4>
                            <div class="bal-m-sec d-none">
                                <div class="main-balance">
                                    <span class="bal-font">{{ str_replace('USD', '', showAmount($estimatedBalance)) }}</span> <span class="currency-font">USD</span> <i class="fa fa-eye hide-balance"></i>
                                </div>
                                <div class="main-balance-hide">
                                    ********* <i class="fa fa-eye-slash show-balance"></i>
                                </div>
                            </div>
                            <small class="today-pnl">Today PNL $0000(-0.00%)</small>
                        </div>
                    @endif

                    {{--                    <div class="dashboard-body__bar d-xl-none d-inline-block">--}}
                    {{--                        <button class="dashboard-sidebar-filter__button">--}}
                    {{--                            <i class="las la-bars"></i>--}}
                    {{--                        </button>--}}
                    {{--                    </div>--}}
                    @if (request()->routeIs('user.home'))
                        <div class="dashboard-body__bar style deposit-con-sec-for-m">
                            <span class="dashboard-body__bar-two-icon toggle-dashboard-right"><i
                                    class="fas fa-bars"></i></span>
                        </div>
                    @endif

                    @if (request()->routeIs('user.p2p*'))
                        <div class="p2p-sidebar__menu">
                                <span class="p2p-sidebar__menu-icon">
                                    <i class="fas fa-bars"></i>
                                </span>
                        </div>
                    @endif

                </div>
                @stack('topContent')
                @yield('content')
            </div>
        </div>
    </div>
</div>

<div class="mobile-footer-menu">
    <div class="mobile-menu-main-section">
        <div class="d-flex justify-content-center m-menu-icon-sec">
            <a href="{{ route('user.home') }}" class="{{ menuActive('user.home') }}">
                <i class="fa fa-home"></i>
                <span class="icon-text-title">Home</span>
            </a>
        </div>

        <div class="d-flex justify-content-center m-menu-icon-sec">
            <a href="{{route('user.stock.index')}}" class="{{ menuActive('user.stock.*') }}">
                <i class="fa fa-chart-bar"></i>
                <span class="icon-text-title">Stock</span>
            </a>
        </div>

        <div class="d-flex justify-content-center m-menu-icon-sec">
            <a href="{{ route('trade') }}" class="{{ menuActive('trade') }}">
                <i class="fa fa-chart-line"></i>
                <span class="icon-text-title">Trade</span>
            </a>
        </div>

        <div class="d-flex justify-content-center m-menu-icon-sec">
            <a href="#" class="">
                <i class="fa fa-lines-leaning"></i>
                <span class="icon-text-title">Future</span>
            </a>
        </div>
        <div class="d-flex justify-content-center m-menu-icon-sec">
            <a href="{{route('user.wallet.overview')}}" class="{{ menuActive('user.wallet.*') }}">
                <i class="fa fa-wallet"></i>
                <span class="icon-text-title">Wallet</span>
            </a>
        </div>

    </div>
</div>



<!-- Modal -->
<div class="modal fade" id="chmsModal" data-backdrop="static" tabindex="-1" role="dialog"
     aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header"
                 style="justify-content: right;padding-top: 0px !important; padding-bottom: 0px !important;">
                <button type="button" class="closeChms" data-dismiss="modal" aria-label="Close">
                    <span style="font-size: 30px" aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="section-image">
                    <img src="{{asset('core/public/chms.jpg')}}" alt="">
                </div>
            </div>

        </div>
    </div>
</div>

<script src="{{ asset('assets/global/js/jquery-3.7.1.min.js') }}"></script>
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>



<script>

    jQuery('button[type="submit"]').on('click', function (e) {
        var form = $(this).parents('form:first');
        if (form) {
            $(this).attr('disabled', 'disabled').addClass('disabled')
            $(this).html(' <i class="fa fa-spinner fa-spin"></i> Loading');
            form.submit();
        }
    });



    // $(document).ready(function () {
    //     // Check if modal should be shown
    //     const modalKey = 'chmsModalClosed';
    //     const lastClosed = localStorage.getItem(modalKey);

    //     // Check the current time
    //     const now = new Date().getTime();

    //     // Show modal only if not closed in the last 6 hours
    //     if (!lastClosed || now - lastClosed > 6 * 60 * 60 * 1000) {
    //         $('#chmsModal').modal('show');
    //     }

    //     // Save the close event time
    //     $('#chmsModal').on('hidden.bs.modal', function () {
    //         localStorage.setItem(modalKey, new Date().getTime());
    //     });
    // });
    
    

    // $(document).on('click', '.closeChms', function(e){
    //     $('#chmsModal').modal('hide');
    // })
    

    $(document).ready(function() {
        // Prevent anchor tags inside the tradingview widget container
        $('.tradingview-widget-container').on('click', 'a', function(event) {
            event.preventDefault(); // Prevent the default behavior of the anchor tags
        });
    });

    $(document).on('click', '.sec-sm-icons', function(e){
        const data_url=$(this).attr('data-url');
        if(!data_url){
            return;
        }

        location.href=data_url;
    });
</script>


<script>
    // Create or modify the viewport meta tag
    function disableZoom() {
        let metaViewport = document.querySelector('meta[name="viewport"]');
        if (!metaViewport) {
            metaViewport = document.createElement('meta');
            metaViewport.name = "viewport";
            document.head.appendChild(metaViewport);
        }
        metaViewport.content = "width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no";
    }

    // Call the function to apply the viewport settings
    disableZoom();
</script>


<script>
    (function($) {

        $.each($('.canvas-select2'), function(index, element) {
            $('.canvas-select2').select2({
                dropdownParent: $(this).closest('.position-relative')
            });
        });

        $('.2fa-notice').on('click', '.delete-icon', function(e) {
            $(this).closest('.col-12').fadeOut('slow', function() {
                $(this).remove();
            });
        });

        let walletSkip = 3;

        $('.show-more-wallet').on('click', function(e) {
            let route = "{{ route('user.more.wallet', ':skip') }}";
            let $this = $(this);
            $.ajax({
                url: route.replace(':skip', walletSkip),
                type: "GET",
                dataType: 'json',
                cache: false,
                beforeSend: function() {
                    $this.html(`
                        <span class="right-sidebar__button-icon">
                            <i class="las la-spinner la-spin"></i>
                        </span>`).attr('disabled', true);
                },
                complete: function(e) {
                    setTimeout(() => {
                        $this.html(`
                        <span class="right-sidebar__button-icon">
                            <i class="las la-chevron-circle-down"></i>
                        </span>@lang('Show More')`).attr('disabled', false);
                        $('.wallet-list').removeClass('skeleton');
                    }, 500);
                },
                success: function(resp) {
                    if (resp.success && (resp.wallets && resp.wallets.length > 0)) {
                        let html = "";
                        $.each(resp.wallets, function(i, wallet) {
                            html += `
                            <div class="right-sidebar__item wallet-list skeleton">
                                <div class="d-flex align-items-center">
                                    <span class="right-sidebar__item-icon">
                                        <img src="${wallet.currency.image_url}">
                                    </span>
                                    <h6 class="right-sidebar__item-name">
                                        ${wallet.currency.name}
                                        <span class="fs-11 d-block">
                                            ${wallet.currency.symbol}
                                        </span>
                                    </h6>
                                </div>

                                <h6 class="right-sidebar__item-number">${getAmount(wallet.balance)}</h6>
                            </div>
                            `
                        });
                        walletSkip += 3;
                        $('.wallet-wrapper').append(html);
                    } else {
                        $this.remove();
                    }

                    $('.right-sidebar__menu').animate({
                        scrollTop: $('.right-sidebar__menu')[0].scrollHeight + 150
                    }, "slow");
                },
                error: function() {
                    notify('error', "@lang('Something went to wrong')");
                    $this.remove();
                }
            });
        });


    })(jQuery);
</script>

@if(request()->get('type') && request()->get('type')=='deposit')

    <script>
        $(document).ready(function (){

            $('.toggle-dashboard-right').trigger('click');
        })
    </script>

@endif



<script src="{{ asset('assets/global/js/bootstrap.bundle.min.js') }}"></script>
@stack('script-lib')

<script src="{{ asset($activeTemplateTrue . 'dashboard/js/main.js') }}"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.9.1/summernote.min.js"></script>



<script>
    window.allow_decimal = "{{ gs('allow_decimal_after_number') }}";
</script>

@include('partials.notify')

@php echo loadExtension('tawk-chat') @endphp

@if (gs('pn'))
    @include('partials.push_script')
@endif

@stack('script')

<script>

    $(document).ready(function(){
        let preViewBalance = localStorage.getItem('viewBalance');
        if(preViewBalance && preViewBalance=='yes'){
            $('.main-balance').hide();
            $('.main-balance-hide').show();
        }else{
            $('.main-balance').show();
            $('.main-balance-hide').hide();
        }


        $('.bal-m-sec').removeClass('d-none');
    })

    $(document).on('click', '.hide-balance', function (e) {
        $('.main-balance').hide();
        $('.main-balance-hide').show();

        localStorage.setItem('viewBalance', 'yes');

    });

    $(document).on('click', '.show-balance', function (e) {
        $('.main-balance').show();
        $('.main-balance-hide').hide();

        localStorage.removeItem('viewBalance');
    });

    $(document).on('click', '.copyTextBtn', function (e) {

        const ref_link='{{ route('user.register',['reference'=>auth()->user()->username]) }}';


        navigator.clipboard.writeText(ref_link);

    });
</script>

<script>
    (function ($) {
        "use strict";

        var inputElements = $('[type=text],[type=password],select,textarea');
        $.each(inputElements, function (index, element) {
            element = $(element);
            element.closest('.form-group').find('label').attr('for', element.attr('name'));
            element.attr('id', element.attr('name'))
        });

        $.each($('input, select, textarea'), function (i, element) {
            if (element.hasAttribute('required')) {
                $(element).closest('.form-group').find('label').addClass('required');
            }
        });

        $('.showFilterBtn').on('click', function () {
            $('.responsive-filter-card').slideToggle();
        });

        Array.from(document.querySelectorAll('table')).forEach(table => {
            let heading = table.querySelectorAll('thead tr th');
            Array.from(table.querySelectorAll('tbody tr')).forEach((row) => {
                if (row.querySelectorAll('td').length > 1) {
                    Array.from(row.querySelectorAll('td')).forEach((colum, i) => {
                        colum.setAttribute('data-label', heading[i].innerText)
                    });
                }
            });
        });

        @if (session('app'))
        $('.btn--base').each(function () {
            var isInForm = $(this).closest('form').length > 0;
            if (isInForm) {
                $(this).closest('form').on("submit", function () {
                    let html = `<span class="spinner-border spinner-border-sm" role="status"></span>`;
                    $(this).find('.btn--base').attr('disabled', true).html(html);
                });
            } else {
                $(this).on('click', function () {
                    let html = `<span class="spinner-border spinner-border-sm" role="status"></span>`;
                    $(this).attr('disabled', true).html(html);
                });
            }
        });
        @endif
    })(jQuery);
</script>

<script>
    $(document).ready(function (){

        $('.summernote').summernote();
    });

</script>
</body>
</html>
