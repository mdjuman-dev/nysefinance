var page_visibility = {
  "hidden_method"       : null,
  "show_method"         : null,
  "touchstart_method"   : null,     //PCのようにtouchstartがない場合はmousedownで発動
  "touchend_method"     : null,     //PCのようにtouchendがない場合はmouseupで発動
};

page_visibility.hidden              = null;
page_visibility.visibilityChange    = null;
page_visibility.touchstart          = null;
page_visibility.touchend            = null;

if (typeof document.hidden !== "undefined") { // Opera 12.10 や Firefox 18 以降でサポート
    page_visibility.hidden = "hidden";
    page_visibility.visibilityChange = "visibilitychange";
} else if (typeof document.msHidden !== "undefined") {
    page_visibility.hidden = "msHidden";
    page_visibility.visibilityChange = "msvisibilitychange";
} else if (typeof document.webkitHidden !== "undefined") {
    page_visibility.hidden = "webkitHidden";
    page_visibility.visibilityChange = "webkitvisibilitychange";
}

if (typeof document.ontouchstart !== "undefined") {
    page_visibility.touchstart       = "touchstart";
    page_visibility.touchend         = "touchend";
} else if (typeof document.onmousedown !== "undefined") {
    page_visibility.touchstart       = "mousedown";
    page_visibility.touchend         = "mouseup";
}

// 無名関数だと重複登録されてしまうので関数式としてラップ
page_visibility.handlerVisibilityChange = function(){
    if (document[page_visibility.hidden]) {
        if( page_visibility.hidden_method != null ){
            page_visibility.hidden_method();
        }
    } else {
        if( page_visibility.show_method != null ){
            page_visibility.show_method();
        }
    }
}

page_visibility.handlerTouchStart = function(){
    if( page_visibility.touchstart_method != null ){
        page_visibility.touchstart_method();
    }
}

page_visibility.handlerTouchEnd = function(){
    if( page_visibility.touchend_method != null ){
        page_visibility.touchend_method();
    }
}

// ブラウザーが addEventListener または Page Visibility API をサポートしない場合に警告
if (typeof document.addEventListener === "undefined" || typeof document[page_visibility.hidden] === "undefined") {
    // console.log("not supports the Page Visibility API.");
} else {
    // Page Visibility の変更を扱う
    document.addEventListener(page_visibility.visibilityChange, page_visibility.handlerVisibilityChange, false);
    document.addEventListener(page_visibility.touchstart, page_visibility.handlerTouchStart, false);
    document.addEventListener(page_visibility.touchend, page_visibility.handlerTouchEnd, false);
}
